#!/bin/bash

log_file="log.txt"

main(){
	echo ">>>>>>>>>>Testing source>>>>>>>>>>"
	echo ""
	eval "gcc -fprofile-arcs -ftest-coverage ../source.alt/source.orig/schedule.c -o ../source/schedule.exe >> ${log_file} 2>&1"
	eval "mkdir ../outputs/output.correct >> ${log_file} 2>&1"
	source ./runall.sh correct >> ${log_file} 
	eval "mv ./schedule.gc* ../source.alt/source.orig"
	eval "gcov -b -c ../source.alt/source.orig/schedule.c"
	eval "mv ./schedule.c.gcov ../source.alt/source.orig"
	eval "rm ../source/schedule.exe"
	eval "lcov -c -d ../source.alt/source.orig -o ../source.alt/source.orig/lcov_info --rc lcov_branch_coverage=1 >> ${log_file} 2>&1"
	eval "genhtml -o ../source.alt/source.orig/lcov_report ../source.alt/source.orig/lcov_info --rc lcov_branch_coverage=1 >> ${log_file} 2>&1"
	i=1;
	while(( $i<10 ))
	do
	  testing v$i
	  checking v$i
	  let i++
	done
}

testing(){
	target=$1
	echo ">>>>>>>>>>Testing ${target}>>>>>>>>>>"
	echo ""
	eval "gcc -fprofile-arcs -ftest-coverage ../versions.alt/versions.orig/${target}/schedule.c -o ../source/schedule.exe >> ${log_file} 2>&1"
	eval "mkdir ../outputs/output.${target} >> ${log_file} 2>&1"
	source ./runall.sh ${target} >> ${log_file} 
	eval "mv ./schedule.gc* ../versions.alt/versions.orig/${target}"
	eval "gcov -b -c ../versions.alt/versions.orig/${target}/schedule.c"
	eval "mv ./schedule.c.gcov ../versions.alt/versions.orig/${target}"
	eval "rm ../source/schedule.exe"
	eval "lcov -c -d ../versions.alt/versions.orig/${target} -o ../versions.alt/versions.orig/${target}/lcov_info --rc lcov_branch_coverage=1 >> ${log_file} 2>&1"
	eval "genhtml -o ../versions.alt/versions.orig/${target}/lcov_report ../versions.alt/versions.orig/${target}/lcov_info --rc lcov_branch_coverage=1 >> ${log_file} 2>&1"

}

checking(){
	round=2650
	r=${round}
	success=2650
	target=$1
	while(( ${r}>0 ))
	do
	   out="t${r}"
	   result=`diff -q ../outputs/output.correct/${out} ../outputs/output.${target}/${out} `
    	   if [ -n "$result" ];then
            #echo "Failed test: ${out}"
	      let success--
	   fi
    	let r--
	done
	echo "Passing rate: ${success}/${round}"
	echo ""
}

starttime=`date +'%Y-%m-%d %H:%M:%S'`
source ./cleanall.sh
main
endtime=`date +'%Y-%m-%d %H:%M:%S'`
start_seconds=$(date --date="$starttime" +%s);
end_seconds=$(date --date="$endtime" +%s);
echo "Completed in "$((end_seconds-start_seconds))"s"



