echo script type: R
echo ">>>>>>>>running test 1"
../source/schedule.exe 7 1 9  < ../inputs/input/inp.58 > ../outputs/output.${1}/t1
echo ">>>>>>>>running test 2"
../source/schedule.exe 2 3 5  < ../inputs/input/inp.46 > ../outputs/output.${1}/t2
echo ">>>>>>>>running test 3"
../source/schedule.exe 4 8 8  < ../inputs/input/inp.18 > ../outputs/output.${1}/t3
echo ">>>>>>>>running test 4"
../source/schedule.exe 10 0 2  < ../inputs/input/inp.51 > ../outputs/output.${1}/t4
echo ">>>>>>>>running test 5"
../source/schedule.exe 8 3 2  < ../inputs/input/inp.99 > ../outputs/output.${1}/t5
echo ">>>>>>>>running test 6"
../source/schedule.exe 7 10 5  < ../inputs/input/inp.84 > ../outputs/output.${1}/t6
echo ">>>>>>>>running test 7"
../source/schedule.exe 4 0 6  < ../inputs/input/inp.20 > ../outputs/output.${1}/t7
echo ">>>>>>>>running test 8"
../source/schedule.exe 3 7 4  < ../inputs/input/inp.28 > ../outputs/output.${1}/t8
echo ">>>>>>>>running test 9"
../source/schedule.exe 9 7 5  < ../inputs/input/inp.9 > ../outputs/output.${1}/t9
echo ">>>>>>>>running test 10"
../source/schedule.exe 9 10 6  < ../inputs/input/inp.98 > ../outputs/output.${1}/t10
echo ">>>>>>>>running test 11"
../source/schedule.exe 7 9 8  < ../inputs/input/inp.14 > ../outputs/output.${1}/t11
echo ">>>>>>>>running test 12"
../source/schedule.exe 8 9 0  < ../inputs/input/inp.34 > ../outputs/output.${1}/t12
echo ">>>>>>>>running test 13"
../source/schedule.exe 8 5 0  < ../inputs/input/inp.42 > ../outputs/output.${1}/t13
echo ">>>>>>>>running test 14"
../source/schedule.exe 9 8 5  < ../inputs/input/inp.88 > ../outputs/output.${1}/t14
echo ">>>>>>>>running test 15"
../source/schedule.exe 7 0 6  < ../inputs/input/inp.95 > ../outputs/output.${1}/t15
echo ">>>>>>>>running test 16"
../source/schedule.exe 8 3 9  < ../inputs/input/inp.56 > ../outputs/output.${1}/t16
echo ">>>>>>>>running test 17"
../source/schedule.exe 7 4 2  < ../inputs/input/inp.12 > ../outputs/output.${1}/t17
echo ">>>>>>>>running test 18"
../source/schedule.exe 5 8 7  < ../inputs/input/inp.6 > ../outputs/output.${1}/t18
echo ">>>>>>>>running test 19"
../source/schedule.exe 0 4 1  < ../inputs/input/inp.75 > ../outputs/output.${1}/t19
echo ">>>>>>>>running test 20"
../source/schedule.exe 0 10 6  < ../inputs/input/inp.59 > ../outputs/output.${1}/t20
echo ">>>>>>>>running test 21"
../source/schedule.exe 9 0 9  < ../inputs/input/inp.20 > ../outputs/output.${1}/t21
echo ">>>>>>>>running test 22"
../source/schedule.exe 9 9 2  < ../inputs/input/inp.3 > ../outputs/output.${1}/t22
echo ">>>>>>>>running test 23"
../source/schedule.exe 6 1 0  < ../inputs/input/inp.27 > ../outputs/output.${1}/t23
echo ">>>>>>>>running test 24"
../source/schedule.exe 5 10 8  < ../inputs/input/inp.66 > ../outputs/output.${1}/t24
echo ">>>>>>>>running test 25"
../source/schedule.exe 6 9 0  < ../inputs/input/inp.88 > ../outputs/output.${1}/t25
echo ">>>>>>>>running test 26"
../source/schedule.exe 3 7 3  < ../inputs/input/inp.32 > ../outputs/output.${1}/t26
echo ">>>>>>>>running test 27"
../source/schedule.exe 1 5 5  < ../inputs/input/inp.35 > ../outputs/output.${1}/t27
echo ">>>>>>>>running test 28"
../source/schedule.exe 1 2 7  < ../inputs/input/inp.30 > ../outputs/output.${1}/t28
echo ">>>>>>>>running test 29"
../source/schedule.exe 2 7 6  < ../inputs/input/inp.19 > ../outputs/output.${1}/t29
echo ">>>>>>>>running test 30"
../source/schedule.exe 4 6 3  < ../inputs/input/inp.68 > ../outputs/output.${1}/t30
echo ">>>>>>>>running test 31"
../source/schedule.exe 4 6 2  < ../inputs/input/inp.97 > ../outputs/output.${1}/t31
echo ">>>>>>>>running test 32"
../source/schedule.exe 8 4 2  < ../inputs/input/inp.58 > ../outputs/output.${1}/t32
echo ">>>>>>>>running test 33"
../source/schedule.exe 10 0 0  < ../inputs/input/inp.21 > ../outputs/output.${1}/t33
echo ">>>>>>>>running test 34"
../source/schedule.exe 6 3 3  < ../inputs/input/inp.6 > ../outputs/output.${1}/t34
echo ">>>>>>>>running test 35"
../source/schedule.exe 8 9 10  < ../inputs/input/inp.76 > ../outputs/output.${1}/t35
echo ">>>>>>>>running test 36"
../source/schedule.exe 10 5 9  < ../inputs/input/inp.6 > ../outputs/output.${1}/t36
echo ">>>>>>>>running test 37"
../source/schedule.exe 8 9 0  < ../inputs/input/inp.37 > ../outputs/output.${1}/t37
echo ">>>>>>>>running test 38"
../source/schedule.exe 10 10 3  < ../inputs/input/inp.15 > ../outputs/output.${1}/t38
echo ">>>>>>>>running test 39"
../source/schedule.exe 1 7 2  < ../inputs/input/inp.60 > ../outputs/output.${1}/t39
echo ">>>>>>>>running test 40"
../source/schedule.exe 2 9 5  < ../inputs/input/inp.15 > ../outputs/output.${1}/t40
echo ">>>>>>>>running test 41"
../source/schedule.exe 9 4 2  < ../inputs/input/inp.15 > ../outputs/output.${1}/t41
echo ">>>>>>>>running test 42"
../source/schedule.exe 9 0 0  < ../inputs/input/inp.81 > ../outputs/output.${1}/t42
echo ">>>>>>>>running test 43"
../source/schedule.exe 0 6 4  < ../inputs/input/inp.19 > ../outputs/output.${1}/t43
echo ">>>>>>>>running test 44"
../source/schedule.exe 10 4 5  < ../inputs/input/inp.53 > ../outputs/output.${1}/t44
echo ">>>>>>>>running test 45"
../source/schedule.exe 7 6 5  < ../inputs/input/inp.89 > ../outputs/output.${1}/t45
echo ">>>>>>>>running test 46"
../source/schedule.exe 0 2 2  < ../inputs/input/inp.97 > ../outputs/output.${1}/t46
echo ">>>>>>>>running test 47"
../source/schedule.exe 10 8 8  < ../inputs/input/inp.52 > ../outputs/output.${1}/t47
echo ">>>>>>>>running test 48"
../source/schedule.exe 0 5 1  < ../inputs/input/inp.22 > ../outputs/output.${1}/t48
echo ">>>>>>>>running test 49"
../source/schedule.exe 4 1 6  < ../inputs/input/inp.23 > ../outputs/output.${1}/t49
echo ">>>>>>>>running test 50"
../source/schedule.exe 7 10 4  < ../inputs/input/inp.10 > ../outputs/output.${1}/t50
echo ">>>>>>>>running test 51"
../source/schedule.exe 8 1 0  < ../inputs/input/inp.37 > ../outputs/output.${1}/t51
echo ">>>>>>>>running test 52"
../source/schedule.exe 1 10 6  < ../inputs/input/inp.1 > ../outputs/output.${1}/t52
echo ">>>>>>>>running test 53"
../source/schedule.exe 2 8 0  < ../inputs/input/inp.55 > ../outputs/output.${1}/t53
echo ">>>>>>>>running test 54"
../source/schedule.exe 0 5 1  < ../inputs/input/inp.91 > ../outputs/output.${1}/t54
echo ">>>>>>>>running test 55"
../source/schedule.exe 0 7 4  < ../inputs/input/inp.44 > ../outputs/output.${1}/t55
echo ">>>>>>>>running test 56"
../source/schedule.exe 6 2 3  < ../inputs/input/inp.2 > ../outputs/output.${1}/t56
echo ">>>>>>>>running test 57"
../source/schedule.exe 6 3 8  < ../inputs/input/inp.78 > ../outputs/output.${1}/t57
echo ">>>>>>>>running test 58"
../source/schedule.exe 6 10 8  < ../inputs/input/inp.28 > ../outputs/output.${1}/t58
echo ">>>>>>>>running test 59"
../source/schedule.exe 3 3 2  < ../inputs/input/inp.27 > ../outputs/output.${1}/t59
echo ">>>>>>>>running test 60"
../source/schedule.exe 6 1 4  < ../inputs/input/inp.60 > ../outputs/output.${1}/t60
echo ">>>>>>>>running test 61"
../source/schedule.exe 0 6 8  < ../inputs/input/inp.90 > ../outputs/output.${1}/t61
echo ">>>>>>>>running test 62"
../source/schedule.exe 5 2 8  < ../inputs/input/inp.81 > ../outputs/output.${1}/t62
echo ">>>>>>>>running test 63"
../source/schedule.exe 3 4 5  < ../inputs/input/inp.46 > ../outputs/output.${1}/t63
echo ">>>>>>>>running test 64"
../source/schedule.exe 10 4 0  < ../inputs/input/inp.86 > ../outputs/output.${1}/t64
echo ">>>>>>>>running test 65"
../source/schedule.exe 6 1 2  < ../inputs/input/inp.38 > ../outputs/output.${1}/t65
echo ">>>>>>>>running test 66"
../source/schedule.exe 8 2 9  < ../inputs/input/inp.39 > ../outputs/output.${1}/t66
echo ">>>>>>>>running test 67"
../source/schedule.exe 6 7 7  < ../inputs/input/inp.3 > ../outputs/output.${1}/t67
echo ">>>>>>>>running test 68"
../source/schedule.exe 2 5 5  < ../inputs/input/inp.6 > ../outputs/output.${1}/t68
echo ">>>>>>>>running test 69"
../source/schedule.exe 7 5 7  < ../inputs/input/inp.66 > ../outputs/output.${1}/t69
echo ">>>>>>>>running test 70"
../source/schedule.exe 3 6 1  < ../inputs/input/inp.61 > ../outputs/output.${1}/t70
echo ">>>>>>>>running test 71"
../source/schedule.exe 4 9 6  < ../inputs/input/inp.30 > ../outputs/output.${1}/t71
echo ">>>>>>>>running test 72"
../source/schedule.exe 6 0 1  < ../inputs/input/inp.26 > ../outputs/output.${1}/t72
echo ">>>>>>>>running test 73"
../source/schedule.exe 3 5 6  < ../inputs/input/inp.84 > ../outputs/output.${1}/t73
echo ">>>>>>>>running test 74"
../source/schedule.exe 4 8 0  < ../inputs/input/inp.51 > ../outputs/output.${1}/t74
echo ">>>>>>>>running test 75"
../source/schedule.exe 2 3 7  < ../inputs/input/inp.30 > ../outputs/output.${1}/t75
echo ">>>>>>>>running test 76"
../source/schedule.exe 1 4 4  < ../inputs/input/inp.68 > ../outputs/output.${1}/t76
echo ">>>>>>>>running test 77"
../source/schedule.exe 0 4 4  < ../inputs/input/inp.56 > ../outputs/output.${1}/t77
echo ">>>>>>>>running test 78"
../source/schedule.exe 1 3 8  < ../inputs/input/inp.43 > ../outputs/output.${1}/t78
echo ">>>>>>>>running test 79"
../source/schedule.exe 4 6 6  < ../inputs/input/inp.39 > ../outputs/output.${1}/t79
echo ">>>>>>>>running test 80"
../source/schedule.exe 7 6 8  < ../inputs/input/inp.26 > ../outputs/output.${1}/t80
echo ">>>>>>>>running test 81"
../source/schedule.exe 1 3 10  < ../inputs/input/inp.27 > ../outputs/output.${1}/t81
echo ">>>>>>>>running test 82"
../source/schedule.exe 7 3 8  < ../inputs/input/inp.86 > ../outputs/output.${1}/t82
echo ">>>>>>>>running test 83"
../source/schedule.exe 3 3 8  < ../inputs/input/inp.3 > ../outputs/output.${1}/t83
echo ">>>>>>>>running test 84"
../source/schedule.exe 1 10 1  < ../inputs/input/inp.61 > ../outputs/output.${1}/t84
echo ">>>>>>>>running test 85"
../source/schedule.exe 8 5 3  < ../inputs/input/inp.91 > ../outputs/output.${1}/t85
echo ">>>>>>>>running test 86"
../source/schedule.exe 3 5 3  < ../inputs/input/inp.43 > ../outputs/output.${1}/t86
echo ">>>>>>>>running test 87"
../source/schedule.exe 7 6 0  < ../inputs/input/inp.5 > ../outputs/output.${1}/t87
echo ">>>>>>>>running test 88"
../source/schedule.exe 4 6 7  < ../inputs/input/inp.28 > ../outputs/output.${1}/t88
echo ">>>>>>>>running test 89"
../source/schedule.exe 9 0 3  < ../inputs/input/inp.73 > ../outputs/output.${1}/t89
echo ">>>>>>>>running test 90"
../source/schedule.exe 8 7 6  < ../inputs/input/inp.54 > ../outputs/output.${1}/t90
echo ">>>>>>>>running test 91"
../source/schedule.exe 6 10 9  < ../inputs/input/inp.74 > ../outputs/output.${1}/t91
echo ">>>>>>>>running test 92"
../source/schedule.exe 5 4 8  < ../inputs/input/inp.99 > ../outputs/output.${1}/t92
echo ">>>>>>>>running test 93"
../source/schedule.exe 3 0 2  < ../inputs/input/inp.38 > ../outputs/output.${1}/t93
echo ">>>>>>>>running test 94"
../source/schedule.exe 2 0 1  < ../inputs/input/inp.3 > ../outputs/output.${1}/t94
echo ">>>>>>>>running test 95"
../source/schedule.exe 6 4 6  < ../inputs/input/inp.58 > ../outputs/output.${1}/t95
echo ">>>>>>>>running test 96"
../source/schedule.exe 8 9 6  < ../inputs/input/inp.32 > ../outputs/output.${1}/t96
echo ">>>>>>>>running test 97"
../source/schedule.exe 7 1 8  < ../inputs/input/inp.91 > ../outputs/output.${1}/t97
echo ">>>>>>>>running test 98"
../source/schedule.exe 9 3 7  < ../inputs/input/inp.40 > ../outputs/output.${1}/t98
echo ">>>>>>>>running test 99"
../source/schedule.exe 3 9 4  < ../inputs/input/inp.41 > ../outputs/output.${1}/t99
echo ">>>>>>>>running test 100"
../source/schedule.exe 6 10 0  < ../inputs/input/inp.56 > ../outputs/output.${1}/t100
echo ">>>>>>>>running test 101"
../source/schedule.exe 3 0 7  < ../inputs/input/inp.71 > ../outputs/output.${1}/t101
echo ">>>>>>>>running test 102"
../source/schedule.exe 2 9 4  < ../inputs/input/inp.20 > ../outputs/output.${1}/t102
echo ">>>>>>>>running test 103"
../source/schedule.exe 6 1 7  < ../inputs/input/inp.91 > ../outputs/output.${1}/t103
echo ">>>>>>>>running test 104"
../source/schedule.exe 2 9 9  < ../inputs/input/inp.25 > ../outputs/output.${1}/t104
echo ">>>>>>>>running test 105"
../source/schedule.exe 0 10 3  < ../inputs/input/inp.6 > ../outputs/output.${1}/t105
echo ">>>>>>>>running test 106"
../source/schedule.exe 3 10 10  < ../inputs/input/inp.63 > ../outputs/output.${1}/t106
echo ">>>>>>>>running test 107"
../source/schedule.exe 10 1 7  < ../inputs/input/inp.74 > ../outputs/output.${1}/t107
echo ">>>>>>>>running test 108"
../source/schedule.exe 7 1 2  < ../inputs/input/inp.16 > ../outputs/output.${1}/t108
echo ">>>>>>>>running test 109"
../source/schedule.exe 1 4 5  < ../inputs/input/inp.24 > ../outputs/output.${1}/t109
echo ">>>>>>>>running test 110"
../source/schedule.exe 0 0 1  < ../inputs/input/inp.71 > ../outputs/output.${1}/t110
echo ">>>>>>>>running test 111"
../source/schedule.exe 8 5 1  < ../inputs/input/inp.92 > ../outputs/output.${1}/t111
echo ">>>>>>>>running test 112"
../source/schedule.exe 10 5 8  < ../inputs/input/inp.82 > ../outputs/output.${1}/t112
echo ">>>>>>>>running test 113"
../source/schedule.exe 4 9 4  < ../inputs/input/inp.44 > ../outputs/output.${1}/t113
echo ">>>>>>>>running test 114"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.20 > ../outputs/output.${1}/t114
echo ">>>>>>>>running test 115"
../source/schedule.exe 0 0 8  < ../inputs/input/inp.29 > ../outputs/output.${1}/t115
echo ">>>>>>>>running test 116"
../source/schedule.exe 5 7 9  < ../inputs/input/inp.39 > ../outputs/output.${1}/t116
echo ">>>>>>>>running test 117"
../source/schedule.exe 0 8 2  < ../inputs/input/inp.47 > ../outputs/output.${1}/t117
echo ">>>>>>>>running test 118"
../source/schedule.exe 2 3 3  < ../inputs/input/inp.3 > ../outputs/output.${1}/t118
echo ">>>>>>>>running test 119"
../source/schedule.exe 2 3 7  < ../inputs/input/inp.12 > ../outputs/output.${1}/t119
echo ">>>>>>>>running test 120"
../source/schedule.exe 8 0 0  < ../inputs/input/inp.32 > ../outputs/output.${1}/t120
echo ">>>>>>>>running test 121"
../source/schedule.exe 7 3 7  < ../inputs/input/inp.12 > ../outputs/output.${1}/t121
echo ">>>>>>>>running test 122"
../source/schedule.exe 5 5 8  < ../inputs/input/inp.74 > ../outputs/output.${1}/t122
echo ">>>>>>>>running test 123"
../source/schedule.exe 1 7 2  < ../inputs/input/inp.59 > ../outputs/output.${1}/t123
echo ">>>>>>>>running test 124"
../source/schedule.exe 3 1 10  < ../inputs/input/inp.71 > ../outputs/output.${1}/t124
echo ">>>>>>>>running test 125"
../source/schedule.exe 7 5 2  < ../inputs/input/inp.98 > ../outputs/output.${1}/t125
echo ">>>>>>>>running test 126"
../source/schedule.exe 6 9 0  < ../inputs/input/inp.74 > ../outputs/output.${1}/t126
echo ">>>>>>>>running test 127"
../source/schedule.exe 5 1 1  < ../inputs/input/inp.60 > ../outputs/output.${1}/t127
echo ">>>>>>>>running test 128"
../source/schedule.exe 10 10 6  < ../inputs/input/inp.79 > ../outputs/output.${1}/t128
echo ">>>>>>>>running test 129"
../source/schedule.exe 2 2 3  < ../inputs/input/inp.35 > ../outputs/output.${1}/t129
echo ">>>>>>>>running test 130"
../source/schedule.exe 6 2 6  < ../inputs/input/inp.20 > ../outputs/output.${1}/t130
echo ">>>>>>>>running test 131"
../source/schedule.exe 4 8 2  < ../inputs/input/inp.91 > ../outputs/output.${1}/t131
echo ">>>>>>>>running test 132"
../source/schedule.exe 8 4 9  < ../inputs/input/inp.54 > ../outputs/output.${1}/t132
echo ">>>>>>>>running test 133"
../source/schedule.exe 1 1 4  < ../inputs/input/inp.30 > ../outputs/output.${1}/t133
echo ">>>>>>>>running test 134"
../source/schedule.exe 5 8 10  < ../inputs/input/inp.76 > ../outputs/output.${1}/t134
echo ">>>>>>>>running test 135"
../source/schedule.exe 2 1 6  < ../inputs/input/inp.95 > ../outputs/output.${1}/t135
echo ">>>>>>>>running test 136"
../source/schedule.exe 4 9 10  < ../inputs/input/inp.33 > ../outputs/output.${1}/t136
echo ">>>>>>>>running test 137"
../source/schedule.exe 7 9 0  < ../inputs/input/inp.25 > ../outputs/output.${1}/t137
echo ">>>>>>>>running test 138"
../source/schedule.exe 2 6 0  < ../inputs/input/inp.45 > ../outputs/output.${1}/t138
echo ">>>>>>>>running test 139"
../source/schedule.exe 2 3 7  < ../inputs/input/inp.99 > ../outputs/output.${1}/t139
echo ">>>>>>>>running test 140"
../source/schedule.exe 2 2 10  < ../inputs/input/inp.45 > ../outputs/output.${1}/t140
echo ">>>>>>>>running test 141"
../source/schedule.exe 5 0 9  < ../inputs/input/inp.11 > ../outputs/output.${1}/t141
echo ">>>>>>>>running test 142"
../source/schedule.exe 4 8 1  < ../inputs/input/inp.53 > ../outputs/output.${1}/t142
echo ">>>>>>>>running test 143"
../source/schedule.exe 5 3 2  < ../inputs/input/inp.38 > ../outputs/output.${1}/t143
echo ">>>>>>>>running test 144"
../source/schedule.exe 10 3 3  < ../inputs/input/inp.78 > ../outputs/output.${1}/t144
echo ">>>>>>>>running test 145"
../source/schedule.exe 1 6 10  < ../inputs/input/inp.57 > ../outputs/output.${1}/t145
echo ">>>>>>>>running test 146"
../source/schedule.exe 0 4 10  < ../inputs/input/inp.82 > ../outputs/output.${1}/t146
echo ">>>>>>>>running test 147"
../source/schedule.exe 4 10 2  < ../inputs/input/inp.91 > ../outputs/output.${1}/t147
echo ">>>>>>>>running test 148"
../source/schedule.exe 1 2 10  < ../inputs/input/inp.40 > ../outputs/output.${1}/t148
echo ">>>>>>>>running test 149"
../source/schedule.exe 6 8 9  < ../inputs/input/inp.100 > ../outputs/output.${1}/t149
echo ">>>>>>>>running test 150"
../source/schedule.exe 8 3 8  < ../inputs/input/inp.92 > ../outputs/output.${1}/t150
echo ">>>>>>>>running test 151"
../source/schedule.exe 1 10 7  < ../inputs/input/inp.18 > ../outputs/output.${1}/t151
echo ">>>>>>>>running test 152"
../source/schedule.exe 7 8 5  < ../inputs/input/inp.9 > ../outputs/output.${1}/t152
echo ">>>>>>>>running test 153"
../source/schedule.exe 7 6 5  < ../inputs/input/inp.24 > ../outputs/output.${1}/t153
echo ">>>>>>>>running test 154"
../source/schedule.exe 4 3 0  < ../inputs/input/inp.2 > ../outputs/output.${1}/t154
echo ">>>>>>>>running test 155"
../source/schedule.exe 10 5 6  < ../inputs/input/inp.2 > ../outputs/output.${1}/t155
echo ">>>>>>>>running test 156"
../source/schedule.exe 9 8 9  < ../inputs/input/inp.26 > ../outputs/output.${1}/t156
echo ">>>>>>>>running test 157"
../source/schedule.exe 4 2 4  < ../inputs/input/inp.22 > ../outputs/output.${1}/t157
echo ">>>>>>>>running test 158"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.94 > ../outputs/output.${1}/t158
echo ">>>>>>>>running test 159"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.40 > ../outputs/output.${1}/t159
echo ">>>>>>>>running test 160"
../source/schedule.exe 5 6 2  < ../inputs/input/inp.92 > ../outputs/output.${1}/t160
echo ">>>>>>>>running test 161"
../source/schedule.exe 9 8 3  < ../inputs/input/inp.0 > ../outputs/output.${1}/t161
echo ">>>>>>>>running test 162"
../source/schedule.exe 7 6 2  < ../inputs/input/inp.86 > ../outputs/output.${1}/t162
echo ">>>>>>>>running test 163"
../source/schedule.exe 1 1 1  < ../inputs/input/inp.78 > ../outputs/output.${1}/t163
echo ">>>>>>>>running test 164"
../source/schedule.exe 3 7 3  < ../inputs/input/inp.7 > ../outputs/output.${1}/t164
echo ">>>>>>>>running test 165"
../source/schedule.exe 3 8 8  < ../inputs/input/inp.61 > ../outputs/output.${1}/t165
echo ">>>>>>>>running test 166"
../source/schedule.exe 10 2 4  < ../inputs/input/inp.84 > ../outputs/output.${1}/t166
echo ">>>>>>>>running test 167"
../source/schedule.exe 2 2 2  < ../inputs/input/inp.51 > ../outputs/output.${1}/t167
echo ">>>>>>>>running test 168"
../source/schedule.exe 0 4 2  < ../inputs/input/inp.2 > ../outputs/output.${1}/t168
echo ">>>>>>>>running test 169"
../source/schedule.exe 5 2 0  < ../inputs/input/inp.76 > ../outputs/output.${1}/t169
echo ">>>>>>>>running test 170"
../source/schedule.exe 7 10 1  < ../inputs/input/inp.21 > ../outputs/output.${1}/t170
echo ">>>>>>>>running test 171"
../source/schedule.exe 7 0 0  < ../inputs/input/inp.39 > ../outputs/output.${1}/t171
echo ">>>>>>>>running test 172"
../source/schedule.exe 10 4 3  < ../inputs/input/inp.35 > ../outputs/output.${1}/t172
echo ">>>>>>>>running test 173"
../source/schedule.exe 1 8 1  < ../inputs/input/inp.5 > ../outputs/output.${1}/t173
echo ">>>>>>>>running test 174"
../source/schedule.exe 2 1 10  < ../inputs/input/inp.20 > ../outputs/output.${1}/t174
echo ">>>>>>>>running test 175"
../source/schedule.exe 10 1 6  < ../inputs/input/inp.8 > ../outputs/output.${1}/t175
echo ">>>>>>>>running test 176"
../source/schedule.exe 10 5 7  < ../inputs/input/inp.72 > ../outputs/output.${1}/t176
echo ">>>>>>>>running test 177"
../source/schedule.exe 9 10 5  < ../inputs/input/inp.96 > ../outputs/output.${1}/t177
echo ">>>>>>>>running test 178"
../source/schedule.exe 1 1 8  < ../inputs/input/inp.14 > ../outputs/output.${1}/t178
echo ">>>>>>>>running test 179"
../source/schedule.exe 3 9 5  < ../inputs/input/inp.2 > ../outputs/output.${1}/t179
echo ">>>>>>>>running test 180"
../source/schedule.exe 6 2 10  < ../inputs/input/inp.71 > ../outputs/output.${1}/t180
echo ">>>>>>>>running test 181"
../source/schedule.exe 7 8 4  < ../inputs/input/inp.30 > ../outputs/output.${1}/t181
echo ">>>>>>>>running test 182"
../source/schedule.exe 9 5 7  < ../inputs/input/inp.96 > ../outputs/output.${1}/t182
echo ">>>>>>>>running test 183"
../source/schedule.exe 10 6 5  < ../inputs/input/inp.35 > ../outputs/output.${1}/t183
echo ">>>>>>>>running test 184"
../source/schedule.exe 8 2 8  < ../inputs/input/inp.50 > ../outputs/output.${1}/t184
echo ">>>>>>>>running test 185"
../source/schedule.exe 10 7 4  < ../inputs/input/inp.72 > ../outputs/output.${1}/t185
echo ">>>>>>>>running test 186"
../source/schedule.exe 0 2 5  < ../inputs/input/inp.16 > ../outputs/output.${1}/t186
echo ">>>>>>>>running test 187"
../source/schedule.exe 0 0 7  < ../inputs/input/inp.60 > ../outputs/output.${1}/t187
echo ">>>>>>>>running test 188"
../source/schedule.exe 7 8 9  < ../inputs/input/inp.64 > ../outputs/output.${1}/t188
echo ">>>>>>>>running test 189"
../source/schedule.exe 1 3 8  < ../inputs/input/inp.65 > ../outputs/output.${1}/t189
echo ">>>>>>>>running test 190"
../source/schedule.exe 2 0 8  < ../inputs/input/inp.86 > ../outputs/output.${1}/t190
echo ">>>>>>>>running test 191"
../source/schedule.exe 1 5 3  < ../inputs/input/inp.33 > ../outputs/output.${1}/t191
echo ">>>>>>>>running test 192"
../source/schedule.exe 2 2 0  < ../inputs/input/inp.85 > ../outputs/output.${1}/t192
echo ">>>>>>>>running test 193"
../source/schedule.exe 4 6 10  < ../inputs/input/inp.86 > ../outputs/output.${1}/t193
echo ">>>>>>>>running test 194"
../source/schedule.exe 5 0 2  < ../inputs/input/inp.83 > ../outputs/output.${1}/t194
echo ">>>>>>>>running test 195"
../source/schedule.exe 5 7 6  < ../inputs/input/inp.75 > ../outputs/output.${1}/t195
echo ">>>>>>>>running test 196"
../source/schedule.exe 4 2 2  < ../inputs/input/inp.77 > ../outputs/output.${1}/t196
echo ">>>>>>>>running test 197"
../source/schedule.exe 4 3 1  < ../inputs/input/inp.91 > ../outputs/output.${1}/t197
echo ">>>>>>>>running test 198"
../source/schedule.exe 10 3 8  < ../inputs/input/inp.7 > ../outputs/output.${1}/t198
echo ">>>>>>>>running test 199"
../source/schedule.exe 4 0 6  < ../inputs/input/inp.99 > ../outputs/output.${1}/t199
echo ">>>>>>>>running test 200"
../source/schedule.exe 2 6 2  < ../inputs/input/inp.92 > ../outputs/output.${1}/t200
echo ">>>>>>>>running test 201"
../source/schedule.exe 2 8 10  < ../inputs/input/inp.97 > ../outputs/output.${1}/t201
echo ">>>>>>>>running test 202"
../source/schedule.exe 4 7 6  < ../inputs/input/inp.30 > ../outputs/output.${1}/t202
echo ">>>>>>>>running test 203"
../source/schedule.exe 6 6 3  < ../inputs/input/inp.55 > ../outputs/output.${1}/t203
echo ">>>>>>>>running test 204"
../source/schedule.exe 9 0 5  < ../inputs/input/inp.51 > ../outputs/output.${1}/t204
echo ">>>>>>>>running test 205"
../source/schedule.exe 2 10 3  < ../inputs/input/inp.5 > ../outputs/output.${1}/t205
echo ">>>>>>>>running test 206"
../source/schedule.exe 7 2 2  < ../inputs/input/inp.17 > ../outputs/output.${1}/t206
echo ">>>>>>>>running test 207"
../source/schedule.exe 9 8 10  < ../inputs/input/inp.35 > ../outputs/output.${1}/t207
echo ">>>>>>>>running test 208"
../source/schedule.exe 7 8 10  < ../inputs/input/inp.30 > ../outputs/output.${1}/t208
echo ">>>>>>>>running test 209"
../source/schedule.exe 5 7 9  < ../inputs/input/inp.76 > ../outputs/output.${1}/t209
echo ">>>>>>>>running test 210"
../source/schedule.exe 10 10 10  < ../inputs/input/inp.97 > ../outputs/output.${1}/t210
echo ">>>>>>>>running test 211"
../source/schedule.exe 5 0 10  < ../inputs/input/inp.52 > ../outputs/output.${1}/t211
echo ">>>>>>>>running test 212"
../source/schedule.exe 1 2 5  < ../inputs/input/inp.45 > ../outputs/output.${1}/t212
echo ">>>>>>>>running test 213"
../source/schedule.exe 3 2 0  < ../inputs/input/inp.22 > ../outputs/output.${1}/t213
echo ">>>>>>>>running test 214"
../source/schedule.exe 9 2 6  < ../inputs/input/inp.23 > ../outputs/output.${1}/t214
echo ">>>>>>>>running test 215"
../source/schedule.exe 3 7 4  < ../inputs/input/inp.2 > ../outputs/output.${1}/t215
echo ">>>>>>>>running test 216"
../source/schedule.exe 5 2 3  < ../inputs/input/inp.37 > ../outputs/output.${1}/t216
echo ">>>>>>>>running test 217"
../source/schedule.exe 2 9 10  < ../inputs/input/inp.34 > ../outputs/output.${1}/t217
echo ">>>>>>>>running test 218"
../source/schedule.exe 4 2 10  < ../inputs/input/inp.97 > ../outputs/output.${1}/t218
echo ">>>>>>>>running test 219"
../source/schedule.exe 1 5 4  < ../inputs/input/inp.61 > ../outputs/output.${1}/t219
echo ">>>>>>>>running test 220"
../source/schedule.exe 2 9 9  < ../inputs/input/inp.65 > ../outputs/output.${1}/t220
echo ">>>>>>>>running test 221"
../source/schedule.exe 6 10 5  < ../inputs/input/inp.13 > ../outputs/output.${1}/t221
echo ">>>>>>>>running test 222"
../source/schedule.exe 1 3 3  < ../inputs/input/inp.15 > ../outputs/output.${1}/t222
echo ">>>>>>>>running test 223"
../source/schedule.exe 8 7 6  < ../inputs/input/inp.59 > ../outputs/output.${1}/t223
echo ">>>>>>>>running test 224"
../source/schedule.exe 2 5 6  < ../inputs/input/inp.12 > ../outputs/output.${1}/t224
echo ">>>>>>>>running test 225"
../source/schedule.exe 10 10 4  < ../inputs/input/inp.18 > ../outputs/output.${1}/t225
echo ">>>>>>>>running test 226"
../source/schedule.exe 9 1 3  < ../inputs/input/inp.1 > ../outputs/output.${1}/t226
echo ">>>>>>>>running test 227"
../source/schedule.exe 3 7 6  < ../inputs/input/inp.47 > ../outputs/output.${1}/t227
echo ">>>>>>>>running test 228"
../source/schedule.exe 2 4 10  < ../inputs/input/inp.18 > ../outputs/output.${1}/t228
echo ">>>>>>>>running test 229"
../source/schedule.exe 2 3 9  < ../inputs/input/inp.4 > ../outputs/output.${1}/t229
echo ">>>>>>>>running test 230"
../source/schedule.exe 10 10 3  < ../inputs/input/inp.61 > ../outputs/output.${1}/t230
echo ">>>>>>>>running test 231"
../source/schedule.exe 9 0 8  < ../inputs/input/inp.87 > ../outputs/output.${1}/t231
echo ">>>>>>>>running test 232"
../source/schedule.exe 9 10 7  < ../inputs/input/inp.66 > ../outputs/output.${1}/t232
echo ">>>>>>>>running test 233"
../source/schedule.exe 6 5 0  < ../inputs/input/inp.53 > ../outputs/output.${1}/t233
echo ">>>>>>>>running test 234"
../source/schedule.exe 8 2 7  < ../inputs/input/inp.53 > ../outputs/output.${1}/t234
echo ">>>>>>>>running test 235"
../source/schedule.exe 8 0 6  < ../inputs/input/inp.4 > ../outputs/output.${1}/t235
echo ">>>>>>>>running test 236"
../source/schedule.exe 2 1 4  < ../inputs/input/inp.81 > ../outputs/output.${1}/t236
echo ">>>>>>>>running test 237"
../source/schedule.exe 9 6 10  < ../inputs/input/inp.99 > ../outputs/output.${1}/t237
echo ">>>>>>>>running test 238"
../source/schedule.exe 8 8 9  < ../inputs/input/inp.89 > ../outputs/output.${1}/t238
echo ">>>>>>>>running test 239"
../source/schedule.exe 8 0 7  < ../inputs/input/inp.28 > ../outputs/output.${1}/t239
echo ">>>>>>>>running test 240"
../source/schedule.exe 4 10 7  < ../inputs/input/inp.66 > ../outputs/output.${1}/t240
echo ">>>>>>>>running test 241"
../source/schedule.exe 7 0 5  < ../inputs/input/inp.70 > ../outputs/output.${1}/t241
echo ">>>>>>>>running test 242"
../source/schedule.exe 0 1 10  < ../inputs/input/inp.83 > ../outputs/output.${1}/t242
echo ">>>>>>>>running test 243"
../source/schedule.exe 0 0 9  < ../inputs/input/inp.63 > ../outputs/output.${1}/t243
echo ">>>>>>>>running test 244"
../source/schedule.exe 2 3 6  < ../inputs/input/inp.83 > ../outputs/output.${1}/t244
echo ">>>>>>>>running test 245"
../source/schedule.exe 4 7 0  < ../inputs/input/inp.66 > ../outputs/output.${1}/t245
echo ">>>>>>>>running test 246"
../source/schedule.exe 1 7 7  < ../inputs/input/inp.40 > ../outputs/output.${1}/t246
echo ">>>>>>>>running test 247"
../source/schedule.exe 7 4 6  < ../inputs/input/inp.51 > ../outputs/output.${1}/t247
echo ">>>>>>>>running test 248"
../source/schedule.exe 8 1 2  < ../inputs/input/inp.42 > ../outputs/output.${1}/t248
echo ">>>>>>>>running test 249"
../source/schedule.exe 0 3 1  < ../inputs/input/inp.66 > ../outputs/output.${1}/t249
echo ">>>>>>>>running test 250"
../source/schedule.exe 10 6 3  < ../inputs/input/inp.42 > ../outputs/output.${1}/t250
echo ">>>>>>>>running test 251"
../source/schedule.exe 0 2 3  < ../inputs/input/inp.39 > ../outputs/output.${1}/t251
echo ">>>>>>>>running test 252"
../source/schedule.exe 9 7 3  < ../inputs/input/inp.56 > ../outputs/output.${1}/t252
echo ">>>>>>>>running test 253"
../source/schedule.exe 3 0 5  < ../inputs/input/inp.1 > ../outputs/output.${1}/t253
echo ">>>>>>>>running test 254"
../source/schedule.exe 5 4 4  < ../inputs/input/inp.44 > ../outputs/output.${1}/t254
echo ">>>>>>>>running test 255"
../source/schedule.exe 10 5 6  < ../inputs/input/inp.27 > ../outputs/output.${1}/t255
echo ">>>>>>>>running test 256"
../source/schedule.exe 6 6 0  < ../inputs/input/inp.59 > ../outputs/output.${1}/t256
echo ">>>>>>>>running test 257"
../source/schedule.exe 2 2 5  < ../inputs/input/inp.25 > ../outputs/output.${1}/t257
echo ">>>>>>>>running test 258"
../source/schedule.exe 4 6 6  < ../inputs/input/inp.52 > ../outputs/output.${1}/t258
echo ">>>>>>>>running test 259"
../source/schedule.exe 8 5 8  < ../inputs/input/inp.19 > ../outputs/output.${1}/t259
echo ">>>>>>>>running test 260"
../source/schedule.exe 1 9 4  < ../inputs/input/inp.16 > ../outputs/output.${1}/t260
echo ">>>>>>>>running test 261"
../source/schedule.exe 1 1 6  < ../inputs/input/inp.84 > ../outputs/output.${1}/t261
echo ">>>>>>>>running test 262"
../source/schedule.exe 6 9 6  < ../inputs/input/inp.2 > ../outputs/output.${1}/t262
echo ">>>>>>>>running test 263"
../source/schedule.exe 2 6 10  < ../inputs/input/inp.20 > ../outputs/output.${1}/t263
echo ">>>>>>>>running test 264"
../source/schedule.exe 2 1 2  < ../inputs/input/inp.58 > ../outputs/output.${1}/t264
echo ">>>>>>>>running test 265"
../source/schedule.exe 4 2 0  < ../inputs/input/inp.39 > ../outputs/output.${1}/t265
echo ">>>>>>>>running test 266"
../source/schedule.exe 2 8 1  < ../inputs/input/inp.10 > ../outputs/output.${1}/t266
echo ">>>>>>>>running test 267"
../source/schedule.exe 8 10 0  < ../inputs/input/inp.73 > ../outputs/output.${1}/t267
echo ">>>>>>>>running test 268"
../source/schedule.exe 7 8 5  < ../inputs/input/inp.34 > ../outputs/output.${1}/t268
echo ">>>>>>>>running test 269"
../source/schedule.exe 1 1 6  < ../inputs/input/inp.8 > ../outputs/output.${1}/t269
echo ">>>>>>>>running test 270"
../source/schedule.exe 9 5 3  < ../inputs/input/inp.24 > ../outputs/output.${1}/t270
echo ">>>>>>>>running test 271"
../source/schedule.exe 8 0 3  < ../inputs/input/inp.80 > ../outputs/output.${1}/t271
echo ">>>>>>>>running test 272"
../source/schedule.exe 10 2 6  < ../inputs/input/inp.33 > ../outputs/output.${1}/t272
echo ">>>>>>>>running test 273"
../source/schedule.exe 4 10 3  < ../inputs/input/inp.98 > ../outputs/output.${1}/t273
echo ">>>>>>>>running test 274"
../source/schedule.exe 6 7 10  < ../inputs/input/inp.20 > ../outputs/output.${1}/t274
echo ">>>>>>>>running test 275"
../source/schedule.exe 8 10 4  < ../inputs/input/inp.17 > ../outputs/output.${1}/t275
echo ">>>>>>>>running test 276"
../source/schedule.exe 8 2 9  < ../inputs/input/inp.70 > ../outputs/output.${1}/t276
echo ">>>>>>>>running test 277"
../source/schedule.exe 0 2 1  < ../inputs/input/inp.55 > ../outputs/output.${1}/t277
echo ">>>>>>>>running test 278"
../source/schedule.exe 8 7 8  < ../inputs/input/inp.17 > ../outputs/output.${1}/t278
echo ">>>>>>>>running test 279"
../source/schedule.exe 6 10 7  < ../inputs/input/inp.82 > ../outputs/output.${1}/t279
echo ">>>>>>>>running test 280"
../source/schedule.exe 2 2 2  < ../inputs/input/inp.60 > ../outputs/output.${1}/t280
echo ">>>>>>>>running test 281"
../source/schedule.exe 9 7 9  < ../inputs/input/inp.38 > ../outputs/output.${1}/t281
echo ">>>>>>>>running test 282"
../source/schedule.exe 5 3 10  < ../inputs/input/inp.96 > ../outputs/output.${1}/t282
echo ">>>>>>>>running test 283"
../source/schedule.exe 9 6 6  < ../inputs/input/inp.75 > ../outputs/output.${1}/t283
echo ">>>>>>>>running test 284"
../source/schedule.exe 3 6 3  < ../inputs/input/inp.20 > ../outputs/output.${1}/t284
echo ">>>>>>>>running test 285"
../source/schedule.exe 0 8 8  < ../inputs/input/inp.34 > ../outputs/output.${1}/t285
echo ">>>>>>>>running test 286"
../source/schedule.exe 7 5 5  < ../inputs/input/inp.78 > ../outputs/output.${1}/t286
echo ">>>>>>>>running test 287"
../source/schedule.exe 6 2 3  < ../inputs/input/inp.66 > ../outputs/output.${1}/t287
echo ">>>>>>>>running test 288"
../source/schedule.exe 10 6 6  < ../inputs/input/inp.47 > ../outputs/output.${1}/t288
echo ">>>>>>>>running test 289"
../source/schedule.exe 9 3 6  < ../inputs/input/inp.37 > ../outputs/output.${1}/t289
echo ">>>>>>>>running test 290"
../source/schedule.exe 9 3 9  < ../inputs/input/inp.100 > ../outputs/output.${1}/t290
echo ">>>>>>>>running test 291"
../source/schedule.exe 3 2 7  < ../inputs/input/inp.48 > ../outputs/output.${1}/t291
echo ">>>>>>>>running test 292"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.21 > ../outputs/output.${1}/t292
echo ">>>>>>>>running test 293"
../source/schedule.exe 7 8 3  < ../inputs/input/inp.97 > ../outputs/output.${1}/t293
echo ">>>>>>>>running test 294"
../source/schedule.exe 8 7 10  < ../inputs/input/inp.63 > ../outputs/output.${1}/t294
echo ">>>>>>>>running test 295"
../source/schedule.exe 9 9 7  < ../inputs/input/inp.64 > ../outputs/output.${1}/t295
echo ">>>>>>>>running test 296"
../source/schedule.exe 7 3 8  < ../inputs/input/inp.12 > ../outputs/output.${1}/t296
echo ">>>>>>>>running test 297"
../source/schedule.exe 0 0 6  < ../inputs/input/inp.81 > ../outputs/output.${1}/t297
echo ">>>>>>>>running test 298"
../source/schedule.exe 3 9 4  < ../inputs/input/inp.70 > ../outputs/output.${1}/t298
echo ">>>>>>>>running test 299"
../source/schedule.exe 4 2 3  < ../inputs/input/inp.48 > ../outputs/output.${1}/t299
echo ">>>>>>>>running test 300"
../source/schedule.exe 6 7 9  < ../inputs/input/inp.48 > ../outputs/output.${1}/t300
echo ">>>>>>>>running test 301"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.1 > ../outputs/output.${1}/t301
echo ">>>>>>>>running test 302"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.2 > ../outputs/output.${1}/t302
echo ">>>>>>>>running test 303"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.3 > ../outputs/output.${1}/t303
echo ">>>>>>>>running test 304"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.4 > ../outputs/output.${1}/t304
echo ">>>>>>>>running test 305"
../source/schedule.exe  2 1 4  < ../inputs/input/tc.5 > ../outputs/output.${1}/t305
echo ">>>>>>>>running test 306"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.6 > ../outputs/output.${1}/t306
echo ">>>>>>>>running test 307"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.7 > ../outputs/output.${1}/t307
echo ">>>>>>>>running test 308"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.8 > ../outputs/output.${1}/t308
echo ">>>>>>>>running test 309"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.9 > ../outputs/output.${1}/t309
echo ">>>>>>>>running test 310"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.10 > ../outputs/output.${1}/t310
echo ">>>>>>>>running test 311"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.11 > ../outputs/output.${1}/t311
echo ">>>>>>>>running test 312"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.12 > ../outputs/output.${1}/t312
echo ">>>>>>>>running test 313"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.13 > ../outputs/output.${1}/t313
echo ">>>>>>>>running test 314"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.14 > ../outputs/output.${1}/t314
echo ">>>>>>>>running test 315"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.15 > ../outputs/output.${1}/t315
echo ">>>>>>>>running test 316"
../source/schedule.exe  4 2 3  < ../inputs/input/tc.16 > ../outputs/output.${1}/t316
echo ">>>>>>>>running test 317"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.17 > ../outputs/output.${1}/t317
echo ">>>>>>>>running test 318"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.18 > ../outputs/output.${1}/t318
echo ">>>>>>>>running test 319"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.19 > ../outputs/output.${1}/t319
echo ">>>>>>>>running test 320"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.20 > ../outputs/output.${1}/t320
echo ">>>>>>>>running test 321"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.21 > ../outputs/output.${1}/t321
echo ">>>>>>>>running test 322"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.22 > ../outputs/output.${1}/t322
echo ">>>>>>>>running test 323"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.23 > ../outputs/output.${1}/t323
echo ">>>>>>>>running test 324"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.24 > ../outputs/output.${1}/t324
echo ">>>>>>>>running test 325"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.25 > ../outputs/output.${1}/t325
echo ">>>>>>>>running test 326"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.26 > ../outputs/output.${1}/t326
echo ">>>>>>>>running test 327"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.27 > ../outputs/output.${1}/t327
echo ">>>>>>>>running test 328"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.28 > ../outputs/output.${1}/t328
echo ">>>>>>>>running test 329"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.29 > ../outputs/output.${1}/t329
echo ">>>>>>>>running test 330"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.30 > ../outputs/output.${1}/t330
echo ">>>>>>>>running test 331"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.31 > ../outputs/output.${1}/t331
echo ">>>>>>>>running test 332"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.32 > ../outputs/output.${1}/t332
echo ">>>>>>>>running test 333"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.33 > ../outputs/output.${1}/t333
echo ">>>>>>>>running test 334"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.34 > ../outputs/output.${1}/t334
echo ">>>>>>>>running test 335"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.35 > ../outputs/output.${1}/t335
echo ">>>>>>>>running test 336"
../source/schedule.exe  3 4 3  < ../inputs/input/tc.36 > ../outputs/output.${1}/t336
echo ">>>>>>>>running test 337"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.37 > ../outputs/output.${1}/t337
echo ">>>>>>>>running test 338"
../source/schedule.exe  4 2 4  < ../inputs/input/tc.38 > ../outputs/output.${1}/t338
echo ">>>>>>>>running test 339"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.39 > ../outputs/output.${1}/t339
echo ">>>>>>>>running test 340"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.40 > ../outputs/output.${1}/t340
echo ">>>>>>>>running test 341"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.41 > ../outputs/output.${1}/t341
echo ">>>>>>>>running test 342"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.42 > ../outputs/output.${1}/t342
echo ">>>>>>>>running test 343"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.43 > ../outputs/output.${1}/t343
echo ">>>>>>>>running test 344"
../source/schedule.exe  3 3 3  < ../inputs/input/tc.44 > ../outputs/output.${1}/t344
echo ">>>>>>>>running test 345"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.45 > ../outputs/output.${1}/t345
echo ">>>>>>>>running test 346"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.46 > ../outputs/output.${1}/t346
echo ">>>>>>>>running test 347"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.47 > ../outputs/output.${1}/t347
echo ">>>>>>>>running test 348"
../source/schedule.exe  4 4 1  < ../inputs/input/tc.48 > ../outputs/output.${1}/t348
echo ">>>>>>>>running test 349"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.49 > ../outputs/output.${1}/t349
echo ">>>>>>>>running test 350"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.50 > ../outputs/output.${1}/t350
echo ">>>>>>>>running test 351"
../source/schedule.exe  1 1 3  < ../inputs/input/tc.51 > ../outputs/output.${1}/t351
echo ">>>>>>>>running test 352"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.52 > ../outputs/output.${1}/t352
echo ">>>>>>>>running test 353"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.53 > ../outputs/output.${1}/t353
echo ">>>>>>>>running test 354"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.54 > ../outputs/output.${1}/t354
echo ">>>>>>>>running test 355"
../source/schedule.exe  4 1 3  < ../inputs/input/tc.55 > ../outputs/output.${1}/t355
echo ">>>>>>>>running test 356"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.56 > ../outputs/output.${1}/t356
echo ">>>>>>>>running test 357"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.57 > ../outputs/output.${1}/t357
echo ">>>>>>>>running test 358"
../source/schedule.exe  1 3 4  < ../inputs/input/tc.58 > ../outputs/output.${1}/t358
echo ">>>>>>>>running test 359"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.59 > ../outputs/output.${1}/t359
echo ">>>>>>>>running test 360"
../source/schedule.exe  1 3 2  < ../inputs/input/tc.60 > ../outputs/output.${1}/t360
echo ">>>>>>>>running test 361"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.61 > ../outputs/output.${1}/t361
echo ">>>>>>>>running test 362"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.62 > ../outputs/output.${1}/t362
echo ">>>>>>>>running test 363"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.63 > ../outputs/output.${1}/t363
echo ">>>>>>>>running test 364"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.64 > ../outputs/output.${1}/t364
echo ">>>>>>>>running test 365"
../source/schedule.exe  3 4 1  < ../inputs/input/tc.65 > ../outputs/output.${1}/t365
echo ">>>>>>>>running test 366"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.66 > ../outputs/output.${1}/t366
echo ">>>>>>>>running test 367"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.67 > ../outputs/output.${1}/t367
echo ">>>>>>>>running test 368"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.68 > ../outputs/output.${1}/t368
echo ">>>>>>>>running test 369"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.69 > ../outputs/output.${1}/t369
echo ">>>>>>>>running test 370"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.70 > ../outputs/output.${1}/t370
echo ">>>>>>>>running test 371"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.71 > ../outputs/output.${1}/t371
echo ">>>>>>>>running test 372"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.72 > ../outputs/output.${1}/t372
echo ">>>>>>>>running test 373"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.73 > ../outputs/output.${1}/t373
echo ">>>>>>>>running test 374"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.74 > ../outputs/output.${1}/t374
echo ">>>>>>>>running test 375"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.75 > ../outputs/output.${1}/t375
echo ">>>>>>>>running test 376"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.76 > ../outputs/output.${1}/t376
echo ">>>>>>>>running test 377"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.77 > ../outputs/output.${1}/t377
echo ">>>>>>>>running test 378"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.78 > ../outputs/output.${1}/t378
echo ">>>>>>>>running test 379"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.79 > ../outputs/output.${1}/t379
echo ">>>>>>>>running test 380"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.80 > ../outputs/output.${1}/t380
echo ">>>>>>>>running test 381"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.81 > ../outputs/output.${1}/t381
echo ">>>>>>>>running test 382"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.82 > ../outputs/output.${1}/t382
echo ">>>>>>>>running test 383"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.83 > ../outputs/output.${1}/t383
echo ">>>>>>>>running test 384"
../source/schedule.exe  2 1 3  < ../inputs/input/tc.84 > ../outputs/output.${1}/t384
echo ">>>>>>>>running test 385"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.85 > ../outputs/output.${1}/t385
echo ">>>>>>>>running test 386"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.86 > ../outputs/output.${1}/t386
echo ">>>>>>>>running test 387"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.87 > ../outputs/output.${1}/t387
echo ">>>>>>>>running test 388"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.88 > ../outputs/output.${1}/t388
echo ">>>>>>>>running test 389"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.89 > ../outputs/output.${1}/t389
echo ">>>>>>>>running test 390"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.90 > ../outputs/output.${1}/t390
echo ">>>>>>>>running test 391"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.91 > ../outputs/output.${1}/t391
echo ">>>>>>>>running test 392"
../source/schedule.exe  2 2 4  < ../inputs/input/tc.92 > ../outputs/output.${1}/t392
echo ">>>>>>>>running test 393"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.93 > ../outputs/output.${1}/t393
echo ">>>>>>>>running test 394"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.94 > ../outputs/output.${1}/t394
echo ">>>>>>>>running test 395"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.95 > ../outputs/output.${1}/t395
echo ">>>>>>>>running test 396"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.96 > ../outputs/output.${1}/t396
echo ">>>>>>>>running test 397"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.97 > ../outputs/output.${1}/t397
echo ">>>>>>>>running test 398"
../source/schedule.exe  3 3 3  < ../inputs/input/tc.98 > ../outputs/output.${1}/t398
echo ">>>>>>>>running test 399"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.99 > ../outputs/output.${1}/t399
echo ">>>>>>>>running test 400"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.100 > ../outputs/output.${1}/t400
echo ">>>>>>>>running test 401"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.101 > ../outputs/output.${1}/t401
echo ">>>>>>>>running test 402"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.102 > ../outputs/output.${1}/t402
echo ">>>>>>>>running test 403"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.103 > ../outputs/output.${1}/t403
echo ">>>>>>>>running test 404"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.104 > ../outputs/output.${1}/t404
echo ">>>>>>>>running test 405"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.105 > ../outputs/output.${1}/t405
echo ">>>>>>>>running test 406"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.106 > ../outputs/output.${1}/t406
echo ">>>>>>>>running test 407"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.107 > ../outputs/output.${1}/t407
echo ">>>>>>>>running test 408"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.108 > ../outputs/output.${1}/t408
echo ">>>>>>>>running test 409"
../source/schedule.exe  1 3 3  < ../inputs/input/tc.109 > ../outputs/output.${1}/t409
echo ">>>>>>>>running test 410"
../source/schedule.exe  3 4 1  < ../inputs/input/tc.110 > ../outputs/output.${1}/t410
echo ">>>>>>>>running test 411"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.111 > ../outputs/output.${1}/t411
echo ">>>>>>>>running test 412"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.112 > ../outputs/output.${1}/t412
echo ">>>>>>>>running test 413"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.113 > ../outputs/output.${1}/t413
echo ">>>>>>>>running test 414"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.114 > ../outputs/output.${1}/t414
echo ">>>>>>>>running test 415"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.115 > ../outputs/output.${1}/t415
echo ">>>>>>>>running test 416"
../source/schedule.exe  1 4 1  < ../inputs/input/tc.116 > ../outputs/output.${1}/t416
echo ">>>>>>>>running test 417"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.117 > ../outputs/output.${1}/t417
echo ">>>>>>>>running test 418"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.118 > ../outputs/output.${1}/t418
echo ">>>>>>>>running test 419"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.119 > ../outputs/output.${1}/t419
echo ">>>>>>>>running test 420"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.120 > ../outputs/output.${1}/t420
echo ">>>>>>>>running test 421"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.121 > ../outputs/output.${1}/t421
echo ">>>>>>>>running test 422"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.122 > ../outputs/output.${1}/t422
echo ">>>>>>>>running test 423"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.123 > ../outputs/output.${1}/t423
echo ">>>>>>>>running test 424"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.124 > ../outputs/output.${1}/t424
echo ">>>>>>>>running test 425"
../source/schedule.exe  2 2 4  < ../inputs/input/tc.125 > ../outputs/output.${1}/t425
echo ">>>>>>>>running test 426"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.126 > ../outputs/output.${1}/t426
echo ">>>>>>>>running test 427"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.127 > ../outputs/output.${1}/t427
echo ">>>>>>>>running test 428"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.128 > ../outputs/output.${1}/t428
echo ">>>>>>>>running test 429"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.129 > ../outputs/output.${1}/t429
echo ">>>>>>>>running test 430"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.130 > ../outputs/output.${1}/t430
echo ">>>>>>>>running test 431"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.131 > ../outputs/output.${1}/t431
echo ">>>>>>>>running test 432"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.132 > ../outputs/output.${1}/t432
echo ">>>>>>>>running test 433"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.133 > ../outputs/output.${1}/t433
echo ">>>>>>>>running test 434"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.134 > ../outputs/output.${1}/t434
echo ">>>>>>>>running test 435"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.135 > ../outputs/output.${1}/t435
echo ">>>>>>>>running test 436"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.136 > ../outputs/output.${1}/t436
echo ">>>>>>>>running test 437"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.137 > ../outputs/output.${1}/t437
echo ">>>>>>>>running test 438"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.138 > ../outputs/output.${1}/t438
echo ">>>>>>>>running test 439"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.139 > ../outputs/output.${1}/t439
echo ">>>>>>>>running test 440"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.140 > ../outputs/output.${1}/t440
echo ">>>>>>>>running test 441"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.141 > ../outputs/output.${1}/t441
echo ">>>>>>>>running test 442"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.142 > ../outputs/output.${1}/t442
echo ">>>>>>>>running test 443"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.143 > ../outputs/output.${1}/t443
echo ">>>>>>>>running test 444"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.144 > ../outputs/output.${1}/t444
echo ">>>>>>>>running test 445"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.145 > ../outputs/output.${1}/t445
echo ">>>>>>>>running test 446"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.146 > ../outputs/output.${1}/t446
echo ">>>>>>>>running test 447"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.147 > ../outputs/output.${1}/t447
echo ">>>>>>>>running test 448"
../source/schedule.exe  2 2 3  < ../inputs/input/tc.148 > ../outputs/output.${1}/t448
echo ">>>>>>>>running test 449"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.149 > ../outputs/output.${1}/t449
echo ">>>>>>>>running test 450"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.150 > ../outputs/output.${1}/t450
echo ">>>>>>>>running test 451"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.151 > ../outputs/output.${1}/t451
echo ">>>>>>>>running test 452"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.152 > ../outputs/output.${1}/t452
echo ">>>>>>>>running test 453"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.153 > ../outputs/output.${1}/t453
echo ">>>>>>>>running test 454"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.154 > ../outputs/output.${1}/t454
echo ">>>>>>>>running test 455"
../source/schedule.exe  1 4 3  < ../inputs/input/tc.155 > ../outputs/output.${1}/t455
echo ">>>>>>>>running test 456"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.156 > ../outputs/output.${1}/t456
echo ">>>>>>>>running test 457"
../source/schedule.exe  2 1 4  < ../inputs/input/tc.157 > ../outputs/output.${1}/t457
echo ">>>>>>>>running test 458"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.158 > ../outputs/output.${1}/t458
echo ">>>>>>>>running test 459"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.159 > ../outputs/output.${1}/t459
echo ">>>>>>>>running test 460"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.160 > ../outputs/output.${1}/t460
echo ">>>>>>>>running test 461"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.161 > ../outputs/output.${1}/t461
echo ">>>>>>>>running test 462"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.162 > ../outputs/output.${1}/t462
echo ">>>>>>>>running test 463"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.163 > ../outputs/output.${1}/t463
echo ">>>>>>>>running test 464"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.164 > ../outputs/output.${1}/t464
echo ">>>>>>>>running test 465"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.165 > ../outputs/output.${1}/t465
echo ">>>>>>>>running test 466"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.166 > ../outputs/output.${1}/t466
echo ">>>>>>>>running test 467"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.167 > ../outputs/output.${1}/t467
echo ">>>>>>>>running test 468"
../source/schedule.exe  4 3 1  < ../inputs/input/tc.168 > ../outputs/output.${1}/t468
echo ">>>>>>>>running test 469"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.169 > ../outputs/output.${1}/t469
echo ">>>>>>>>running test 470"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.170 > ../outputs/output.${1}/t470
echo ">>>>>>>>running test 471"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.171 > ../outputs/output.${1}/t471
echo ">>>>>>>>running test 472"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.172 > ../outputs/output.${1}/t472
echo ">>>>>>>>running test 473"
../source/schedule.exe  4 3 1  < ../inputs/input/tc.173 > ../outputs/output.${1}/t473
echo ">>>>>>>>running test 474"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.174 > ../outputs/output.${1}/t474
echo ">>>>>>>>running test 475"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.175 > ../outputs/output.${1}/t475
echo ">>>>>>>>running test 476"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.176 > ../outputs/output.${1}/t476
echo ">>>>>>>>running test 477"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.177 > ../outputs/output.${1}/t477
echo ">>>>>>>>running test 478"
../source/schedule.exe  3 3 1  < ../inputs/input/tc.178 > ../outputs/output.${1}/t478
echo ">>>>>>>>running test 479"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.179 > ../outputs/output.${1}/t479
echo ">>>>>>>>running test 480"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.180 > ../outputs/output.${1}/t480
echo ">>>>>>>>running test 481"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.181 > ../outputs/output.${1}/t481
echo ">>>>>>>>running test 482"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.182 > ../outputs/output.${1}/t482
echo ">>>>>>>>running test 483"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.183 > ../outputs/output.${1}/t483
echo ">>>>>>>>running test 484"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.184 > ../outputs/output.${1}/t484
echo ">>>>>>>>running test 485"
../source/schedule.exe  3 1 1  < ../inputs/input/tc.185 > ../outputs/output.${1}/t485
echo ">>>>>>>>running test 486"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.186 > ../outputs/output.${1}/t486
echo ">>>>>>>>running test 487"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.187 > ../outputs/output.${1}/t487
echo ">>>>>>>>running test 488"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.188 > ../outputs/output.${1}/t488
echo ">>>>>>>>running test 489"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.189 > ../outputs/output.${1}/t489
echo ">>>>>>>>running test 490"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.190 > ../outputs/output.${1}/t490
echo ">>>>>>>>running test 491"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.191 > ../outputs/output.${1}/t491
echo ">>>>>>>>running test 492"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.192 > ../outputs/output.${1}/t492
echo ">>>>>>>>running test 493"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.193 > ../outputs/output.${1}/t493
echo ">>>>>>>>running test 494"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.194 > ../outputs/output.${1}/t494
echo ">>>>>>>>running test 495"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.195 > ../outputs/output.${1}/t495
echo ">>>>>>>>running test 496"
../source/schedule.exe  4 3 2  < ../inputs/input/tc.196 > ../outputs/output.${1}/t496
echo ">>>>>>>>running test 497"
../source/schedule.exe  1 2 2  < ../inputs/input/tc.197 > ../outputs/output.${1}/t497
echo ">>>>>>>>running test 498"
../source/schedule.exe  2 2 4  < ../inputs/input/tc.198 > ../outputs/output.${1}/t498
echo ">>>>>>>>running test 499"
../source/schedule.exe  1 4 1  < ../inputs/input/tc.199 > ../outputs/output.${1}/t499
echo ">>>>>>>>running test 500"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.200 > ../outputs/output.${1}/t500
echo ">>>>>>>>running test 501"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.201 > ../outputs/output.${1}/t501
echo ">>>>>>>>running test 502"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.202 > ../outputs/output.${1}/t502
echo ">>>>>>>>running test 503"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.203 > ../outputs/output.${1}/t503
echo ">>>>>>>>running test 504"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.204 > ../outputs/output.${1}/t504
echo ">>>>>>>>running test 505"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.205 > ../outputs/output.${1}/t505
echo ">>>>>>>>running test 506"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.206 > ../outputs/output.${1}/t506
echo ">>>>>>>>running test 507"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.207 > ../outputs/output.${1}/t507
echo ">>>>>>>>running test 508"
../source/schedule.exe  3 2 4  < ../inputs/input/tc.208 > ../outputs/output.${1}/t508
echo ">>>>>>>>running test 509"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.209 > ../outputs/output.${1}/t509
echo ">>>>>>>>running test 510"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.210 > ../outputs/output.${1}/t510
echo ">>>>>>>>running test 511"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.211 > ../outputs/output.${1}/t511
echo ">>>>>>>>running test 512"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.212 > ../outputs/output.${1}/t512
echo ">>>>>>>>running test 513"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.213 > ../outputs/output.${1}/t513
echo ">>>>>>>>running test 514"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.214 > ../outputs/output.${1}/t514
echo ">>>>>>>>running test 515"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.215 > ../outputs/output.${1}/t515
echo ">>>>>>>>running test 516"
../source/schedule.exe  4 3 2  < ../inputs/input/tc.216 > ../outputs/output.${1}/t516
echo ">>>>>>>>running test 517"
../source/schedule.exe  2 3 2  < ../inputs/input/tc.217 > ../outputs/output.${1}/t517
echo ">>>>>>>>running test 518"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.218 > ../outputs/output.${1}/t518
echo ">>>>>>>>running test 519"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.219 > ../outputs/output.${1}/t519
echo ">>>>>>>>running test 520"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.220 > ../outputs/output.${1}/t520
echo ">>>>>>>>running test 521"
../source/schedule.exe  3 3 3  < ../inputs/input/tc.221 > ../outputs/output.${1}/t521
echo ">>>>>>>>running test 522"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.222 > ../outputs/output.${1}/t522
echo ">>>>>>>>running test 523"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.223 > ../outputs/output.${1}/t523
echo ">>>>>>>>running test 524"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.224 > ../outputs/output.${1}/t524
echo ">>>>>>>>running test 525"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.225 > ../outputs/output.${1}/t525
echo ">>>>>>>>running test 526"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.226 > ../outputs/output.${1}/t526
echo ">>>>>>>>running test 527"
../source/schedule.exe  1 3 3  < ../inputs/input/tc.227 > ../outputs/output.${1}/t527
echo ">>>>>>>>running test 528"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.228 > ../outputs/output.${1}/t528
echo ">>>>>>>>running test 529"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.229 > ../outputs/output.${1}/t529
echo ">>>>>>>>running test 530"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.230 > ../outputs/output.${1}/t530
echo ">>>>>>>>running test 531"
../source/schedule.exe  4 3 4  < ../inputs/input/tc.231 > ../outputs/output.${1}/t531
echo ">>>>>>>>running test 532"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.232 > ../outputs/output.${1}/t532
echo ">>>>>>>>running test 533"
../source/schedule.exe  3 3 4  < ../inputs/input/tc.233 > ../outputs/output.${1}/t533
echo ">>>>>>>>running test 534"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.234 > ../outputs/output.${1}/t534
echo ">>>>>>>>running test 535"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.235 > ../outputs/output.${1}/t535
echo ">>>>>>>>running test 536"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.236 > ../outputs/output.${1}/t536
echo ">>>>>>>>running test 537"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.237 > ../outputs/output.${1}/t537
echo ">>>>>>>>running test 538"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.238 > ../outputs/output.${1}/t538
echo ">>>>>>>>running test 539"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.239 > ../outputs/output.${1}/t539
echo ">>>>>>>>running test 540"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.240 > ../outputs/output.${1}/t540
echo ">>>>>>>>running test 541"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.241 > ../outputs/output.${1}/t541
echo ">>>>>>>>running test 542"
../source/schedule.exe  4 4 4  < ../inputs/input/tc.242 > ../outputs/output.${1}/t542
echo ">>>>>>>>running test 543"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.243 > ../outputs/output.${1}/t543
echo ">>>>>>>>running test 544"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.244 > ../outputs/output.${1}/t544
echo ">>>>>>>>running test 545"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.245 > ../outputs/output.${1}/t545
echo ">>>>>>>>running test 546"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.246 > ../outputs/output.${1}/t546
echo ">>>>>>>>running test 547"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.247 > ../outputs/output.${1}/t547
echo ">>>>>>>>running test 548"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.248 > ../outputs/output.${1}/t548
echo ">>>>>>>>running test 549"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.249 > ../outputs/output.${1}/t549
echo ">>>>>>>>running test 550"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.250 > ../outputs/output.${1}/t550
echo ">>>>>>>>running test 551"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.251 > ../outputs/output.${1}/t551
echo ">>>>>>>>running test 552"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.252 > ../outputs/output.${1}/t552
echo ">>>>>>>>running test 553"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.253 > ../outputs/output.${1}/t553
echo ">>>>>>>>running test 554"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.254 > ../outputs/output.${1}/t554
echo ">>>>>>>>running test 555"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.255 > ../outputs/output.${1}/t555
echo ">>>>>>>>running test 556"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.256 > ../outputs/output.${1}/t556
echo ">>>>>>>>running test 557"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.257 > ../outputs/output.${1}/t557
echo ">>>>>>>>running test 558"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.258 > ../outputs/output.${1}/t558
echo ">>>>>>>>running test 559"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.259 > ../outputs/output.${1}/t559
echo ">>>>>>>>running test 560"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.260 > ../outputs/output.${1}/t560
echo ">>>>>>>>running test 561"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.261 > ../outputs/output.${1}/t561
echo ">>>>>>>>running test 562"
../source/schedule.exe  2 3 4  < ../inputs/input/tc.262 > ../outputs/output.${1}/t562
echo ">>>>>>>>running test 563"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.263 > ../outputs/output.${1}/t563
echo ">>>>>>>>running test 564"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.264 > ../outputs/output.${1}/t564
echo ">>>>>>>>running test 565"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.265 > ../outputs/output.${1}/t565
echo ">>>>>>>>running test 566"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.266 > ../outputs/output.${1}/t566
echo ">>>>>>>>running test 567"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.267 > ../outputs/output.${1}/t567
echo ">>>>>>>>running test 568"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.268 > ../outputs/output.${1}/t568
echo ">>>>>>>>running test 569"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.269 > ../outputs/output.${1}/t569
echo ">>>>>>>>running test 570"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.270 > ../outputs/output.${1}/t570
echo ">>>>>>>>running test 571"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.271 > ../outputs/output.${1}/t571
echo ">>>>>>>>running test 572"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.272 > ../outputs/output.${1}/t572
echo ">>>>>>>>running test 573"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.273 > ../outputs/output.${1}/t573
echo ">>>>>>>>running test 574"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.274 > ../outputs/output.${1}/t574
echo ">>>>>>>>running test 575"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.275 > ../outputs/output.${1}/t575
echo ">>>>>>>>running test 576"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.276 > ../outputs/output.${1}/t576
echo ">>>>>>>>running test 577"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.277 > ../outputs/output.${1}/t577
echo ">>>>>>>>running test 578"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.278 > ../outputs/output.${1}/t578
echo ">>>>>>>>running test 579"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.279 > ../outputs/output.${1}/t579
echo ">>>>>>>>running test 580"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.280 > ../outputs/output.${1}/t580
echo ">>>>>>>>running test 581"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.281 > ../outputs/output.${1}/t581
echo ">>>>>>>>running test 582"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.282 > ../outputs/output.${1}/t582
echo ">>>>>>>>running test 583"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.283 > ../outputs/output.${1}/t583
echo ">>>>>>>>running test 584"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.284 > ../outputs/output.${1}/t584
echo ">>>>>>>>running test 585"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.285 > ../outputs/output.${1}/t585
echo ">>>>>>>>running test 586"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.286 > ../outputs/output.${1}/t586
echo ">>>>>>>>running test 587"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.287 > ../outputs/output.${1}/t587
echo ">>>>>>>>running test 588"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.288 > ../outputs/output.${1}/t588
echo ">>>>>>>>running test 589"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.289 > ../outputs/output.${1}/t589
echo ">>>>>>>>running test 590"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.290 > ../outputs/output.${1}/t590
echo ">>>>>>>>running test 591"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.291 > ../outputs/output.${1}/t591
echo ">>>>>>>>running test 592"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.292 > ../outputs/output.${1}/t592
echo ">>>>>>>>running test 593"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.293 > ../outputs/output.${1}/t593
echo ">>>>>>>>running test 594"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.294 > ../outputs/output.${1}/t594
echo ">>>>>>>>running test 595"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.295 > ../outputs/output.${1}/t595
echo ">>>>>>>>running test 596"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.296 > ../outputs/output.${1}/t596
echo ">>>>>>>>running test 597"
../source/schedule.exe  1 4 2  < ../inputs/input/tc.297 > ../outputs/output.${1}/t597
echo ">>>>>>>>running test 598"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.298 > ../outputs/output.${1}/t598
echo ">>>>>>>>running test 599"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.299 > ../outputs/output.${1}/t599
echo ">>>>>>>>running test 600"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.300 > ../outputs/output.${1}/t600
echo ">>>>>>>>running test 601"
../source/schedule.exe  5 4 2  < ../inputs/input/dat000 > ../outputs/output.${1}/t601
echo ">>>>>>>>running test 602"
../source/schedule.exe  2 5 2  < ../inputs/input/dat001 > ../outputs/output.${1}/t602
echo ">>>>>>>>running test 603"
../source/schedule.exe  0 3 2  < ../inputs/input/dat002 > ../outputs/output.${1}/t603
echo ">>>>>>>>running test 604"
../source/schedule.exe  5 3 2  < ../inputs/input/dat003 > ../outputs/output.${1}/t604
echo ">>>>>>>>running test 605"
../source/schedule.exe  3 2 1  < ../inputs/input/dat004 > ../outputs/output.${1}/t605
echo ">>>>>>>>running test 606"
../source/schedule.exe  1 1 5  < ../inputs/input/dat005 > ../outputs/output.${1}/t606
echo ">>>>>>>>running test 607"
../source/schedule.exe  2 0 4  < ../inputs/input/dat006 > ../outputs/output.${1}/t607
echo ">>>>>>>>running test 608"
../source/schedule.exe  2 4 4  < ../inputs/input/dat007 > ../outputs/output.${1}/t608
echo ">>>>>>>>running test 609"
../source/schedule.exe  1 3 2  < ../inputs/input/dat008 > ../outputs/output.${1}/t609
echo ">>>>>>>>running test 610"
../source/schedule.exe  5 0 3  < ../inputs/input/dat009 > ../outputs/output.${1}/t610
echo ">>>>>>>>running test 611"
../source/schedule.exe  3 2 3  < ../inputs/input/dat010 > ../outputs/output.${1}/t611
echo ">>>>>>>>running test 612"
../source/schedule.exe  2 5 4  < ../inputs/input/dat011 > ../outputs/output.${1}/t612
echo ">>>>>>>>running test 613"
../source/schedule.exe  3 4 0  < ../inputs/input/dat012 > ../outputs/output.${1}/t613
echo ">>>>>>>>running test 614"
../source/schedule.exe  3 4 2  < ../inputs/input/dat013 > ../outputs/output.${1}/t614
echo ">>>>>>>>running test 615"
../source/schedule.exe  1 1 1  < ../inputs/input/dat014 > ../outputs/output.${1}/t615
echo ">>>>>>>>running test 616"
../source/schedule.exe  1 5 1  < ../inputs/input/dat015 > ../outputs/output.${1}/t616
echo ">>>>>>>>running test 617"
../source/schedule.exe  3 2 3  < ../inputs/input/dat016 > ../outputs/output.${1}/t617
echo ">>>>>>>>running test 618"
../source/schedule.exe  2 4 2  < ../inputs/input/dat017 > ../outputs/output.${1}/t618
echo ">>>>>>>>running test 619"
../source/schedule.exe  1 5 2  < ../inputs/input/dat018 > ../outputs/output.${1}/t619
echo ">>>>>>>>running test 620"
../source/schedule.exe  0 0 5  < ../inputs/input/dat019 > ../outputs/output.${1}/t620
echo ">>>>>>>>running test 621"
../source/schedule.exe  3 4 3  < ../inputs/input/dat020 > ../outputs/output.${1}/t621
echo ">>>>>>>>running test 622"
../source/schedule.exe  4 1 3  < ../inputs/input/dat021 > ../outputs/output.${1}/t622
echo ">>>>>>>>running test 623"
../source/schedule.exe  0 3 0  < ../inputs/input/dat022 > ../outputs/output.${1}/t623
echo ">>>>>>>>running test 624"
../source/schedule.exe  1 1 3  < ../inputs/input/dat023 > ../outputs/output.${1}/t624
echo ">>>>>>>>running test 625"
../source/schedule.exe  5 5 1  < ../inputs/input/dat024 > ../outputs/output.${1}/t625
echo ">>>>>>>>running test 626"
../source/schedule.exe  2 1 3  < ../inputs/input/dat025 > ../outputs/output.${1}/t626
echo ">>>>>>>>running test 627"
../source/schedule.exe  2 2 5  < ../inputs/input/dat026 > ../outputs/output.${1}/t627
echo ">>>>>>>>running test 628"
../source/schedule.exe  5 1 1  < ../inputs/input/dat027 > ../outputs/output.${1}/t628
echo ">>>>>>>>running test 629"
../source/schedule.exe  2 5 1  < ../inputs/input/dat028 > ../outputs/output.${1}/t629
echo ">>>>>>>>running test 630"
../source/schedule.exe  1 1 3  < ../inputs/input/dat029 > ../outputs/output.${1}/t630
echo ">>>>>>>>running test 631"
../source/schedule.exe  5 3 0  < ../inputs/input/dat030 > ../outputs/output.${1}/t631
echo ">>>>>>>>running test 632"
../source/schedule.exe  3 4 1  < ../inputs/input/dat031 > ../outputs/output.${1}/t632
echo ">>>>>>>>running test 633"
../source/schedule.exe  2 0 3  < ../inputs/input/dat032 > ../outputs/output.${1}/t633
echo ">>>>>>>>running test 634"
../source/schedule.exe  2 2 1  < ../inputs/input/dat033 > ../outputs/output.${1}/t634
echo ">>>>>>>>running test 635"
../source/schedule.exe  2 0 4  < ../inputs/input/dat034 > ../outputs/output.${1}/t635
echo ">>>>>>>>running test 636"
../source/schedule.exe  4 2 4  < ../inputs/input/dat035 > ../outputs/output.${1}/t636
echo ">>>>>>>>running test 637"
../source/schedule.exe  5 1 0  < ../inputs/input/dat036 > ../outputs/output.${1}/t637
echo ">>>>>>>>running test 638"
../source/schedule.exe  1 0 3  < ../inputs/input/dat037 > ../outputs/output.${1}/t638
echo ">>>>>>>>running test 639"
../source/schedule.exe  2 5 5  < ../inputs/input/dat038 > ../outputs/output.${1}/t639
echo ">>>>>>>>running test 640"
../source/schedule.exe  5 4 0  < ../inputs/input/dat039 > ../outputs/output.${1}/t640
echo ">>>>>>>>running test 641"
../source/schedule.exe  4 2 2  < ../inputs/input/dat040 > ../outputs/output.${1}/t641
echo ">>>>>>>>running test 642"
../source/schedule.exe  4 4 3  < ../inputs/input/dat041 > ../outputs/output.${1}/t642
echo ">>>>>>>>running test 643"
../source/schedule.exe  3 3 4  < ../inputs/input/dat042 > ../outputs/output.${1}/t643
echo ">>>>>>>>running test 644"
../source/schedule.exe  1 1 4  < ../inputs/input/dat043 > ../outputs/output.${1}/t644
echo ">>>>>>>>running test 645"
../source/schedule.exe  2 2 1  < ../inputs/input/dat044 > ../outputs/output.${1}/t645
echo ">>>>>>>>running test 646"
../source/schedule.exe  1 1 3  < ../inputs/input/dat045 > ../outputs/output.${1}/t646
echo ">>>>>>>>running test 647"
../source/schedule.exe  3 3 4  < ../inputs/input/dat046 > ../outputs/output.${1}/t647
echo ">>>>>>>>running test 648"
../source/schedule.exe  5 2 0  < ../inputs/input/dat047 > ../outputs/output.${1}/t648
echo ">>>>>>>>running test 649"
../source/schedule.exe  3 4 1  < ../inputs/input/dat048 > ../outputs/output.${1}/t649
echo ">>>>>>>>running test 650"
../source/schedule.exe  0 1 1  < ../inputs/input/dat049 > ../outputs/output.${1}/t650
echo ">>>>>>>>running test 651"
../source/schedule.exe  1 1 2  < ../inputs/input/dat050 > ../outputs/output.${1}/t651
echo ">>>>>>>>running test 652"
../source/schedule.exe  4 4 5  < ../inputs/input/dat051 > ../outputs/output.${1}/t652
echo ">>>>>>>>running test 653"
../source/schedule.exe  4 4 2  < ../inputs/input/dat052 > ../outputs/output.${1}/t653
echo ">>>>>>>>running test 654"
../source/schedule.exe  5 0 3  < ../inputs/input/dat053 > ../outputs/output.${1}/t654
echo ">>>>>>>>running test 655"
../source/schedule.exe  4 1 2  < ../inputs/input/dat054 > ../outputs/output.${1}/t655
echo ">>>>>>>>running test 656"
../source/schedule.exe  1 5 5  < ../inputs/input/dat055 > ../outputs/output.${1}/t656
echo ">>>>>>>>running test 657"
../source/schedule.exe  0 3 1  < ../inputs/input/dat056 > ../outputs/output.${1}/t657
echo ">>>>>>>>running test 658"
../source/schedule.exe  0 4 3  < ../inputs/input/dat057 > ../outputs/output.${1}/t658
echo ">>>>>>>>running test 659"
../source/schedule.exe  1 3 2  < ../inputs/input/dat058 > ../outputs/output.${1}/t659
echo ">>>>>>>>running test 660"
../source/schedule.exe  4 0 1  < ../inputs/input/dat059 > ../outputs/output.${1}/t660
echo ">>>>>>>>running test 661"
../source/schedule.exe  2 0 3  < ../inputs/input/dat060 > ../outputs/output.${1}/t661
echo ">>>>>>>>running test 662"
../source/schedule.exe  4 4 5  < ../inputs/input/dat061 > ../outputs/output.${1}/t662
echo ">>>>>>>>running test 663"
../source/schedule.exe  5 5 0  < ../inputs/input/dat062 > ../outputs/output.${1}/t663
echo ">>>>>>>>running test 664"
../source/schedule.exe  1 0 1  < ../inputs/input/dat063 > ../outputs/output.${1}/t664
echo ">>>>>>>>running test 665"
../source/schedule.exe  1 5 1  < ../inputs/input/dat064 > ../outputs/output.${1}/t665
echo ">>>>>>>>running test 666"
../source/schedule.exe  3 2 0  < ../inputs/input/dat065 > ../outputs/output.${1}/t666
echo ">>>>>>>>running test 667"
../source/schedule.exe  0 3 2  < ../inputs/input/dat066 > ../outputs/output.${1}/t667
echo ">>>>>>>>running test 668"
../source/schedule.exe  4 2 2  < ../inputs/input/dat067 > ../outputs/output.${1}/t668
echo ">>>>>>>>running test 669"
../source/schedule.exe  3 5 1  < ../inputs/input/dat068 > ../outputs/output.${1}/t669
echo ">>>>>>>>running test 670"
../source/schedule.exe  0 4 3  < ../inputs/input/dat069 > ../outputs/output.${1}/t670
echo ">>>>>>>>running test 671"
../source/schedule.exe  1 0 1  < ../inputs/input/dat070 > ../outputs/output.${1}/t671
echo ">>>>>>>>running test 672"
../source/schedule.exe  1 2 2  < ../inputs/input/dat071 > ../outputs/output.${1}/t672
echo ">>>>>>>>running test 673"
../source/schedule.exe  5 1 0  < ../inputs/input/dat072 > ../outputs/output.${1}/t673
echo ">>>>>>>>running test 674"
../source/schedule.exe  4 2 1  < ../inputs/input/dat073 > ../outputs/output.${1}/t674
echo ">>>>>>>>running test 675"
../source/schedule.exe  5 3 0  < ../inputs/input/dat074 > ../outputs/output.${1}/t675
echo ">>>>>>>>running test 676"
../source/schedule.exe  5 4 3  < ../inputs/input/dat075 > ../outputs/output.${1}/t676
echo ">>>>>>>>running test 677"
../source/schedule.exe  3 3 4  < ../inputs/input/dat076 > ../outputs/output.${1}/t677
echo ">>>>>>>>running test 678"
../source/schedule.exe  1 2 1  < ../inputs/input/dat077 > ../outputs/output.${1}/t678
echo ">>>>>>>>running test 679"
../source/schedule.exe  4 3 3  < ../inputs/input/dat078 > ../outputs/output.${1}/t679
echo ">>>>>>>>running test 680"
../source/schedule.exe  0 1 0  < ../inputs/input/dat079 > ../outputs/output.${1}/t680
echo ">>>>>>>>running test 681"
../source/schedule.exe  0 5 5  < ../inputs/input/dat080 > ../outputs/output.${1}/t681
echo ">>>>>>>>running test 682"
../source/schedule.exe  3 1 5  < ../inputs/input/dat081 > ../outputs/output.${1}/t682
echo ">>>>>>>>running test 683"
../source/schedule.exe  0 5 1  < ../inputs/input/dat082 > ../outputs/output.${1}/t683
echo ">>>>>>>>running test 684"
../source/schedule.exe  1 1 3  < ../inputs/input/dat083 > ../outputs/output.${1}/t684
echo ">>>>>>>>running test 685"
../source/schedule.exe  3 1 3  < ../inputs/input/dat084 > ../outputs/output.${1}/t685
echo ">>>>>>>>running test 686"
../source/schedule.exe  4 4 0  < ../inputs/input/dat085 > ../outputs/output.${1}/t686
echo ">>>>>>>>running test 687"
../source/schedule.exe  1 0 3  < ../inputs/input/dat086 > ../outputs/output.${1}/t687
echo ">>>>>>>>running test 688"
../source/schedule.exe  5 1 0  < ../inputs/input/dat087 > ../outputs/output.${1}/t688
echo ">>>>>>>>running test 689"
../source/schedule.exe  0 2 2  < ../inputs/input/dat088 > ../outputs/output.${1}/t689
echo ">>>>>>>>running test 690"
../source/schedule.exe  0 4 4  < ../inputs/input/dat089 > ../outputs/output.${1}/t690
echo ">>>>>>>>running test 691"
../source/schedule.exe  5 5 4  < ../inputs/input/dat090 > ../outputs/output.${1}/t691
echo ">>>>>>>>running test 692"
../source/schedule.exe  0 2 1  < ../inputs/input/dat091 > ../outputs/output.${1}/t692
echo ">>>>>>>>running test 693"
../source/schedule.exe  2 5 2  < ../inputs/input/dat092 > ../outputs/output.${1}/t693
echo ">>>>>>>>running test 694"
../source/schedule.exe  1 1 5  < ../inputs/input/dat093 > ../outputs/output.${1}/t694
echo ">>>>>>>>running test 695"
../source/schedule.exe  2 3 1  < ../inputs/input/dat094 > ../outputs/output.${1}/t695
echo ">>>>>>>>running test 696"
../source/schedule.exe  5 1 0  < ../inputs/input/dat095 > ../outputs/output.${1}/t696
echo ">>>>>>>>running test 697"
../source/schedule.exe  5 4 1  < ../inputs/input/dat096 > ../outputs/output.${1}/t697
echo ">>>>>>>>running test 698"
../source/schedule.exe  5 5 1  < ../inputs/input/dat097 > ../outputs/output.${1}/t698
echo ">>>>>>>>running test 699"
../source/schedule.exe  3 2 1  < ../inputs/input/dat098 > ../outputs/output.${1}/t699
echo ">>>>>>>>running test 700"
../source/schedule.exe  0 5 3  < ../inputs/input/dat099 > ../outputs/output.${1}/t700
echo ">>>>>>>>running test 701"
../source/schedule.exe  0 1 2  < ../inputs/input/dat100 > ../outputs/output.${1}/t701
echo ">>>>>>>>running test 702"
../source/schedule.exe  2 5 0  < ../inputs/input/dat101 > ../outputs/output.${1}/t702
echo ">>>>>>>>running test 703"
../source/schedule.exe  1 2 3  < ../inputs/input/dat102 > ../outputs/output.${1}/t703
echo ">>>>>>>>running test 704"
../source/schedule.exe  2 4 4  < ../inputs/input/dat103 > ../outputs/output.${1}/t704
echo ">>>>>>>>running test 705"
../source/schedule.exe  2 0 0  < ../inputs/input/dat104 > ../outputs/output.${1}/t705
echo ">>>>>>>>running test 706"
../source/schedule.exe  2 4 1  < ../inputs/input/dat105 > ../outputs/output.${1}/t706
echo ">>>>>>>>running test 707"
../source/schedule.exe  5 2 4  < ../inputs/input/dat106 > ../outputs/output.${1}/t707
echo ">>>>>>>>running test 708"
../source/schedule.exe  0 5 3  < ../inputs/input/dat107 > ../outputs/output.${1}/t708
echo ">>>>>>>>running test 709"
../source/schedule.exe  3 2 2  < ../inputs/input/dat108 > ../outputs/output.${1}/t709
echo ">>>>>>>>running test 710"
../source/schedule.exe  3 5 5  < ../inputs/input/dat109 > ../outputs/output.${1}/t710
echo ">>>>>>>>running test 711"
../source/schedule.exe  5 0 3  < ../inputs/input/dat110 > ../outputs/output.${1}/t711
echo ">>>>>>>>running test 712"
../source/schedule.exe  2 4 5  < ../inputs/input/dat111 > ../outputs/output.${1}/t712
echo ">>>>>>>>running test 713"
../source/schedule.exe  3 5 1  < ../inputs/input/dat112 > ../outputs/output.${1}/t713
echo ">>>>>>>>running test 714"
../source/schedule.exe  0 3 1  < ../inputs/input/dat113 > ../outputs/output.${1}/t714
echo ">>>>>>>>running test 715"
../source/schedule.exe  1 1 3  < ../inputs/input/dat114 > ../outputs/output.${1}/t715
echo ">>>>>>>>running test 716"
../source/schedule.exe  1 5 4  < ../inputs/input/dat115 > ../outputs/output.${1}/t716
echo ">>>>>>>>running test 717"
../source/schedule.exe  3 1 2  < ../inputs/input/dat116 > ../outputs/output.${1}/t717
echo ">>>>>>>>running test 718"
../source/schedule.exe  1 5 5  < ../inputs/input/dat117 > ../outputs/output.${1}/t718
echo ">>>>>>>>running test 719"
../source/schedule.exe  1 3 5  < ../inputs/input/dat118 > ../outputs/output.${1}/t719
echo ">>>>>>>>running test 720"
../source/schedule.exe  2 1 1  < ../inputs/input/dat119 > ../outputs/output.${1}/t720
echo ">>>>>>>>running test 721"
../source/schedule.exe  4 2 3  < ../inputs/input/dat120 > ../outputs/output.${1}/t721
echo ">>>>>>>>running test 722"
../source/schedule.exe  4 4 1  < ../inputs/input/dat121 > ../outputs/output.${1}/t722
echo ">>>>>>>>running test 723"
../source/schedule.exe  1 1 2  < ../inputs/input/dat122 > ../outputs/output.${1}/t723
echo ">>>>>>>>running test 724"
../source/schedule.exe  1 4 3  < ../inputs/input/dat123 > ../outputs/output.${1}/t724
echo ">>>>>>>>running test 725"
../source/schedule.exe  0 1 4  < ../inputs/input/dat124 > ../outputs/output.${1}/t725
echo ">>>>>>>>running test 726"
../source/schedule.exe  0 4 3  < ../inputs/input/dat125 > ../outputs/output.${1}/t726
echo ">>>>>>>>running test 727"
../source/schedule.exe  3 5 5  < ../inputs/input/dat126 > ../outputs/output.${1}/t727
echo ">>>>>>>>running test 728"
../source/schedule.exe  5 3 5  < ../inputs/input/dat127 > ../outputs/output.${1}/t728
echo ">>>>>>>>running test 729"
../source/schedule.exe  1 5 1  < ../inputs/input/dat128 > ../outputs/output.${1}/t729
echo ">>>>>>>>running test 730"
../source/schedule.exe  0 5 1  < ../inputs/input/dat129 > ../outputs/output.${1}/t730
echo ">>>>>>>>running test 731"
../source/schedule.exe  4 3 1  < ../inputs/input/dat130 > ../outputs/output.${1}/t731
echo ">>>>>>>>running test 732"
../source/schedule.exe  4 4 4  < ../inputs/input/dat131 > ../outputs/output.${1}/t732
echo ">>>>>>>>running test 733"
../source/schedule.exe  4 2 3  < ../inputs/input/dat132 > ../outputs/output.${1}/t733
echo ">>>>>>>>running test 734"
../source/schedule.exe  2 3 3  < ../inputs/input/dat133 > ../outputs/output.${1}/t734
echo ">>>>>>>>running test 735"
../source/schedule.exe  0 4 5  < ../inputs/input/dat134 > ../outputs/output.${1}/t735
echo ">>>>>>>>running test 736"
../source/schedule.exe  5 3 2  < ../inputs/input/dat135 > ../outputs/output.${1}/t736
echo ">>>>>>>>running test 737"
../source/schedule.exe  2 5 5  < ../inputs/input/dat136 > ../outputs/output.${1}/t737
echo ">>>>>>>>running test 738"
../source/schedule.exe  3 2 2  < ../inputs/input/dat137 > ../outputs/output.${1}/t738
echo ">>>>>>>>running test 739"
../source/schedule.exe  0 3 3  < ../inputs/input/dat138 > ../outputs/output.${1}/t739
echo ">>>>>>>>running test 740"
../source/schedule.exe  2 4 5  < ../inputs/input/dat139 > ../outputs/output.${1}/t740
echo ">>>>>>>>running test 741"
../source/schedule.exe  0 4 5  < ../inputs/input/dat140 > ../outputs/output.${1}/t741
echo ">>>>>>>>running test 742"
../source/schedule.exe  4 0 3  < ../inputs/input/dat141 > ../outputs/output.${1}/t742
echo ">>>>>>>>running test 743"
../source/schedule.exe  1 0 2  < ../inputs/input/dat142 > ../outputs/output.${1}/t743
echo ">>>>>>>>running test 744"
../source/schedule.exe  5 3 5  < ../inputs/input/dat143 > ../outputs/output.${1}/t744
echo ">>>>>>>>running test 745"
../source/schedule.exe  5 5 4  < ../inputs/input/dat144 > ../outputs/output.${1}/t745
echo ">>>>>>>>running test 746"
../source/schedule.exe  1 3 5  < ../inputs/input/dat145 > ../outputs/output.${1}/t746
echo ">>>>>>>>running test 747"
../source/schedule.exe  5 4 0  < ../inputs/input/dat146 > ../outputs/output.${1}/t747
echo ">>>>>>>>running test 748"
../source/schedule.exe  3 0 1  < ../inputs/input/dat147 > ../outputs/output.${1}/t748
echo ">>>>>>>>running test 749"
../source/schedule.exe  5 4 4  < ../inputs/input/dat148 > ../outputs/output.${1}/t749
echo ">>>>>>>>running test 750"
../source/schedule.exe  3 5 3  < ../inputs/input/dat149 > ../outputs/output.${1}/t750
echo ">>>>>>>>running test 751"
../source/schedule.exe  1 0 3  < ../inputs/input/dat150 > ../outputs/output.${1}/t751
echo ">>>>>>>>running test 752"
../source/schedule.exe  2 0 5  < ../inputs/input/dat151 > ../outputs/output.${1}/t752
echo ">>>>>>>>running test 753"
../source/schedule.exe  5 3 2  < ../inputs/input/dat152 > ../outputs/output.${1}/t753
echo ">>>>>>>>running test 754"
../source/schedule.exe  2 1 0  < ../inputs/input/dat153 > ../outputs/output.${1}/t754
echo ">>>>>>>>running test 755"
../source/schedule.exe  1 4 0  < ../inputs/input/dat154 > ../outputs/output.${1}/t755
echo ">>>>>>>>running test 756"
../source/schedule.exe  4 1 5  < ../inputs/input/dat155 > ../outputs/output.${1}/t756
echo ">>>>>>>>running test 757"
../source/schedule.exe  1 3 5  < ../inputs/input/dat156 > ../outputs/output.${1}/t757
echo ">>>>>>>>running test 758"
../source/schedule.exe  5 4 5  < ../inputs/input/dat157 > ../outputs/output.${1}/t758
echo ">>>>>>>>running test 759"
../source/schedule.exe  4 0 2  < ../inputs/input/dat158 > ../outputs/output.${1}/t759
echo ">>>>>>>>running test 760"
../source/schedule.exe  2 0 0  < ../inputs/input/dat159 > ../outputs/output.${1}/t760
echo ">>>>>>>>running test 761"
../source/schedule.exe  1 1 1  < ../inputs/input/dat160 > ../outputs/output.${1}/t761
echo ">>>>>>>>running test 762"
../source/schedule.exe  4 3 4  < ../inputs/input/dat161 > ../outputs/output.${1}/t762
echo ">>>>>>>>running test 763"
../source/schedule.exe  0 2 1  < ../inputs/input/dat162 > ../outputs/output.${1}/t763
echo ">>>>>>>>running test 764"
../source/schedule.exe  4 5 4  < ../inputs/input/dat163 > ../outputs/output.${1}/t764
echo ">>>>>>>>running test 765"
../source/schedule.exe  4 1 5  < ../inputs/input/dat164 > ../outputs/output.${1}/t765
echo ">>>>>>>>running test 766"
../source/schedule.exe  3 4 4  < ../inputs/input/dat165 > ../outputs/output.${1}/t766
echo ">>>>>>>>running test 767"
../source/schedule.exe  4 5 1  < ../inputs/input/dat166 > ../outputs/output.${1}/t767
echo ">>>>>>>>running test 768"
../source/schedule.exe  1 0 1  < ../inputs/input/dat167 > ../outputs/output.${1}/t768
echo ">>>>>>>>running test 769"
../source/schedule.exe  4 5 3  < ../inputs/input/dat168 > ../outputs/output.${1}/t769
echo ">>>>>>>>running test 770"
../source/schedule.exe  2 3 0  < ../inputs/input/dat169 > ../outputs/output.${1}/t770
echo ">>>>>>>>running test 771"
../source/schedule.exe  5 0 5  < ../inputs/input/dat170 > ../outputs/output.${1}/t771
echo ">>>>>>>>running test 772"
../source/schedule.exe  2 4 4  < ../inputs/input/dat171 > ../outputs/output.${1}/t772
echo ">>>>>>>>running test 773"
../source/schedule.exe  5 0 2  < ../inputs/input/dat172 > ../outputs/output.${1}/t773
echo ">>>>>>>>running test 774"
../source/schedule.exe  2 5 4  < ../inputs/input/dat173 > ../outputs/output.${1}/t774
echo ">>>>>>>>running test 775"
../source/schedule.exe  0 2 3  < ../inputs/input/dat174 > ../outputs/output.${1}/t775
echo ">>>>>>>>running test 776"
../source/schedule.exe  4 1 5  < ../inputs/input/dat175 > ../outputs/output.${1}/t776
echo ">>>>>>>>running test 777"
../source/schedule.exe  4 2 0  < ../inputs/input/dat176 > ../outputs/output.${1}/t777
echo ">>>>>>>>running test 778"
../source/schedule.exe  5 3 0  < ../inputs/input/dat177 > ../outputs/output.${1}/t778
echo ">>>>>>>>running test 779"
../source/schedule.exe  5 4 2  < ../inputs/input/dat178 > ../outputs/output.${1}/t779
echo ">>>>>>>>running test 780"
../source/schedule.exe  4 2 3  < ../inputs/input/dat179 > ../outputs/output.${1}/t780
echo ">>>>>>>>running test 781"
../source/schedule.exe  3 5 0  < ../inputs/input/dat180 > ../outputs/output.${1}/t781
echo ">>>>>>>>running test 782"
../source/schedule.exe  2 2 0  < ../inputs/input/dat181 > ../outputs/output.${1}/t782
echo ">>>>>>>>running test 783"
../source/schedule.exe  5 4 5  < ../inputs/input/dat182 > ../outputs/output.${1}/t783
echo ">>>>>>>>running test 784"
../source/schedule.exe  5 0 2  < ../inputs/input/dat183 > ../outputs/output.${1}/t784
echo ">>>>>>>>running test 785"
../source/schedule.exe  5 2 0  < ../inputs/input/dat184 > ../outputs/output.${1}/t785
echo ">>>>>>>>running test 786"
../source/schedule.exe  5 2 0  < ../inputs/input/dat185 > ../outputs/output.${1}/t786
echo ">>>>>>>>running test 787"
../source/schedule.exe  1 4 5  < ../inputs/input/dat186 > ../outputs/output.${1}/t787
echo ">>>>>>>>running test 788"
../source/schedule.exe  5 1 1  < ../inputs/input/dat187 > ../outputs/output.${1}/t788
echo ">>>>>>>>running test 789"
../source/schedule.exe  1 1 5  < ../inputs/input/dat188 > ../outputs/output.${1}/t789
echo ">>>>>>>>running test 790"
../source/schedule.exe  3 5 0  < ../inputs/input/dat189 > ../outputs/output.${1}/t790
echo ">>>>>>>>running test 791"
../source/schedule.exe  3 1 3  < ../inputs/input/dat190 > ../outputs/output.${1}/t791
echo ">>>>>>>>running test 792"
../source/schedule.exe  4 2 2  < ../inputs/input/dat191 > ../outputs/output.${1}/t792
echo ">>>>>>>>running test 793"
../source/schedule.exe  2 2 3  < ../inputs/input/dat192 > ../outputs/output.${1}/t793
echo ">>>>>>>>running test 794"
../source/schedule.exe  5 3 2  < ../inputs/input/dat193 > ../outputs/output.${1}/t794
echo ">>>>>>>>running test 795"
../source/schedule.exe  4 4 1  < ../inputs/input/dat194 > ../outputs/output.${1}/t795
echo ">>>>>>>>running test 796"
../source/schedule.exe  3 2 1  < ../inputs/input/dat195 > ../outputs/output.${1}/t796
echo ">>>>>>>>running test 797"
../source/schedule.exe  1 2 4  < ../inputs/input/dat196 > ../outputs/output.${1}/t797
echo ">>>>>>>>running test 798"
../source/schedule.exe  0 1 2  < ../inputs/input/dat197 > ../outputs/output.${1}/t798
echo ">>>>>>>>running test 799"
../source/schedule.exe  3 2 4  < ../inputs/input/dat198 > ../outputs/output.${1}/t799
echo ">>>>>>>>running test 800"
../source/schedule.exe  1 3 4  < ../inputs/input/dat199 > ../outputs/output.${1}/t800
echo ">>>>>>>>running test 801"
../source/schedule.exe  5 3 2  < ../inputs/input/dat200 > ../outputs/output.${1}/t801
echo ">>>>>>>>running test 802"
../source/schedule.exe  5 3 4  < ../inputs/input/dat201 > ../outputs/output.${1}/t802
echo ">>>>>>>>running test 803"
../source/schedule.exe  4 1 0  < ../inputs/input/dat202 > ../outputs/output.${1}/t803
echo ">>>>>>>>running test 804"
../source/schedule.exe  2 2 1  < ../inputs/input/dat203 > ../outputs/output.${1}/t804
echo ">>>>>>>>running test 805"
../source/schedule.exe  0 3 2  < ../inputs/input/dat204 > ../outputs/output.${1}/t805
echo ">>>>>>>>running test 806"
../source/schedule.exe  0 1 4  < ../inputs/input/dat205 > ../outputs/output.${1}/t806
echo ">>>>>>>>running test 807"
../source/schedule.exe  2 0 3  < ../inputs/input/dat206 > ../outputs/output.${1}/t807
echo ">>>>>>>>running test 808"
../source/schedule.exe  1 3 3  < ../inputs/input/dat207 > ../outputs/output.${1}/t808
echo ">>>>>>>>running test 809"
../source/schedule.exe  1 2 0  < ../inputs/input/dat208 > ../outputs/output.${1}/t809
echo ">>>>>>>>running test 810"
../source/schedule.exe  1 4 1  < ../inputs/input/dat209 > ../outputs/output.${1}/t810
echo ">>>>>>>>running test 811"
../source/schedule.exe  2 4 3  < ../inputs/input/dat210 > ../outputs/output.${1}/t811
echo ">>>>>>>>running test 812"
../source/schedule.exe  5 1 1  < ../inputs/input/dat211 > ../outputs/output.${1}/t812
echo ">>>>>>>>running test 813"
../source/schedule.exe  3 2 5  < ../inputs/input/dat212 > ../outputs/output.${1}/t813
echo ">>>>>>>>running test 814"
../source/schedule.exe  5 3 1  < ../inputs/input/dat213 > ../outputs/output.${1}/t814
echo ">>>>>>>>running test 815"
../source/schedule.exe  0 5 4  < ../inputs/input/dat214 > ../outputs/output.${1}/t815
echo ">>>>>>>>running test 816"
../source/schedule.exe  0 4 4  < ../inputs/input/dat215 > ../outputs/output.${1}/t816
echo ">>>>>>>>running test 817"
../source/schedule.exe  2 2 3  < ../inputs/input/dat216 > ../outputs/output.${1}/t817
echo ">>>>>>>>running test 818"
../source/schedule.exe  5 2 4  < ../inputs/input/dat217 > ../outputs/output.${1}/t818
echo ">>>>>>>>running test 819"
../source/schedule.exe  0 5 4  < ../inputs/input/dat218 > ../outputs/output.${1}/t819
echo ">>>>>>>>running test 820"
../source/schedule.exe  1 0 4  < ../inputs/input/dat219 > ../outputs/output.${1}/t820
echo ">>>>>>>>running test 821"
../source/schedule.exe  1 2 5  < ../inputs/input/dat220 > ../outputs/output.${1}/t821
echo ">>>>>>>>running test 822"
../source/schedule.exe  2 1 1  < ../inputs/input/dat221 > ../outputs/output.${1}/t822
echo ">>>>>>>>running test 823"
../source/schedule.exe  5 2 1  < ../inputs/input/dat222 > ../outputs/output.${1}/t823
echo ">>>>>>>>running test 824"
../source/schedule.exe  3 2 0  < ../inputs/input/dat223 > ../outputs/output.${1}/t824
echo ">>>>>>>>running test 825"
../source/schedule.exe  3 5 0  < ../inputs/input/dat224 > ../outputs/output.${1}/t825
echo ">>>>>>>>running test 826"
../source/schedule.exe  4 2 5  < ../inputs/input/dat225 > ../outputs/output.${1}/t826
echo ">>>>>>>>running test 827"
../source/schedule.exe  5 5 3  < ../inputs/input/dat226 > ../outputs/output.${1}/t827
echo ">>>>>>>>running test 828"
../source/schedule.exe  0 4 1  < ../inputs/input/dat227 > ../outputs/output.${1}/t828
echo ">>>>>>>>running test 829"
../source/schedule.exe  2 1 1  < ../inputs/input/dat228 > ../outputs/output.${1}/t829
echo ">>>>>>>>running test 830"
../source/schedule.exe  4 4 0  < ../inputs/input/dat229 > ../outputs/output.${1}/t830
echo ">>>>>>>>running test 831"
../source/schedule.exe  0 3 2  < ../inputs/input/dat230 > ../outputs/output.${1}/t831
echo ">>>>>>>>running test 832"
../source/schedule.exe  2 1 3  < ../inputs/input/dat231 > ../outputs/output.${1}/t832
echo ">>>>>>>>running test 833"
../source/schedule.exe  5 0 2  < ../inputs/input/dat232 > ../outputs/output.${1}/t833
echo ">>>>>>>>running test 834"
../source/schedule.exe  5 2 4  < ../inputs/input/dat233 > ../outputs/output.${1}/t834
echo ">>>>>>>>running test 835"
../source/schedule.exe  4 2 2  < ../inputs/input/dat234 > ../outputs/output.${1}/t835
echo ">>>>>>>>running test 836"
../source/schedule.exe  0 4 5  < ../inputs/input/dat235 > ../outputs/output.${1}/t836
echo ">>>>>>>>running test 837"
../source/schedule.exe  3 1 3  < ../inputs/input/dat236 > ../outputs/output.${1}/t837
echo ">>>>>>>>running test 838"
../source/schedule.exe  4 1 0  < ../inputs/input/dat237 > ../outputs/output.${1}/t838
echo ">>>>>>>>running test 839"
../source/schedule.exe  0 5 3  < ../inputs/input/dat238 > ../outputs/output.${1}/t839
echo ">>>>>>>>running test 840"
../source/schedule.exe  1 0 2  < ../inputs/input/dat239 > ../outputs/output.${1}/t840
echo ">>>>>>>>running test 841"
../source/schedule.exe  4 3 1  < ../inputs/input/dat240 > ../outputs/output.${1}/t841
echo ">>>>>>>>running test 842"
../source/schedule.exe  5 1 1  < ../inputs/input/dat241 > ../outputs/output.${1}/t842
echo ">>>>>>>>running test 843"
../source/schedule.exe  3 4 2  < ../inputs/input/dat242 > ../outputs/output.${1}/t843
echo ">>>>>>>>running test 844"
../source/schedule.exe  4 2 4  < ../inputs/input/dat243 > ../outputs/output.${1}/t844
echo ">>>>>>>>running test 845"
../source/schedule.exe  4 3 4  < ../inputs/input/dat244 > ../outputs/output.${1}/t845
echo ">>>>>>>>running test 846"
../source/schedule.exe  3 0 2  < ../inputs/input/dat245 > ../outputs/output.${1}/t846
echo ">>>>>>>>running test 847"
../source/schedule.exe  0 4 3  < ../inputs/input/dat246 > ../outputs/output.${1}/t847
echo ">>>>>>>>running test 848"
../source/schedule.exe  0 0 5  < ../inputs/input/dat247 > ../outputs/output.${1}/t848
echo ">>>>>>>>running test 849"
../source/schedule.exe  2 4 0  < ../inputs/input/dat248 > ../outputs/output.${1}/t849
echo ">>>>>>>>running test 850"
../source/schedule.exe  4 3 2  < ../inputs/input/dat249 > ../outputs/output.${1}/t850
echo ">>>>>>>>running test 851"
../source/schedule.exe  1 5 4  < ../inputs/input/dat250 > ../outputs/output.${1}/t851
echo ">>>>>>>>running test 852"
../source/schedule.exe  4 2 4  < ../inputs/input/dat251 > ../outputs/output.${1}/t852
echo ">>>>>>>>running test 853"
../source/schedule.exe  0 2 1  < ../inputs/input/dat252 > ../outputs/output.${1}/t853
echo ">>>>>>>>running test 854"
../source/schedule.exe  0 1 3  < ../inputs/input/dat253 > ../outputs/output.${1}/t854
echo ">>>>>>>>running test 855"
../source/schedule.exe  3 2 2  < ../inputs/input/dat254 > ../outputs/output.${1}/t855
echo ">>>>>>>>running test 856"
../source/schedule.exe  3 2 0  < ../inputs/input/dat255 > ../outputs/output.${1}/t856
echo ">>>>>>>>running test 857"
../source/schedule.exe  5 1 1  < ../inputs/input/dat256 > ../outputs/output.${1}/t857
echo ">>>>>>>>running test 858"
../source/schedule.exe  1 3 3  < ../inputs/input/dat257 > ../outputs/output.${1}/t858
echo ">>>>>>>>running test 859"
../source/schedule.exe  0 3 3  < ../inputs/input/dat258 > ../outputs/output.${1}/t859
echo ">>>>>>>>running test 860"
../source/schedule.exe  1 0 2  < ../inputs/input/dat259 > ../outputs/output.${1}/t860
echo ">>>>>>>>running test 861"
../source/schedule.exe  2 5 1  < ../inputs/input/dat260 > ../outputs/output.${1}/t861
echo ">>>>>>>>running test 862"
../source/schedule.exe  1 3 4  < ../inputs/input/dat261 > ../outputs/output.${1}/t862
echo ">>>>>>>>running test 863"
../source/schedule.exe  3 5 3  < ../inputs/input/dat262 > ../outputs/output.${1}/t863
echo ">>>>>>>>running test 864"
../source/schedule.exe  1 1 3  < ../inputs/input/dat263 > ../outputs/output.${1}/t864
echo ">>>>>>>>running test 865"
../source/schedule.exe  4 2 3  < ../inputs/input/dat264 > ../outputs/output.${1}/t865
echo ">>>>>>>>running test 866"
../source/schedule.exe  0 0 4  < ../inputs/input/dat265 > ../outputs/output.${1}/t866
echo ">>>>>>>>running test 867"
../source/schedule.exe  4 0 1  < ../inputs/input/dat266 > ../outputs/output.${1}/t867
echo ">>>>>>>>running test 868"
../source/schedule.exe  1 1 5  < ../inputs/input/dat267 > ../outputs/output.${1}/t868
echo ">>>>>>>>running test 869"
../source/schedule.exe  0 0 2  < ../inputs/input/dat268 > ../outputs/output.${1}/t869
echo ">>>>>>>>running test 870"
../source/schedule.exe  5 4 1  < ../inputs/input/dat269 > ../outputs/output.${1}/t870
echo ">>>>>>>>running test 871"
../source/schedule.exe  3 3 3  < ../inputs/input/dat270 > ../outputs/output.${1}/t871
echo ">>>>>>>>running test 872"
../source/schedule.exe  2 1 0  < ../inputs/input/dat271 > ../outputs/output.${1}/t872
echo ">>>>>>>>running test 873"
../source/schedule.exe  3 3 4  < ../inputs/input/dat272 > ../outputs/output.${1}/t873
echo ">>>>>>>>running test 874"
../source/schedule.exe  5 4 4  < ../inputs/input/dat273 > ../outputs/output.${1}/t874
echo ">>>>>>>>running test 875"
../source/schedule.exe  5 1 2  < ../inputs/input/dat274 > ../outputs/output.${1}/t875
echo ">>>>>>>>running test 876"
../source/schedule.exe  2 4 3  < ../inputs/input/dat275 > ../outputs/output.${1}/t876
echo ">>>>>>>>running test 877"
../source/schedule.exe  3 4 4  < ../inputs/input/dat276 > ../outputs/output.${1}/t877
echo ">>>>>>>>running test 878"
../source/schedule.exe  1 3 5  < ../inputs/input/dat277 > ../outputs/output.${1}/t878
echo ">>>>>>>>running test 879"
../source/schedule.exe  5 4 4  < ../inputs/input/dat278 > ../outputs/output.${1}/t879
echo ">>>>>>>>running test 880"
../source/schedule.exe  1 1 4  < ../inputs/input/dat279 > ../outputs/output.${1}/t880
echo ">>>>>>>>running test 881"
../source/schedule.exe  0 3 0  < ../inputs/input/dat280 > ../outputs/output.${1}/t881
echo ">>>>>>>>running test 882"
../source/schedule.exe  1 1 5  < ../inputs/input/dat281 > ../outputs/output.${1}/t882
echo ">>>>>>>>running test 883"
../source/schedule.exe  4 5 2  < ../inputs/input/dat282 > ../outputs/output.${1}/t883
echo ">>>>>>>>running test 884"
../source/schedule.exe  3 3 2  < ../inputs/input/dat283 > ../outputs/output.${1}/t884
echo ">>>>>>>>running test 885"
../source/schedule.exe  2 4 2  < ../inputs/input/dat284 > ../outputs/output.${1}/t885
echo ">>>>>>>>running test 886"
../source/schedule.exe  4 4 5  < ../inputs/input/dat285 > ../outputs/output.${1}/t886
echo ">>>>>>>>running test 887"
../source/schedule.exe  2 1 0  < ../inputs/input/dat286 > ../outputs/output.${1}/t887
echo ">>>>>>>>running test 888"
../source/schedule.exe  1 4 1  < ../inputs/input/dat287 > ../outputs/output.${1}/t888
echo ">>>>>>>>running test 889"
../source/schedule.exe  5 1 5  < ../inputs/input/dat288 > ../outputs/output.${1}/t889
echo ">>>>>>>>running test 890"
../source/schedule.exe  1 0 1  < ../inputs/input/dat289 > ../outputs/output.${1}/t890
echo ">>>>>>>>running test 891"
../source/schedule.exe  3 2 0  < ../inputs/input/dat290 > ../outputs/output.${1}/t891
echo ">>>>>>>>running test 892"
../source/schedule.exe  3 1 3  < ../inputs/input/dat291 > ../outputs/output.${1}/t892
echo ">>>>>>>>running test 893"
../source/schedule.exe  5 2 5  < ../inputs/input/dat292 > ../outputs/output.${1}/t893
echo ">>>>>>>>running test 894"
../source/schedule.exe  3 2 0  < ../inputs/input/dat293 > ../outputs/output.${1}/t894
echo ">>>>>>>>running test 895"
../source/schedule.exe  2 1 5  < ../inputs/input/dat294 > ../outputs/output.${1}/t895
echo ">>>>>>>>running test 896"
../source/schedule.exe  4 0 1  < ../inputs/input/dat295 > ../outputs/output.${1}/t896
echo ">>>>>>>>running test 897"
../source/schedule.exe  0 4 2  < ../inputs/input/dat296 > ../outputs/output.${1}/t897
echo ">>>>>>>>running test 898"
../source/schedule.exe  0 5 0  < ../inputs/input/dat297 > ../outputs/output.${1}/t898
echo ">>>>>>>>running test 899"
../source/schedule.exe  4 5 1  < ../inputs/input/dat298 > ../outputs/output.${1}/t899
echo ">>>>>>>>running test 900"
../source/schedule.exe  5 1 5  < ../inputs/input/dat299 > ../outputs/output.${1}/t900
echo ">>>>>>>>running test 901"
../source/schedule.exe  0 1 3  < ../inputs/input/dat300 > ../outputs/output.${1}/t901
echo ">>>>>>>>running test 902"
../source/schedule.exe  0 0 1  < ../inputs/input/dat301 > ../outputs/output.${1}/t902
echo ">>>>>>>>running test 903"
../source/schedule.exe  0 0 3  < ../inputs/input/dat302 > ../outputs/output.${1}/t903
echo ">>>>>>>>running test 904"
../source/schedule.exe  3 0 5  < ../inputs/input/dat303 > ../outputs/output.${1}/t904
echo ">>>>>>>>running test 905"
../source/schedule.exe  5 3 2  < ../inputs/input/dat304 > ../outputs/output.${1}/t905
echo ">>>>>>>>running test 906"
../source/schedule.exe  3 5 1  < ../inputs/input/dat305 > ../outputs/output.${1}/t906
echo ">>>>>>>>running test 907"
../source/schedule.exe  2 1 1  < ../inputs/input/dat306 > ../outputs/output.${1}/t907
echo ">>>>>>>>running test 908"
../source/schedule.exe  2 2 1  < ../inputs/input/dat307 > ../outputs/output.${1}/t908
echo ">>>>>>>>running test 909"
../source/schedule.exe  0 2 1  < ../inputs/input/dat308 > ../outputs/output.${1}/t909
echo ">>>>>>>>running test 910"
../source/schedule.exe  4 0 0  < ../inputs/input/dat309 > ../outputs/output.${1}/t910
echo ">>>>>>>>running test 911"
../source/schedule.exe  4 2 5  < ../inputs/input/dat310 > ../outputs/output.${1}/t911
echo ">>>>>>>>running test 912"
../source/schedule.exe  1 4 1  < ../inputs/input/dat311 > ../outputs/output.${1}/t912
echo ">>>>>>>>running test 913"
../source/schedule.exe  5 4 2  < ../inputs/input/dat312 > ../outputs/output.${1}/t913
echo ">>>>>>>>running test 914"
../source/schedule.exe  5 5 2  < ../inputs/input/dat313 > ../outputs/output.${1}/t914
echo ">>>>>>>>running test 915"
../source/schedule.exe  4 4 2  < ../inputs/input/dat314 > ../outputs/output.${1}/t915
echo ">>>>>>>>running test 916"
../source/schedule.exe  4 1 2  < ../inputs/input/dat315 > ../outputs/output.${1}/t916
echo ">>>>>>>>running test 917"
../source/schedule.exe  3 0 2  < ../inputs/input/dat316 > ../outputs/output.${1}/t917
echo ">>>>>>>>running test 918"
../source/schedule.exe  0 3 1  < ../inputs/input/dat317 > ../outputs/output.${1}/t918
echo ">>>>>>>>running test 919"
../source/schedule.exe  2 0 3  < ../inputs/input/dat318 > ../outputs/output.${1}/t919
echo ">>>>>>>>running test 920"
../source/schedule.exe  3 3 2  < ../inputs/input/dat319 > ../outputs/output.${1}/t920
echo ">>>>>>>>running test 921"
../source/schedule.exe  0 2 2  < ../inputs/input/dat320 > ../outputs/output.${1}/t921
echo ">>>>>>>>running test 922"
../source/schedule.exe  0 5 4  < ../inputs/input/dat321 > ../outputs/output.${1}/t922
echo ">>>>>>>>running test 923"
../source/schedule.exe  3 2 4  < ../inputs/input/dat322 > ../outputs/output.${1}/t923
echo ">>>>>>>>running test 924"
../source/schedule.exe  0 1 0  < ../inputs/input/dat323 > ../outputs/output.${1}/t924
echo ">>>>>>>>running test 925"
../source/schedule.exe  2 3 2  < ../inputs/input/dat324 > ../outputs/output.${1}/t925
echo ">>>>>>>>running test 926"
../source/schedule.exe  2 5 5  < ../inputs/input/dat325 > ../outputs/output.${1}/t926
echo ">>>>>>>>running test 927"
../source/schedule.exe  0 3 3  < ../inputs/input/dat326 > ../outputs/output.${1}/t927
echo ">>>>>>>>running test 928"
../source/schedule.exe  2 5 0  < ../inputs/input/dat327 > ../outputs/output.${1}/t928
echo ">>>>>>>>running test 929"
../source/schedule.exe  3 2 2  < ../inputs/input/dat328 > ../outputs/output.${1}/t929
echo ">>>>>>>>running test 930"
../source/schedule.exe  0 4 3  < ../inputs/input/dat329 > ../outputs/output.${1}/t930
echo ">>>>>>>>running test 931"
../source/schedule.exe  0 0 2  < ../inputs/input/dat330 > ../outputs/output.${1}/t931
echo ">>>>>>>>running test 932"
../source/schedule.exe  0 0 1  < ../inputs/input/dat331 > ../outputs/output.${1}/t932
echo ">>>>>>>>running test 933"
../source/schedule.exe  5 2 2  < ../inputs/input/dat332 > ../outputs/output.${1}/t933
echo ">>>>>>>>running test 934"
../source/schedule.exe  1 3 2  < ../inputs/input/dat333 > ../outputs/output.${1}/t934
echo ">>>>>>>>running test 935"
../source/schedule.exe  0 5 1  < ../inputs/input/dat334 > ../outputs/output.${1}/t935
echo ">>>>>>>>running test 936"
../source/schedule.exe  1 4 5  < ../inputs/input/dat335 > ../outputs/output.${1}/t936
echo ">>>>>>>>running test 937"
../source/schedule.exe  5 4 4  < ../inputs/input/dat336 > ../outputs/output.${1}/t937
echo ">>>>>>>>running test 938"
../source/schedule.exe  5 1 2  < ../inputs/input/dat337 > ../outputs/output.${1}/t938
echo ">>>>>>>>running test 939"
../source/schedule.exe  0 2 5  < ../inputs/input/dat338 > ../outputs/output.${1}/t939
echo ">>>>>>>>running test 940"
../source/schedule.exe  2 4 3  < ../inputs/input/dat339 > ../outputs/output.${1}/t940
echo ">>>>>>>>running test 941"
../source/schedule.exe  2 4 1  < ../inputs/input/dat340 > ../outputs/output.${1}/t941
echo ">>>>>>>>running test 942"
../source/schedule.exe  1 0 3  < ../inputs/input/dat341 > ../outputs/output.${1}/t942
echo ">>>>>>>>running test 943"
../source/schedule.exe  4 1 5  < ../inputs/input/dat342 > ../outputs/output.${1}/t943
echo ">>>>>>>>running test 944"
../source/schedule.exe  1 1 1  < ../inputs/input/dat343 > ../outputs/output.${1}/t944
echo ">>>>>>>>running test 945"
../source/schedule.exe  1 1 1  < ../inputs/input/dat344 > ../outputs/output.${1}/t945
echo ">>>>>>>>running test 946"
../source/schedule.exe  2 4 1  < ../inputs/input/dat345 > ../outputs/output.${1}/t946
echo ">>>>>>>>running test 947"
../source/schedule.exe  0 2 3  < ../inputs/input/dat346 > ../outputs/output.${1}/t947
echo ">>>>>>>>running test 948"
../source/schedule.exe  5 0 1  < ../inputs/input/dat347 > ../outputs/output.${1}/t948
echo ">>>>>>>>running test 949"
../source/schedule.exe  4 5 5  < ../inputs/input/dat348 > ../outputs/output.${1}/t949
echo ">>>>>>>>running test 950"
../source/schedule.exe  5 0 4  < ../inputs/input/dat349 > ../outputs/output.${1}/t950
echo ">>>>>>>>running test 951"
../source/schedule.exe  4 3 1  < ../inputs/input/dat350 > ../outputs/output.${1}/t951
echo ">>>>>>>>running test 952"
../source/schedule.exe  4 1 3  < ../inputs/input/dat351 > ../outputs/output.${1}/t952
echo ">>>>>>>>running test 953"
../source/schedule.exe  3 2 3  < ../inputs/input/dat352 > ../outputs/output.${1}/t953
echo ">>>>>>>>running test 954"
../source/schedule.exe  4 3 5  < ../inputs/input/dat353 > ../outputs/output.${1}/t954
echo ">>>>>>>>running test 955"
../source/schedule.exe  1 3 0  < ../inputs/input/dat354 > ../outputs/output.${1}/t955
echo ">>>>>>>>running test 956"
../source/schedule.exe  2 5 3  < ../inputs/input/dat355 > ../outputs/output.${1}/t956
echo ">>>>>>>>running test 957"
../source/schedule.exe  0 1 1  < ../inputs/input/dat356 > ../outputs/output.${1}/t957
echo ">>>>>>>>running test 958"
../source/schedule.exe  3 1 5  < ../inputs/input/dat357 > ../outputs/output.${1}/t958
echo ">>>>>>>>running test 959"
../source/schedule.exe  3 1 2  < ../inputs/input/dat358 > ../outputs/output.${1}/t959
echo ">>>>>>>>running test 960"
../source/schedule.exe  5 2 5  < ../inputs/input/dat359 > ../outputs/output.${1}/t960
echo ">>>>>>>>running test 961"
../source/schedule.exe  0 1 2  < ../inputs/input/dat360 > ../outputs/output.${1}/t961
echo ">>>>>>>>running test 962"
../source/schedule.exe  3 1 5  < ../inputs/input/dat361 > ../outputs/output.${1}/t962
echo ">>>>>>>>running test 963"
../source/schedule.exe  5 0 1  < ../inputs/input/dat362 > ../outputs/output.${1}/t963
echo ">>>>>>>>running test 964"
../source/schedule.exe  4 2 3  < ../inputs/input/dat363 > ../outputs/output.${1}/t964
echo ">>>>>>>>running test 965"
../source/schedule.exe  3 4 2  < ../inputs/input/dat364 > ../outputs/output.${1}/t965
echo ">>>>>>>>running test 966"
../source/schedule.exe  3 3 4  < ../inputs/input/dat365 > ../outputs/output.${1}/t966
echo ">>>>>>>>running test 967"
../source/schedule.exe  4 2 2  < ../inputs/input/dat366 > ../outputs/output.${1}/t967
echo ">>>>>>>>running test 968"
../source/schedule.exe  5 5 0  < ../inputs/input/dat367 > ../outputs/output.${1}/t968
echo ">>>>>>>>running test 969"
../source/schedule.exe  2 1 2  < ../inputs/input/dat368 > ../outputs/output.${1}/t969
echo ">>>>>>>>running test 970"
../source/schedule.exe  1 4 5  < ../inputs/input/dat369 > ../outputs/output.${1}/t970
echo ">>>>>>>>running test 971"
../source/schedule.exe  3 2 0  < ../inputs/input/dat370 > ../outputs/output.${1}/t971
echo ">>>>>>>>running test 972"
../source/schedule.exe  0 4 4  < ../inputs/input/dat371 > ../outputs/output.${1}/t972
echo ">>>>>>>>running test 973"
../source/schedule.exe  2 0 5  < ../inputs/input/dat372 > ../outputs/output.${1}/t973
echo ">>>>>>>>running test 974"
../source/schedule.exe  4 1 5  < ../inputs/input/dat373 > ../outputs/output.${1}/t974
echo ">>>>>>>>running test 975"
../source/schedule.exe  5 5 4  < ../inputs/input/dat374 > ../outputs/output.${1}/t975
echo ">>>>>>>>running test 976"
../source/schedule.exe  0 5 4  < ../inputs/input/dat375 > ../outputs/output.${1}/t976
echo ">>>>>>>>running test 977"
../source/schedule.exe  2 4 4  < ../inputs/input/dat376 > ../outputs/output.${1}/t977
echo ">>>>>>>>running test 978"
../source/schedule.exe  0 2 1  < ../inputs/input/dat377 > ../outputs/output.${1}/t978
echo ">>>>>>>>running test 979"
../source/schedule.exe  3 3 2  < ../inputs/input/dat378 > ../outputs/output.${1}/t979
echo ">>>>>>>>running test 980"
../source/schedule.exe  2 0 1  < ../inputs/input/dat379 > ../outputs/output.${1}/t980
echo ">>>>>>>>running test 981"
../source/schedule.exe  0 3 3  < ../inputs/input/dat380 > ../outputs/output.${1}/t981
echo ">>>>>>>>running test 982"
../source/schedule.exe  2 4 2  < ../inputs/input/dat381 > ../outputs/output.${1}/t982
echo ">>>>>>>>running test 983"
../source/schedule.exe  0 5 0  < ../inputs/input/dat382 > ../outputs/output.${1}/t983
echo ">>>>>>>>running test 984"
../source/schedule.exe  4 4 0  < ../inputs/input/dat383 > ../outputs/output.${1}/t984
echo ">>>>>>>>running test 985"
../source/schedule.exe  2 5 5  < ../inputs/input/dat384 > ../outputs/output.${1}/t985
echo ">>>>>>>>running test 986"
../source/schedule.exe  0 2 5  < ../inputs/input/dat385 > ../outputs/output.${1}/t986
echo ">>>>>>>>running test 987"
../source/schedule.exe  5 3 1  < ../inputs/input/dat386 > ../outputs/output.${1}/t987
echo ">>>>>>>>running test 988"
../source/schedule.exe  3 1 4  < ../inputs/input/dat387 > ../outputs/output.${1}/t988
echo ">>>>>>>>running test 989"
../source/schedule.exe  5 0 2  < ../inputs/input/dat388 > ../outputs/output.${1}/t989
echo ">>>>>>>>running test 990"
../source/schedule.exe  3 3 1  < ../inputs/input/dat389 > ../outputs/output.${1}/t990
echo ">>>>>>>>running test 991"
../source/schedule.exe  4 4 3  < ../inputs/input/dat390 > ../outputs/output.${1}/t991
echo ">>>>>>>>running test 992"
../source/schedule.exe  4 4 2  < ../inputs/input/dat391 > ../outputs/output.${1}/t992
echo ">>>>>>>>running test 993"
../source/schedule.exe  2 2 1  < ../inputs/input/dat392 > ../outputs/output.${1}/t993
echo ">>>>>>>>running test 994"
../source/schedule.exe  1 3 0  < ../inputs/input/dat393 > ../outputs/output.${1}/t994
echo ">>>>>>>>running test 995"
../source/schedule.exe  5 4 0  < ../inputs/input/dat394 > ../outputs/output.${1}/t995
echo ">>>>>>>>running test 996"
../source/schedule.exe  4 5 2  < ../inputs/input/dat395 > ../outputs/output.${1}/t996
echo ">>>>>>>>running test 997"
../source/schedule.exe  4 3 2  < ../inputs/input/dat396 > ../outputs/output.${1}/t997
echo ">>>>>>>>running test 998"
../source/schedule.exe  3 3 2  < ../inputs/input/dat397 > ../outputs/output.${1}/t998
echo ">>>>>>>>running test 999"
../source/schedule.exe  2 5 4  < ../inputs/input/dat398 > ../outputs/output.${1}/t999
echo ">>>>>>>>running test 1000"
../source/schedule.exe  0 0 5  < ../inputs/input/dat399 > ../outputs/output.${1}/t1000
echo ">>>>>>>>running test 1001"
../source/schedule.exe  5 4 5  < ../inputs/input/dat400 > ../outputs/output.${1}/t1001
echo ">>>>>>>>running test 1002"
../source/schedule.exe  5 0 5  < ../inputs/input/dat401 > ../outputs/output.${1}/t1002
echo ">>>>>>>>running test 1003"
../source/schedule.exe  2 0 3  < ../inputs/input/dat402 > ../outputs/output.${1}/t1003
echo ">>>>>>>>running test 1004"
../source/schedule.exe  3 5 5  < ../inputs/input/dat403 > ../outputs/output.${1}/t1004
echo ">>>>>>>>running test 1005"
../source/schedule.exe  1 3 2  < ../inputs/input/dat404 > ../outputs/output.${1}/t1005
echo ">>>>>>>>running test 1006"
../source/schedule.exe  2 3 3  < ../inputs/input/dat405 > ../outputs/output.${1}/t1006
echo ">>>>>>>>running test 1007"
../source/schedule.exe  1 2 1  < ../inputs/input/dat406 > ../outputs/output.${1}/t1007
echo ">>>>>>>>running test 1008"
../source/schedule.exe  3 4 2  < ../inputs/input/dat407 > ../outputs/output.${1}/t1008
echo ">>>>>>>>running test 1009"
../source/schedule.exe  2 2 4  < ../inputs/input/dat408 > ../outputs/output.${1}/t1009
echo ">>>>>>>>running test 1010"
../source/schedule.exe  5 4 1  < ../inputs/input/dat409 > ../outputs/output.${1}/t1010
echo ">>>>>>>>running test 1011"
../source/schedule.exe  2 3 5  < ../inputs/input/dat410 > ../outputs/output.${1}/t1011
echo ">>>>>>>>running test 1012"
../source/schedule.exe  2 2 2  < ../inputs/input/dat411 > ../outputs/output.${1}/t1012
echo ">>>>>>>>running test 1013"
../source/schedule.exe  3 1 4  < ../inputs/input/dat412 > ../outputs/output.${1}/t1013
echo ">>>>>>>>running test 1014"
../source/schedule.exe  1 4 0  < ../inputs/input/dat413 > ../outputs/output.${1}/t1014
echo ">>>>>>>>running test 1015"
../source/schedule.exe  0 1 5  < ../inputs/input/dat414 > ../outputs/output.${1}/t1015
echo ">>>>>>>>running test 1016"
../source/schedule.exe  3 2 1  < ../inputs/input/dat415 > ../outputs/output.${1}/t1016
echo ">>>>>>>>running test 1017"
../source/schedule.exe  0 1 4  < ../inputs/input/dat416 > ../outputs/output.${1}/t1017
echo ">>>>>>>>running test 1018"
../source/schedule.exe  5 0 5  < ../inputs/input/dat417 > ../outputs/output.${1}/t1018
echo ">>>>>>>>running test 1019"
../source/schedule.exe  5 1 4  < ../inputs/input/dat418 > ../outputs/output.${1}/t1019
echo ">>>>>>>>running test 1020"
../source/schedule.exe  4 3 3  < ../inputs/input/dat419 > ../outputs/output.${1}/t1020
echo ">>>>>>>>running test 1021"
../source/schedule.exe  1 2 0  < ../inputs/input/dat420 > ../outputs/output.${1}/t1021
echo ">>>>>>>>running test 1022"
../source/schedule.exe  2 5 2  < ../inputs/input/dat421 > ../outputs/output.${1}/t1022
echo ">>>>>>>>running test 1023"
../source/schedule.exe  2 3 4  < ../inputs/input/dat422 > ../outputs/output.${1}/t1023
echo ">>>>>>>>running test 1024"
../source/schedule.exe  3 4 4  < ../inputs/input/dat423 > ../outputs/output.${1}/t1024
echo ">>>>>>>>running test 1025"
../source/schedule.exe  1 0 5  < ../inputs/input/dat424 > ../outputs/output.${1}/t1025
echo ">>>>>>>>running test 1026"
../source/schedule.exe  3 3 2  < ../inputs/input/dat425 > ../outputs/output.${1}/t1026
echo ">>>>>>>>running test 1027"
../source/schedule.exe  0 3 0  < ../inputs/input/dat426 > ../outputs/output.${1}/t1027
echo ">>>>>>>>running test 1028"
../source/schedule.exe  0 2 4  < ../inputs/input/dat427 > ../outputs/output.${1}/t1028
echo ">>>>>>>>running test 1029"
../source/schedule.exe  0 1 5  < ../inputs/input/dat428 > ../outputs/output.${1}/t1029
echo ">>>>>>>>running test 1030"
../source/schedule.exe  2 5 4  < ../inputs/input/dat429 > ../outputs/output.${1}/t1030
echo ">>>>>>>>running test 1031"
../source/schedule.exe  0 4 3  < ../inputs/input/dat430 > ../outputs/output.${1}/t1031
echo ">>>>>>>>running test 1032"
../source/schedule.exe  0 1 5  < ../inputs/input/dat431 > ../outputs/output.${1}/t1032
echo ">>>>>>>>running test 1033"
../source/schedule.exe  1 2 5  < ../inputs/input/dat432 > ../outputs/output.${1}/t1033
echo ">>>>>>>>running test 1034"
../source/schedule.exe  2 4 3  < ../inputs/input/dat433 > ../outputs/output.${1}/t1034
echo ">>>>>>>>running test 1035"
../source/schedule.exe  5 0 2  < ../inputs/input/dat434 > ../outputs/output.${1}/t1035
echo ">>>>>>>>running test 1036"
../source/schedule.exe  5 4 5  < ../inputs/input/dat435 > ../outputs/output.${1}/t1036
echo ">>>>>>>>running test 1037"
../source/schedule.exe  1 4 3  < ../inputs/input/dat436 > ../outputs/output.${1}/t1037
echo ">>>>>>>>running test 1038"
../source/schedule.exe  4 1 3  < ../inputs/input/dat437 > ../outputs/output.${1}/t1038
echo ">>>>>>>>running test 1039"
../source/schedule.exe  3 2 0  < ../inputs/input/dat438 > ../outputs/output.${1}/t1039
echo ">>>>>>>>running test 1040"
../source/schedule.exe  4 1 5  < ../inputs/input/dat439 > ../outputs/output.${1}/t1040
echo ">>>>>>>>running test 1041"
../source/schedule.exe  5 1 0  < ../inputs/input/dat440 > ../outputs/output.${1}/t1041
echo ">>>>>>>>running test 1042"
../source/schedule.exe  5 3 0  < ../inputs/input/dat441 > ../outputs/output.${1}/t1042
echo ">>>>>>>>running test 1043"
../source/schedule.exe  5 3 3  < ../inputs/input/dat442 > ../outputs/output.${1}/t1043
echo ">>>>>>>>running test 1044"
../source/schedule.exe  3 1 4  < ../inputs/input/dat443 > ../outputs/output.${1}/t1044
echo ">>>>>>>>running test 1045"
../source/schedule.exe  5 5 2  < ../inputs/input/dat444 > ../outputs/output.${1}/t1045
echo ">>>>>>>>running test 1046"
../source/schedule.exe  2 4 5  < ../inputs/input/dat445 > ../outputs/output.${1}/t1046
echo ">>>>>>>>running test 1047"
../source/schedule.exe  5 1 3  < ../inputs/input/dat446 > ../outputs/output.${1}/t1047
echo ">>>>>>>>running test 1048"
../source/schedule.exe  5 0 1  < ../inputs/input/dat447 > ../outputs/output.${1}/t1048
echo ">>>>>>>>running test 1049"
../source/schedule.exe  5 0 3  < ../inputs/input/dat448 > ../outputs/output.${1}/t1049
echo ">>>>>>>>running test 1050"
../source/schedule.exe  2 4 5  < ../inputs/input/dat449 > ../outputs/output.${1}/t1050
echo ">>>>>>>>running test 1051"
../source/schedule.exe  5 0 1  < ../inputs/input/dat450 > ../outputs/output.${1}/t1051
echo ">>>>>>>>running test 1052"
../source/schedule.exe  2 4 2  < ../inputs/input/dat451 > ../outputs/output.${1}/t1052
echo ">>>>>>>>running test 1053"
../source/schedule.exe  4 2 3  < ../inputs/input/dat452 > ../outputs/output.${1}/t1053
echo ">>>>>>>>running test 1054"
../source/schedule.exe  2 5 3  < ../inputs/input/dat453 > ../outputs/output.${1}/t1054
echo ">>>>>>>>running test 1055"
../source/schedule.exe  0 4 2  < ../inputs/input/dat454 > ../outputs/output.${1}/t1055
echo ">>>>>>>>running test 1056"
../source/schedule.exe  2 4 3  < ../inputs/input/dat455 > ../outputs/output.${1}/t1056
echo ">>>>>>>>running test 1057"
../source/schedule.exe  3 2 1  < ../inputs/input/dat456 > ../outputs/output.${1}/t1057
echo ">>>>>>>>running test 1058"
../source/schedule.exe  0 0 3  < ../inputs/input/dat457 > ../outputs/output.${1}/t1058
echo ">>>>>>>>running test 1059"
../source/schedule.exe  5 0 2  < ../inputs/input/dat458 > ../outputs/output.${1}/t1059
echo ">>>>>>>>running test 1060"
../source/schedule.exe  4 2 1  < ../inputs/input/dat459 > ../outputs/output.${1}/t1060
echo ">>>>>>>>running test 1061"
../source/schedule.exe  0 0 4  < ../inputs/input/dat460 > ../outputs/output.${1}/t1061
echo ">>>>>>>>running test 1062"
../source/schedule.exe  1 2 4  < ../inputs/input/dat461 > ../outputs/output.${1}/t1062
echo ">>>>>>>>running test 1063"
../source/schedule.exe  1 5 5  < ../inputs/input/dat462 > ../outputs/output.${1}/t1063
echo ">>>>>>>>running test 1064"
../source/schedule.exe  3 0 4  < ../inputs/input/dat463 > ../outputs/output.${1}/t1064
echo ">>>>>>>>running test 1065"
../source/schedule.exe  0 2 3  < ../inputs/input/dat464 > ../outputs/output.${1}/t1065
echo ">>>>>>>>running test 1066"
../source/schedule.exe  3 1 1  < ../inputs/input/dat465 > ../outputs/output.${1}/t1066
echo ">>>>>>>>running test 1067"
../source/schedule.exe  4 1 2  < ../inputs/input/dat466 > ../outputs/output.${1}/t1067
echo ">>>>>>>>running test 1068"
../source/schedule.exe  4 3 1  < ../inputs/input/dat467 > ../outputs/output.${1}/t1068
echo ">>>>>>>>running test 1069"
../source/schedule.exe  5 1 4  < ../inputs/input/dat468 > ../outputs/output.${1}/t1069
echo ">>>>>>>>running test 1070"
../source/schedule.exe  5 1 2  < ../inputs/input/dat469 > ../outputs/output.${1}/t1070
echo ">>>>>>>>running test 1071"
../source/schedule.exe  3 3 0  < ../inputs/input/dat470 > ../outputs/output.${1}/t1071
echo ">>>>>>>>running test 1072"
../source/schedule.exe  1 2 2  < ../inputs/input/dat471 > ../outputs/output.${1}/t1072
echo ">>>>>>>>running test 1073"
../source/schedule.exe  0 3 0  < ../inputs/input/dat472 > ../outputs/output.${1}/t1073
echo ">>>>>>>>running test 1074"
../source/schedule.exe  1 0 5  < ../inputs/input/dat473 > ../outputs/output.${1}/t1074
echo ">>>>>>>>running test 1075"
../source/schedule.exe  0 4 2  < ../inputs/input/dat474 > ../outputs/output.${1}/t1075
echo ">>>>>>>>running test 1076"
../source/schedule.exe  3 3 4  < ../inputs/input/dat475 > ../outputs/output.${1}/t1076
echo ">>>>>>>>running test 1077"
../source/schedule.exe  3 0 1  < ../inputs/input/dat476 > ../outputs/output.${1}/t1077
echo ">>>>>>>>running test 1078"
../source/schedule.exe  0 0 5  < ../inputs/input/dat477 > ../outputs/output.${1}/t1078
echo ">>>>>>>>running test 1079"
../source/schedule.exe  5 3 3  < ../inputs/input/dat478 > ../outputs/output.${1}/t1079
echo ">>>>>>>>running test 1080"
../source/schedule.exe  0 1 2  < ../inputs/input/dat479 > ../outputs/output.${1}/t1080
echo ">>>>>>>>running test 1081"
../source/schedule.exe  2 3 3  < ../inputs/input/dat480 > ../outputs/output.${1}/t1081
echo ">>>>>>>>running test 1082"
../source/schedule.exe  0 4 3  < ../inputs/input/dat481 > ../outputs/output.${1}/t1082
echo ">>>>>>>>running test 1083"
../source/schedule.exe  2 0 2  < ../inputs/input/dat482 > ../outputs/output.${1}/t1083
echo ">>>>>>>>running test 1084"
../source/schedule.exe  1 5 4  < ../inputs/input/dat483 > ../outputs/output.${1}/t1084
echo ">>>>>>>>running test 1085"
../source/schedule.exe  5 5 0  < ../inputs/input/dat484 > ../outputs/output.${1}/t1085
echo ">>>>>>>>running test 1086"
../source/schedule.exe  0 3 5  < ../inputs/input/dat485 > ../outputs/output.${1}/t1086
echo ">>>>>>>>running test 1087"
../source/schedule.exe  2 1 3  < ../inputs/input/dat486 > ../outputs/output.${1}/t1087
echo ">>>>>>>>running test 1088"
../source/schedule.exe  0 2 2  < ../inputs/input/dat487 > ../outputs/output.${1}/t1088
echo ">>>>>>>>running test 1089"
../source/schedule.exe  4 0 4  < ../inputs/input/dat488 > ../outputs/output.${1}/t1089
echo ">>>>>>>>running test 1090"
../source/schedule.exe  3 3 5  < ../inputs/input/dat489 > ../outputs/output.${1}/t1090
echo ">>>>>>>>running test 1091"
../source/schedule.exe  5 5 0  < ../inputs/input/dat490 > ../outputs/output.${1}/t1091
echo ">>>>>>>>running test 1092"
../source/schedule.exe  3 5 3  < ../inputs/input/dat491 > ../outputs/output.${1}/t1092
echo ">>>>>>>>running test 1093"
../source/schedule.exe  5 4 5  < ../inputs/input/dat492 > ../outputs/output.${1}/t1093
echo ">>>>>>>>running test 1094"
../source/schedule.exe  4 5 1  < ../inputs/input/dat493 > ../outputs/output.${1}/t1094
echo ">>>>>>>>running test 1095"
../source/schedule.exe  1 2 1  < ../inputs/input/dat494 > ../outputs/output.${1}/t1095
echo ">>>>>>>>running test 1096"
../source/schedule.exe  4 3 4  < ../inputs/input/dat495 > ../outputs/output.${1}/t1096
echo ">>>>>>>>running test 1097"
../source/schedule.exe  0 4 2  < ../inputs/input/dat496 > ../outputs/output.${1}/t1097
echo ">>>>>>>>running test 1098"
../source/schedule.exe  5 4 1  < ../inputs/input/dat497 > ../outputs/output.${1}/t1098
echo ">>>>>>>>running test 1099"
../source/schedule.exe  3 2 1  < ../inputs/input/dat498 > ../outputs/output.${1}/t1099
echo ">>>>>>>>running test 1100"
../source/schedule.exe  5 3 2  < ../inputs/input/dat499 > ../outputs/output.${1}/t1100
echo ">>>>>>>>running test 1101"
../source/schedule.exe  3 1 4  < ../inputs/input/dat500 > ../outputs/output.${1}/t1101
echo ">>>>>>>>running test 1102"
../source/schedule.exe  5 4 0  < ../inputs/input/dat501 > ../outputs/output.${1}/t1102
echo ">>>>>>>>running test 1103"
../source/schedule.exe  2 3 0  < ../inputs/input/dat502 > ../outputs/output.${1}/t1103
echo ">>>>>>>>running test 1104"
../source/schedule.exe  2 5 0  < ../inputs/input/dat503 > ../outputs/output.${1}/t1104
echo ">>>>>>>>running test 1105"
../source/schedule.exe  1 1 0  < ../inputs/input/dat504 > ../outputs/output.${1}/t1105
echo ">>>>>>>>running test 1106"
../source/schedule.exe  4 5 1  < ../inputs/input/dat505 > ../outputs/output.${1}/t1106
echo ">>>>>>>>running test 1107"
../source/schedule.exe  1 0 2  < ../inputs/input/dat506 > ../outputs/output.${1}/t1107
echo ">>>>>>>>running test 1108"
../source/schedule.exe  1 5 4  < ../inputs/input/dat507 > ../outputs/output.${1}/t1108
echo ">>>>>>>>running test 1109"
../source/schedule.exe  2 5 5  < ../inputs/input/dat508 > ../outputs/output.${1}/t1109
echo ">>>>>>>>running test 1110"
../source/schedule.exe  1 0 3  < ../inputs/input/dat509 > ../outputs/output.${1}/t1110
echo ">>>>>>>>running test 1111"
../source/schedule.exe  3 1 2  < ../inputs/input/dat510 > ../outputs/output.${1}/t1111
echo ">>>>>>>>running test 1112"
../source/schedule.exe  2 4 1  < ../inputs/input/dat511 > ../outputs/output.${1}/t1112
echo ">>>>>>>>running test 1113"
../source/schedule.exe  5 2 4  < ../inputs/input/dat512 > ../outputs/output.${1}/t1113
echo ">>>>>>>>running test 1114"
../source/schedule.exe  4 5 1  < ../inputs/input/dat513 > ../outputs/output.${1}/t1114
echo ">>>>>>>>running test 1115"
../source/schedule.exe  3 1 1  < ../inputs/input/dat514 > ../outputs/output.${1}/t1115
echo ">>>>>>>>running test 1116"
../source/schedule.exe  1 3 1  < ../inputs/input/dat515 > ../outputs/output.${1}/t1116
echo ">>>>>>>>running test 1117"
../source/schedule.exe  0 0 5  < ../inputs/input/dat516 > ../outputs/output.${1}/t1117
echo ">>>>>>>>running test 1118"
../source/schedule.exe  5 5 1  < ../inputs/input/dat517 > ../outputs/output.${1}/t1118
echo ">>>>>>>>running test 1119"
../source/schedule.exe  5 0 1  < ../inputs/input/dat518 > ../outputs/output.${1}/t1119
echo ">>>>>>>>running test 1120"
../source/schedule.exe  3 5 2  < ../inputs/input/dat519 > ../outputs/output.${1}/t1120
echo ">>>>>>>>running test 1121"
../source/schedule.exe  5 5 0  < ../inputs/input/dat520 > ../outputs/output.${1}/t1121
echo ">>>>>>>>running test 1122"
../source/schedule.exe  0 1 0  < ../inputs/input/dat521 > ../outputs/output.${1}/t1122
echo ">>>>>>>>running test 1123"
../source/schedule.exe  0 0 3  < ../inputs/input/dat522 > ../outputs/output.${1}/t1123
echo ">>>>>>>>running test 1124"
../source/schedule.exe  0 1 4  < ../inputs/input/dat523 > ../outputs/output.${1}/t1124
echo ">>>>>>>>running test 1125"
../source/schedule.exe  1 4 3  < ../inputs/input/dat524 > ../outputs/output.${1}/t1125
echo ">>>>>>>>running test 1126"
../source/schedule.exe  0 2 0  < ../inputs/input/dat525 > ../outputs/output.${1}/t1126
echo ">>>>>>>>running test 1127"
../source/schedule.exe  4 0 3  < ../inputs/input/dat526 > ../outputs/output.${1}/t1127
echo ">>>>>>>>running test 1128"
../source/schedule.exe  3 1 5  < ../inputs/input/dat527 > ../outputs/output.${1}/t1128
echo ">>>>>>>>running test 1129"
../source/schedule.exe  3 0 5  < ../inputs/input/dat528 > ../outputs/output.${1}/t1129
echo ">>>>>>>>running test 1130"
../source/schedule.exe  5 3 3  < ../inputs/input/dat529 > ../outputs/output.${1}/t1130
echo ">>>>>>>>running test 1131"
../source/schedule.exe  4 5 3  < ../inputs/input/dat530 > ../outputs/output.${1}/t1131
echo ">>>>>>>>running test 1132"
../source/schedule.exe  1 0 0  < ../inputs/input/dat531 > ../outputs/output.${1}/t1132
echo ">>>>>>>>running test 1133"
../source/schedule.exe  1 4 5  < ../inputs/input/dat532 > ../outputs/output.${1}/t1133
echo ">>>>>>>>running test 1134"
../source/schedule.exe  0 4 0  < ../inputs/input/dat533 > ../outputs/output.${1}/t1134
echo ">>>>>>>>running test 1135"
../source/schedule.exe  5 5 3  < ../inputs/input/dat534 > ../outputs/output.${1}/t1135
echo ">>>>>>>>running test 1136"
../source/schedule.exe  2 1 0  < ../inputs/input/dat535 > ../outputs/output.${1}/t1136
echo ">>>>>>>>running test 1137"
../source/schedule.exe  1 0 2  < ../inputs/input/dat536 > ../outputs/output.${1}/t1137
echo ">>>>>>>>running test 1138"
../source/schedule.exe  3 1 5  < ../inputs/input/dat537 > ../outputs/output.${1}/t1138
echo ">>>>>>>>running test 1139"
../source/schedule.exe  4 3 2  < ../inputs/input/dat538 > ../outputs/output.${1}/t1139
echo ">>>>>>>>running test 1140"
../source/schedule.exe  1 0 0  < ../inputs/input/dat539 > ../outputs/output.${1}/t1140
echo ">>>>>>>>running test 1141"
../source/schedule.exe  1 0 0  < ../inputs/input/dat540 > ../outputs/output.${1}/t1141
echo ">>>>>>>>running test 1142"
../source/schedule.exe  2 5 3  < ../inputs/input/dat541 > ../outputs/output.${1}/t1142
echo ">>>>>>>>running test 1143"
../source/schedule.exe  2 3 2  < ../inputs/input/dat542 > ../outputs/output.${1}/t1143
echo ">>>>>>>>running test 1144"
../source/schedule.exe  4 0 5  < ../inputs/input/dat543 > ../outputs/output.${1}/t1144
echo ">>>>>>>>running test 1145"
../source/schedule.exe  2 4 5  < ../inputs/input/dat544 > ../outputs/output.${1}/t1145
echo ">>>>>>>>running test 1146"
../source/schedule.exe  4 4 2  < ../inputs/input/dat545 > ../outputs/output.${1}/t1146
echo ">>>>>>>>running test 1147"
../source/schedule.exe  5 3 4  < ../inputs/input/dat546 > ../outputs/output.${1}/t1147
echo ">>>>>>>>running test 1148"
../source/schedule.exe  2 1 5  < ../inputs/input/dat547 > ../outputs/output.${1}/t1148
echo ">>>>>>>>running test 1149"
../source/schedule.exe  5 5 4  < ../inputs/input/dat548 > ../outputs/output.${1}/t1149
echo ">>>>>>>>running test 1150"
../source/schedule.exe  2 3 3  < ../inputs/input/dat549 > ../outputs/output.${1}/t1150
echo ">>>>>>>>running test 1151"
../source/schedule.exe  0 0 3  < ../inputs/input/dat550 > ../outputs/output.${1}/t1151
echo ">>>>>>>>running test 1152"
../source/schedule.exe  4 0 3  < ../inputs/input/dat551 > ../outputs/output.${1}/t1152
echo ">>>>>>>>running test 1153"
../source/schedule.exe  3 2 2  < ../inputs/input/dat552 > ../outputs/output.${1}/t1153
echo ">>>>>>>>running test 1154"
../source/schedule.exe  2 1 0  < ../inputs/input/dat553 > ../outputs/output.${1}/t1154
echo ">>>>>>>>running test 1155"
../source/schedule.exe  4 3 2  < ../inputs/input/dat554 > ../outputs/output.${1}/t1155
echo ">>>>>>>>running test 1156"
../source/schedule.exe  0 0 0  < ../inputs/input/dat555 > ../outputs/output.${1}/t1156
echo ">>>>>>>>running test 1157"
../source/schedule.exe  4 1 3  < ../inputs/input/dat556 > ../outputs/output.${1}/t1157
echo ">>>>>>>>running test 1158"
../source/schedule.exe  1 4 2  < ../inputs/input/dat557 > ../outputs/output.${1}/t1158
echo ">>>>>>>>running test 1159"
../source/schedule.exe  5 5 1  < ../inputs/input/dat558 > ../outputs/output.${1}/t1159
echo ">>>>>>>>running test 1160"
../source/schedule.exe  4 3 2  < ../inputs/input/dat559 > ../outputs/output.${1}/t1160
echo ">>>>>>>>running test 1161"
../source/schedule.exe  0 4 2  < ../inputs/input/dat560 > ../outputs/output.${1}/t1161
echo ">>>>>>>>running test 1162"
../source/schedule.exe  5 5 0  < ../inputs/input/dat561 > ../outputs/output.${1}/t1162
echo ">>>>>>>>running test 1163"
../source/schedule.exe  4 2 2  < ../inputs/input/dat562 > ../outputs/output.${1}/t1163
echo ">>>>>>>>running test 1164"
../source/schedule.exe  3 5 2  < ../inputs/input/dat563 > ../outputs/output.${1}/t1164
echo ">>>>>>>>running test 1165"
../source/schedule.exe  0 4 2  < ../inputs/input/dat564 > ../outputs/output.${1}/t1165
echo ">>>>>>>>running test 1166"
../source/schedule.exe  2 5 2  < ../inputs/input/dat565 > ../outputs/output.${1}/t1166
echo ">>>>>>>>running test 1167"
../source/schedule.exe  2 5 1  < ../inputs/input/dat566 > ../outputs/output.${1}/t1167
echo ">>>>>>>>running test 1168"
../source/schedule.exe  0 4 1  < ../inputs/input/dat567 > ../outputs/output.${1}/t1168
echo ">>>>>>>>running test 1169"
../source/schedule.exe  4 0 0  < ../inputs/input/dat568 > ../outputs/output.${1}/t1169
echo ">>>>>>>>running test 1170"
../source/schedule.exe  4 0 5  < ../inputs/input/dat569 > ../outputs/output.${1}/t1170
echo ">>>>>>>>running test 1171"
../source/schedule.exe  1 4 2  < ../inputs/input/dat570 > ../outputs/output.${1}/t1171
echo ">>>>>>>>running test 1172"
../source/schedule.exe  1 5 1  < ../inputs/input/dat571 > ../outputs/output.${1}/t1172
echo ">>>>>>>>running test 1173"
../source/schedule.exe  2 2 2  < ../inputs/input/dat572 > ../outputs/output.${1}/t1173
echo ">>>>>>>>running test 1174"
../source/schedule.exe  3 2 0  < ../inputs/input/dat573 > ../outputs/output.${1}/t1174
echo ">>>>>>>>running test 1175"
../source/schedule.exe  0 0 5  < ../inputs/input/dat574 > ../outputs/output.${1}/t1175
echo ">>>>>>>>running test 1176"
../source/schedule.exe  2 1 5  < ../inputs/input/dat575 > ../outputs/output.${1}/t1176
echo ">>>>>>>>running test 1177"
../source/schedule.exe  3 1 0  < ../inputs/input/dat576 > ../outputs/output.${1}/t1177
echo ">>>>>>>>running test 1178"
../source/schedule.exe  0 2 2  < ../inputs/input/dat577 > ../outputs/output.${1}/t1178
echo ">>>>>>>>running test 1179"
../source/schedule.exe  2 2 1  < ../inputs/input/dat578 > ../outputs/output.${1}/t1179
echo ">>>>>>>>running test 1180"
../source/schedule.exe  3 2 0  < ../inputs/input/dat579 > ../outputs/output.${1}/t1180
echo ">>>>>>>>running test 1181"
../source/schedule.exe  3 3 2  < ../inputs/input/dat580 > ../outputs/output.${1}/t1181
echo ">>>>>>>>running test 1182"
../source/schedule.exe  2 2 1  < ../inputs/input/dat581 > ../outputs/output.${1}/t1182
echo ">>>>>>>>running test 1183"
../source/schedule.exe  3 1 3  < ../inputs/input/dat582 > ../outputs/output.${1}/t1183
echo ">>>>>>>>running test 1184"
../source/schedule.exe  1 2 2  < ../inputs/input/dat583 > ../outputs/output.${1}/t1184
echo ">>>>>>>>running test 1185"
../source/schedule.exe  5 4 4  < ../inputs/input/dat584 > ../outputs/output.${1}/t1185
echo ">>>>>>>>running test 1186"
../source/schedule.exe  3 0 5  < ../inputs/input/dat585 > ../outputs/output.${1}/t1186
echo ">>>>>>>>running test 1187"
../source/schedule.exe  1 0 3  < ../inputs/input/dat586 > ../outputs/output.${1}/t1187
echo ">>>>>>>>running test 1188"
../source/schedule.exe  2 3 4  < ../inputs/input/dat587 > ../outputs/output.${1}/t1188
echo ">>>>>>>>running test 1189"
../source/schedule.exe  5 1 0  < ../inputs/input/dat588 > ../outputs/output.${1}/t1189
echo ">>>>>>>>running test 1190"
../source/schedule.exe  3 3 1  < ../inputs/input/dat589 > ../outputs/output.${1}/t1190
echo ">>>>>>>>running test 1191"
../source/schedule.exe  1 4 2  < ../inputs/input/dat590 > ../outputs/output.${1}/t1191
echo ">>>>>>>>running test 1192"
../source/schedule.exe  5 0 4  < ../inputs/input/dat591 > ../outputs/output.${1}/t1192
echo ">>>>>>>>running test 1193"
../source/schedule.exe  5 3 5  < ../inputs/input/dat592 > ../outputs/output.${1}/t1193
echo ">>>>>>>>running test 1194"
../source/schedule.exe  2 0 0  < ../inputs/input/dat593 > ../outputs/output.${1}/t1194
echo ">>>>>>>>running test 1195"
../source/schedule.exe  5 2 4  < ../inputs/input/dat594 > ../outputs/output.${1}/t1195
echo ">>>>>>>>running test 1196"
../source/schedule.exe  3 5 3  < ../inputs/input/dat595 > ../outputs/output.${1}/t1196
echo ">>>>>>>>running test 1197"
../source/schedule.exe  5 1 1  < ../inputs/input/dat596 > ../outputs/output.${1}/t1197
echo ">>>>>>>>running test 1198"
../source/schedule.exe  4 5 0  < ../inputs/input/dat597 > ../outputs/output.${1}/t1198
echo ">>>>>>>>running test 1199"
../source/schedule.exe  3 2 5  < ../inputs/input/dat598 > ../outputs/output.${1}/t1199
echo ">>>>>>>>running test 1200"
../source/schedule.exe  2 0 3  < ../inputs/input/dat599 > ../outputs/output.${1}/t1200
echo ">>>>>>>>running test 1201"
../source/schedule.exe  0 1 2  < ../inputs/input/dat600 > ../outputs/output.${1}/t1201
echo ">>>>>>>>running test 1202"
../source/schedule.exe  0 1 0  < ../inputs/input/dat601 > ../outputs/output.${1}/t1202
echo ">>>>>>>>running test 1203"
../source/schedule.exe  1 4 2  < ../inputs/input/dat602 > ../outputs/output.${1}/t1203
echo ">>>>>>>>running test 1204"
../source/schedule.exe  2 3 5  < ../inputs/input/dat603 > ../outputs/output.${1}/t1204
echo ">>>>>>>>running test 1205"
../source/schedule.exe  3 1 0  < ../inputs/input/dat604 > ../outputs/output.${1}/t1205
echo ">>>>>>>>running test 1206"
../source/schedule.exe  1 5 1  < ../inputs/input/dat605 > ../outputs/output.${1}/t1206
echo ">>>>>>>>running test 1207"
../source/schedule.exe  2 0 3  < ../inputs/input/dat606 > ../outputs/output.${1}/t1207
echo ">>>>>>>>running test 1208"
../source/schedule.exe  3 4 1  < ../inputs/input/dat607 > ../outputs/output.${1}/t1208
echo ">>>>>>>>running test 1209"
../source/schedule.exe  5 4 3  < ../inputs/input/dat608 > ../outputs/output.${1}/t1209
echo ">>>>>>>>running test 1210"
../source/schedule.exe  1 1 5  < ../inputs/input/dat609 > ../outputs/output.${1}/t1210
echo ">>>>>>>>running test 1211"
../source/schedule.exe  5 4 3  < ../inputs/input/dat610 > ../outputs/output.${1}/t1211
echo ">>>>>>>>running test 1212"
../source/schedule.exe  3 1 5  < ../inputs/input/dat612 > ../outputs/output.${1}/t1212
echo ">>>>>>>>running test 1213"
../source/schedule.exe  0 1 5  < ../inputs/input/dat613 > ../outputs/output.${1}/t1213
echo ">>>>>>>>running test 1214"
../source/schedule.exe  4 4 0  < ../inputs/input/dat614 > ../outputs/output.${1}/t1214
echo ">>>>>>>>running test 1215"
../source/schedule.exe  5 1 5  < ../inputs/input/dat615 > ../outputs/output.${1}/t1215
echo ">>>>>>>>running test 1216"
../source/schedule.exe  3 3 5  < ../inputs/input/dat616 > ../outputs/output.${1}/t1216
echo ">>>>>>>>running test 1217"
../source/schedule.exe  1 0 1  < ../inputs/input/dat617 > ../outputs/output.${1}/t1217
echo ">>>>>>>>running test 1218"
../source/schedule.exe  5 3 0  < ../inputs/input/dat618 > ../outputs/output.${1}/t1218
echo ">>>>>>>>running test 1219"
../source/schedule.exe  0 4 0  < ../inputs/input/dat619 > ../outputs/output.${1}/t1219
echo ">>>>>>>>running test 1220"
../source/schedule.exe  1 2 3  < ../inputs/input/dat620 > ../outputs/output.${1}/t1220
echo ">>>>>>>>running test 1221"
../source/schedule.exe  2 2 3  < ../inputs/input/dat621 > ../outputs/output.${1}/t1221
echo ">>>>>>>>running test 1222"
../source/schedule.exe  0 0 0  < ../inputs/input/dat622 > ../outputs/output.${1}/t1222
echo ">>>>>>>>running test 1223"
../source/schedule.exe  5 5 3  < ../inputs/input/dat623 > ../outputs/output.${1}/t1223
echo ">>>>>>>>running test 1224"
../source/schedule.exe  1 0 5  < ../inputs/input/dat624 > ../outputs/output.${1}/t1224
echo ">>>>>>>>running test 1225"
../source/schedule.exe  0 4 5  < ../inputs/input/dat625 > ../outputs/output.${1}/t1225
echo ">>>>>>>>running test 1226"
../source/schedule.exe  3 5 3  < ../inputs/input/dat626 > ../outputs/output.${1}/t1226
echo ">>>>>>>>running test 1227"
../source/schedule.exe  5 0 3  < ../inputs/input/dat627 > ../outputs/output.${1}/t1227
echo ">>>>>>>>running test 1228"
../source/schedule.exe  3 4 1  < ../inputs/input/dat628 > ../outputs/output.${1}/t1228
echo ">>>>>>>>running test 1229"
../source/schedule.exe  4 5 5  < ../inputs/input/dat629 > ../outputs/output.${1}/t1229
echo ">>>>>>>>running test 1230"
../source/schedule.exe  3 0 5  < ../inputs/input/dat630 > ../outputs/output.${1}/t1230
echo ">>>>>>>>running test 1231"
../source/schedule.exe  4 4 3  < ../inputs/input/dat631 > ../outputs/output.${1}/t1231
echo ">>>>>>>>running test 1232"
../source/schedule.exe  4 1 5  < ../inputs/input/dat632 > ../outputs/output.${1}/t1232
echo ">>>>>>>>running test 1233"
../source/schedule.exe  3 2 1  < ../inputs/input/dat633 > ../outputs/output.${1}/t1233
echo ">>>>>>>>running test 1234"
../source/schedule.exe  4 5 4  < ../inputs/input/dat634 > ../outputs/output.${1}/t1234
echo ">>>>>>>>running test 1235"
../source/schedule.exe  1 0 2  < ../inputs/input/dat635 > ../outputs/output.${1}/t1235
echo ">>>>>>>>running test 1236"
../source/schedule.exe  5 4 5  < ../inputs/input/dat636 > ../outputs/output.${1}/t1236
echo ">>>>>>>>running test 1237"
../source/schedule.exe  4 5 1  < ../inputs/input/dat637 > ../outputs/output.${1}/t1237
echo ">>>>>>>>running test 1238"
../source/schedule.exe  0 2 0  < ../inputs/input/dat638 > ../outputs/output.${1}/t1238
echo ">>>>>>>>running test 1239"
../source/schedule.exe  1 3 4  < ../inputs/input/dat639 > ../outputs/output.${1}/t1239
echo ">>>>>>>>running test 1240"
../source/schedule.exe  0 0 4  < ../inputs/input/dat640 > ../outputs/output.${1}/t1240
echo ">>>>>>>>running test 1241"
../source/schedule.exe  3 4 4  < ../inputs/input/dat641 > ../outputs/output.${1}/t1241
echo ">>>>>>>>running test 1242"
../source/schedule.exe  2 5 0  < ../inputs/input/dat642 > ../outputs/output.${1}/t1242
echo ">>>>>>>>running test 1243"
../source/schedule.exe  5 3 0  < ../inputs/input/dat643 > ../outputs/output.${1}/t1243
echo ">>>>>>>>running test 1244"
../source/schedule.exe  1 3 3  < ../inputs/input/dat644 > ../outputs/output.${1}/t1244
echo ">>>>>>>>running test 1245"
../source/schedule.exe  3 5 1  < ../inputs/input/dat645 > ../outputs/output.${1}/t1245
echo ">>>>>>>>running test 1246"
../source/schedule.exe  0 1 2  < ../inputs/input/dat646 > ../outputs/output.${1}/t1246
echo ">>>>>>>>running test 1247"
../source/schedule.exe  5 5 2  < ../inputs/input/dat647 > ../outputs/output.${1}/t1247
echo ">>>>>>>>running test 1248"
../source/schedule.exe  4 2 3  < ../inputs/input/dat648 > ../outputs/output.${1}/t1248
echo ">>>>>>>>running test 1249"
../source/schedule.exe  4 3 5  < ../inputs/input/dat649 > ../outputs/output.${1}/t1249
echo ">>>>>>>>running test 1250"
../source/schedule.exe  2 1 2  < ../inputs/input/dat650 > ../outputs/output.${1}/t1250
echo ">>>>>>>>running test 1251"
../source/schedule.exe  4 4 4  < ../inputs/input/dat651 > ../outputs/output.${1}/t1251
echo ">>>>>>>>running test 1252"
../source/schedule.exe  4 1 2  < ../inputs/input/dat652 > ../outputs/output.${1}/t1252
echo ">>>>>>>>running test 1253"
../source/schedule.exe  2 5 4  < ../inputs/input/dat653 > ../outputs/output.${1}/t1253
echo ">>>>>>>>running test 1254"
../source/schedule.exe  5 3 2  < ../inputs/input/dat654 > ../outputs/output.${1}/t1254
echo ">>>>>>>>running test 1255"
../source/schedule.exe  1 5 0  < ../inputs/input/dat655 > ../outputs/output.${1}/t1255
echo ">>>>>>>>running test 1256"
../source/schedule.exe  0 4 5  < ../inputs/input/dat656 > ../outputs/output.${1}/t1256
echo ">>>>>>>>running test 1257"
../source/schedule.exe  3 3 4  < ../inputs/input/dat657 > ../outputs/output.${1}/t1257
echo ">>>>>>>>running test 1258"
../source/schedule.exe  0 3 3  < ../inputs/input/dat658 > ../outputs/output.${1}/t1258
echo ">>>>>>>>running test 1259"
../source/schedule.exe  3 2 0  < ../inputs/input/dat659 > ../outputs/output.${1}/t1259
echo ">>>>>>>>running test 1260"
../source/schedule.exe  0 0 3  < ../inputs/input/dat660 > ../outputs/output.${1}/t1260
echo ">>>>>>>>running test 1261"
../source/schedule.exe  3 4 1  < ../inputs/input/dat661 > ../outputs/output.${1}/t1261
echo ">>>>>>>>running test 1262"
../source/schedule.exe  5 0 5  < ../inputs/input/dat662 > ../outputs/output.${1}/t1262
echo ">>>>>>>>running test 1263"
../source/schedule.exe  3 3 4  < ../inputs/input/dat663 > ../outputs/output.${1}/t1263
echo ">>>>>>>>running test 1264"
../source/schedule.exe  3 5 1  < ../inputs/input/dat664 > ../outputs/output.${1}/t1264
echo ">>>>>>>>running test 1265"
../source/schedule.exe  4 4 0  < ../inputs/input/dat665 > ../outputs/output.${1}/t1265
echo ">>>>>>>>running test 1266"
../source/schedule.exe  3 1 1  < ../inputs/input/dat666 > ../outputs/output.${1}/t1266
echo ">>>>>>>>running test 1267"
../source/schedule.exe  4 4 3  < ../inputs/input/dat667 > ../outputs/output.${1}/t1267
echo ">>>>>>>>running test 1268"
../source/schedule.exe  2 2 1  < ../inputs/input/dat668 > ../outputs/output.${1}/t1268
echo ">>>>>>>>running test 1269"
../source/schedule.exe  2 4 3  < ../inputs/input/dat669 > ../outputs/output.${1}/t1269
echo ">>>>>>>>running test 1270"
../source/schedule.exe  4 0 2  < ../inputs/input/dat670 > ../outputs/output.${1}/t1270
echo ">>>>>>>>running test 1271"
../source/schedule.exe  4 0 4  < ../inputs/input/dat671 > ../outputs/output.${1}/t1271
echo ">>>>>>>>running test 1272"
../source/schedule.exe  0 2 2  < ../inputs/input/dat672 > ../outputs/output.${1}/t1272
echo ">>>>>>>>running test 1273"
../source/schedule.exe  5 0 3  < ../inputs/input/dat673 > ../outputs/output.${1}/t1273
echo ">>>>>>>>running test 1274"
../source/schedule.exe  1 1 1  < ../inputs/input/dat674 > ../outputs/output.${1}/t1274
echo ">>>>>>>>running test 1275"
../source/schedule.exe  3 5 1  < ../inputs/input/dat675 > ../outputs/output.${1}/t1275
echo ">>>>>>>>running test 1276"
../source/schedule.exe  1 1 3  < ../inputs/input/dat676 > ../outputs/output.${1}/t1276
echo ">>>>>>>>running test 1277"
../source/schedule.exe  5 3 0  < ../inputs/input/dat677 > ../outputs/output.${1}/t1277
echo ">>>>>>>>running test 1278"
../source/schedule.exe  2 3 1  < ../inputs/input/dat678 > ../outputs/output.${1}/t1278
echo ">>>>>>>>running test 1279"
../source/schedule.exe  0 3 3  < ../inputs/input/dat679 > ../outputs/output.${1}/t1279
echo ">>>>>>>>running test 1280"
../source/schedule.exe  2 5 1  < ../inputs/input/dat680 > ../outputs/output.${1}/t1280
echo ">>>>>>>>running test 1281"
../source/schedule.exe  5 4 3  < ../inputs/input/dat681 > ../outputs/output.${1}/t1281
echo ">>>>>>>>running test 1282"
../source/schedule.exe  3 0 0  < ../inputs/input/dat682 > ../outputs/output.${1}/t1282
echo ">>>>>>>>running test 1283"
../source/schedule.exe  2 3 0  < ../inputs/input/dat683 > ../outputs/output.${1}/t1283
echo ">>>>>>>>running test 1284"
../source/schedule.exe  0 3 3  < ../inputs/input/dat684 > ../outputs/output.${1}/t1284
echo ">>>>>>>>running test 1285"
../source/schedule.exe  1 1 0  < ../inputs/input/dat685 > ../outputs/output.${1}/t1285
echo ">>>>>>>>running test 1286"
../source/schedule.exe  0 0 1  < ../inputs/input/dat686 > ../outputs/output.${1}/t1286
echo ">>>>>>>>running test 1287"
../source/schedule.exe  0 3 1  < ../inputs/input/dat687 > ../outputs/output.${1}/t1287
echo ">>>>>>>>running test 1288"
../source/schedule.exe  5 2 4  < ../inputs/input/dat688 > ../outputs/output.${1}/t1288
echo ">>>>>>>>running test 1289"
../source/schedule.exe  5 1 4  < ../inputs/input/dat689 > ../outputs/output.${1}/t1289
echo ">>>>>>>>running test 1290"
../source/schedule.exe  2 5 1  < ../inputs/input/dat690 > ../outputs/output.${1}/t1290
echo ">>>>>>>>running test 1291"
../source/schedule.exe  0 5 5  < ../inputs/input/dat691 > ../outputs/output.${1}/t1291
echo ">>>>>>>>running test 1292"
../source/schedule.exe  3 0 0  < ../inputs/input/dat692 > ../outputs/output.${1}/t1292
echo ">>>>>>>>running test 1293"
../source/schedule.exe  3 2 4  < ../inputs/input/dat693 > ../outputs/output.${1}/t1293
echo ">>>>>>>>running test 1294"
../source/schedule.exe  3 1 5  < ../inputs/input/dat694 > ../outputs/output.${1}/t1294
echo ">>>>>>>>running test 1295"
../source/schedule.exe  4 1 2  < ../inputs/input/dat695 > ../outputs/output.${1}/t1295
echo ">>>>>>>>running test 1296"
../source/schedule.exe  2 3 5  < ../inputs/input/dat696 > ../outputs/output.${1}/t1296
echo ">>>>>>>>running test 1297"
../source/schedule.exe  3 1 1  < ../inputs/input/dat697 > ../outputs/output.${1}/t1297
echo ">>>>>>>>running test 1298"
../source/schedule.exe  2 2 1  < ../inputs/input/dat698 > ../outputs/output.${1}/t1298
echo ">>>>>>>>running test 1299"
../source/schedule.exe  0 1 3  < ../inputs/input/dat699 > ../outputs/output.${1}/t1299
echo ">>>>>>>>running test 1300"
../source/schedule.exe  1 1 5  < ../inputs/input/dat700 > ../outputs/output.${1}/t1300
echo ">>>>>>>>running test 1301"
../source/schedule.exe  2 0 3  < ../inputs/input/dat701 > ../outputs/output.${1}/t1301
echo ">>>>>>>>running test 1302"
../source/schedule.exe  0 2 1  < ../inputs/input/dat702 > ../outputs/output.${1}/t1302
echo ">>>>>>>>running test 1303"
../source/schedule.exe  2 0 4  < ../inputs/input/dat703 > ../outputs/output.${1}/t1303
echo ">>>>>>>>running test 1304"
../source/schedule.exe  3 4 5  < ../inputs/input/dat704 > ../outputs/output.${1}/t1304
echo ">>>>>>>>running test 1305"
../source/schedule.exe  5 5 0  < ../inputs/input/dat705 > ../outputs/output.${1}/t1305
echo ">>>>>>>>running test 1306"
../source/schedule.exe  3 5 2  < ../inputs/input/dat706 > ../outputs/output.${1}/t1306
echo ">>>>>>>>running test 1307"
../source/schedule.exe  0 2 3  < ../inputs/input/dat707 > ../outputs/output.${1}/t1307
echo ">>>>>>>>running test 1308"
../source/schedule.exe  4 1 1  < ../inputs/input/dat708 > ../outputs/output.${1}/t1308
echo ">>>>>>>>running test 1309"
../source/schedule.exe  3 0 2  < ../inputs/input/dat709 > ../outputs/output.${1}/t1309
echo ">>>>>>>>running test 1310"
../source/schedule.exe  1 1 3  < ../inputs/input/dat710 > ../outputs/output.${1}/t1310
echo ">>>>>>>>running test 1311"
../source/schedule.exe  0 0 3  < ../inputs/input/dat711 > ../outputs/output.${1}/t1311
echo ">>>>>>>>running test 1312"
../source/schedule.exe  4 2 2  < ../inputs/input/dat712 > ../outputs/output.${1}/t1312
echo ">>>>>>>>running test 1313"
../source/schedule.exe  5 1 3  < ../inputs/input/dat713 > ../outputs/output.${1}/t1313
echo ">>>>>>>>running test 1314"
../source/schedule.exe  4 4 0  < ../inputs/input/dat714 > ../outputs/output.${1}/t1314
echo ">>>>>>>>running test 1315"
../source/schedule.exe  5 0 0  < ../inputs/input/dat715 > ../outputs/output.${1}/t1315
echo ">>>>>>>>running test 1316"
../source/schedule.exe  0 1 3  < ../inputs/input/dat716 > ../outputs/output.${1}/t1316
echo ">>>>>>>>running test 1317"
../source/schedule.exe  0 5 2  < ../inputs/input/dat717 > ../outputs/output.${1}/t1317
echo ">>>>>>>>running test 1318"
../source/schedule.exe  1 5 2  < ../inputs/input/dat718 > ../outputs/output.${1}/t1318
echo ">>>>>>>>running test 1319"
../source/schedule.exe  0 5 3  < ../inputs/input/dat719 > ../outputs/output.${1}/t1319
echo ">>>>>>>>running test 1320"
../source/schedule.exe  3 3 4  < ../inputs/input/dat720 > ../outputs/output.${1}/t1320
echo ">>>>>>>>running test 1321"
../source/schedule.exe  2 5 4  < ../inputs/input/dat721 > ../outputs/output.${1}/t1321
echo ">>>>>>>>running test 1322"
../source/schedule.exe  4 4 1  < ../inputs/input/dat722 > ../outputs/output.${1}/t1322
echo ">>>>>>>>running test 1323"
../source/schedule.exe  0 1 5  < ../inputs/input/dat723 > ../outputs/output.${1}/t1323
echo ">>>>>>>>running test 1324"
../source/schedule.exe  2 1 0  < ../inputs/input/dat724 > ../outputs/output.${1}/t1324
echo ">>>>>>>>running test 1325"
../source/schedule.exe  3 1 5  < ../inputs/input/dat725 > ../outputs/output.${1}/t1325
echo ">>>>>>>>running test 1326"
../source/schedule.exe  2 0 3  < ../inputs/input/dat726 > ../outputs/output.${1}/t1326
echo ">>>>>>>>running test 1327"
../source/schedule.exe  5 3 0  < ../inputs/input/dat727 > ../outputs/output.${1}/t1327
echo ">>>>>>>>running test 1328"
../source/schedule.exe  2 2 5  < ../inputs/input/dat728 > ../outputs/output.${1}/t1328
echo ">>>>>>>>running test 1329"
../source/schedule.exe  0 0 2  < ../inputs/input/dat729 > ../outputs/output.${1}/t1329
echo ">>>>>>>>running test 1330"
../source/schedule.exe  0 5 1  < ../inputs/input/dat730 > ../outputs/output.${1}/t1330
echo ">>>>>>>>running test 1331"
../source/schedule.exe  0 2 3  < ../inputs/input/dat731 > ../outputs/output.${1}/t1331
echo ">>>>>>>>running test 1332"
../source/schedule.exe  0 4 5  < ../inputs/input/dat732 > ../outputs/output.${1}/t1332
echo ">>>>>>>>running test 1333"
../source/schedule.exe  3 5 4  < ../inputs/input/dat733 > ../outputs/output.${1}/t1333
echo ">>>>>>>>running test 1334"
../source/schedule.exe  2 5 0  < ../inputs/input/dat734 > ../outputs/output.${1}/t1334
echo ">>>>>>>>running test 1335"
../source/schedule.exe  3 3 3  < ../inputs/input/dat735 > ../outputs/output.${1}/t1335
echo ">>>>>>>>running test 1336"
../source/schedule.exe  2 1 1  < ../inputs/input/dat736 > ../outputs/output.${1}/t1336
echo ">>>>>>>>running test 1337"
../source/schedule.exe  2 2 1  < ../inputs/input/dat737 > ../outputs/output.${1}/t1337
echo ">>>>>>>>running test 1338"
../source/schedule.exe  5 4 1  < ../inputs/input/dat738 > ../outputs/output.${1}/t1338
echo ">>>>>>>>running test 1339"
../source/schedule.exe  3 3 0  < ../inputs/input/dat739 > ../outputs/output.${1}/t1339
echo ">>>>>>>>running test 1340"
../source/schedule.exe  0 0 1  < ../inputs/input/dat740 > ../outputs/output.${1}/t1340
echo ">>>>>>>>running test 1341"
../source/schedule.exe  5 3 2  < ../inputs/input/dat741 > ../outputs/output.${1}/t1341
echo ">>>>>>>>running test 1342"
../source/schedule.exe  5 5 5  < ../inputs/input/dat742 > ../outputs/output.${1}/t1342
echo ">>>>>>>>running test 1343"
../source/schedule.exe  5 4 3  < ../inputs/input/dat743 > ../outputs/output.${1}/t1343
echo ">>>>>>>>running test 1344"
../source/schedule.exe  4 3 2  < ../inputs/input/dat744 > ../outputs/output.${1}/t1344
echo ">>>>>>>>running test 1345"
../source/schedule.exe  5 5 4  < ../inputs/input/dat745 > ../outputs/output.${1}/t1345
echo ">>>>>>>>running test 1346"
../source/schedule.exe  1 1 5  < ../inputs/input/dat746 > ../outputs/output.${1}/t1346
echo ">>>>>>>>running test 1347"
../source/schedule.exe  0 4 4  < ../inputs/input/dat747 > ../outputs/output.${1}/t1347
echo ">>>>>>>>running test 1348"
../source/schedule.exe  0 0 1  < ../inputs/input/dat748 > ../outputs/output.${1}/t1348
echo ">>>>>>>>running test 1349"
../source/schedule.exe  4 5 3  < ../inputs/input/dat749 > ../outputs/output.${1}/t1349
echo ">>>>>>>>running test 1350"
../source/schedule.exe  4 4 5  < ../inputs/input/dat750 > ../outputs/output.${1}/t1350
echo ">>>>>>>>running test 1351"
../source/schedule.exe  3 1 5  < ../inputs/input/dat751 > ../outputs/output.${1}/t1351
echo ">>>>>>>>running test 1352"
../source/schedule.exe  4 4 2  < ../inputs/input/dat752 > ../outputs/output.${1}/t1352
echo ">>>>>>>>running test 1353"
../source/schedule.exe  2 1 0  < ../inputs/input/dat753 > ../outputs/output.${1}/t1353
echo ">>>>>>>>running test 1354"
../source/schedule.exe  2 1 2  < ../inputs/input/dat754 > ../outputs/output.${1}/t1354
echo ">>>>>>>>running test 1355"
../source/schedule.exe  0 4 1  < ../inputs/input/dat755 > ../outputs/output.${1}/t1355
echo ">>>>>>>>running test 1356"
../source/schedule.exe  4 1 0  < ../inputs/input/dat756 > ../outputs/output.${1}/t1356
echo ">>>>>>>>running test 1357"
../source/schedule.exe  5 5 2  < ../inputs/input/dat757 > ../outputs/output.${1}/t1357
echo ">>>>>>>>running test 1358"
../source/schedule.exe  2 4 5  < ../inputs/input/dat758 > ../outputs/output.${1}/t1358
echo ">>>>>>>>running test 1359"
../source/schedule.exe  3 5 0  < ../inputs/input/dat759 > ../outputs/output.${1}/t1359
echo ">>>>>>>>running test 1360"
../source/schedule.exe  1 2 4  < ../inputs/input/dat760 > ../outputs/output.${1}/t1360
echo ">>>>>>>>running test 1361"
../source/schedule.exe  3 4 4  < ../inputs/input/dat761 > ../outputs/output.${1}/t1361
echo ">>>>>>>>running test 1362"
../source/schedule.exe  4 2 1  < ../inputs/input/dat762 > ../outputs/output.${1}/t1362
echo ">>>>>>>>running test 1363"
../source/schedule.exe  3 3 0  < ../inputs/input/dat763 > ../outputs/output.${1}/t1363
echo ">>>>>>>>running test 1364"
../source/schedule.exe  3 4 3  < ../inputs/input/dat764 > ../outputs/output.${1}/t1364
echo ">>>>>>>>running test 1365"
../source/schedule.exe  0 5 5  < ../inputs/input/dat765 > ../outputs/output.${1}/t1365
echo ">>>>>>>>running test 1366"
../source/schedule.exe  5 4 0  < ../inputs/input/dat766 > ../outputs/output.${1}/t1366
echo ">>>>>>>>running test 1367"
../source/schedule.exe  0 3 2  < ../inputs/input/dat767 > ../outputs/output.${1}/t1367
echo ">>>>>>>>running test 1368"
../source/schedule.exe  2 3 0  < ../inputs/input/dat768 > ../outputs/output.${1}/t1368
echo ">>>>>>>>running test 1369"
../source/schedule.exe  5 0 1  < ../inputs/input/dat769 > ../outputs/output.${1}/t1369
echo ">>>>>>>>running test 1370"
../source/schedule.exe  0 5 1  < ../inputs/input/dat770 > ../outputs/output.${1}/t1370
echo ">>>>>>>>running test 1371"
../source/schedule.exe  4 4 5  < ../inputs/input/dat771 > ../outputs/output.${1}/t1371
echo ">>>>>>>>running test 1372"
../source/schedule.exe  0 2 2  < ../inputs/input/dat772 > ../outputs/output.${1}/t1372
echo ">>>>>>>>running test 1373"
../source/schedule.exe  1 1 1  < ../inputs/input/dat773 > ../outputs/output.${1}/t1373
echo ">>>>>>>>running test 1374"
../source/schedule.exe  0 2 0  < ../inputs/input/dat774 > ../outputs/output.${1}/t1374
echo ">>>>>>>>running test 1375"
../source/schedule.exe  0 3 0  < ../inputs/input/dat775 > ../outputs/output.${1}/t1375
echo ">>>>>>>>running test 1376"
../source/schedule.exe  4 5 2  < ../inputs/input/dat776 > ../outputs/output.${1}/t1376
echo ">>>>>>>>running test 1377"
../source/schedule.exe  4 2 1  < ../inputs/input/dat777 > ../outputs/output.${1}/t1377
echo ">>>>>>>>running test 1378"
../source/schedule.exe  2 2 5  < ../inputs/input/dat778 > ../outputs/output.${1}/t1378
echo ">>>>>>>>running test 1379"
../source/schedule.exe  5 2 3  < ../inputs/input/dat779 > ../outputs/output.${1}/t1379
echo ">>>>>>>>running test 1380"
../source/schedule.exe  3 1 2  < ../inputs/input/dat780 > ../outputs/output.${1}/t1380
echo ">>>>>>>>running test 1381"
../source/schedule.exe  3 0 3  < ../inputs/input/dat781 > ../outputs/output.${1}/t1381
echo ">>>>>>>>running test 1382"
../source/schedule.exe  5 4 3  < ../inputs/input/dat782 > ../outputs/output.${1}/t1382
echo ">>>>>>>>running test 1383"
../source/schedule.exe  1 3 2  < ../inputs/input/dat783 > ../outputs/output.${1}/t1383
echo ">>>>>>>>running test 1384"
../source/schedule.exe  3 0 0  < ../inputs/input/dat784 > ../outputs/output.${1}/t1384
echo ">>>>>>>>running test 1385"
../source/schedule.exe  4 2 5  < ../inputs/input/dat785 > ../outputs/output.${1}/t1385
echo ">>>>>>>>running test 1386"
../source/schedule.exe  4 3 5  < ../inputs/input/dat786 > ../outputs/output.${1}/t1386
echo ">>>>>>>>running test 1387"
../source/schedule.exe  4 2 4  < ../inputs/input/dat787 > ../outputs/output.${1}/t1387
echo ">>>>>>>>running test 1388"
../source/schedule.exe  1 5 4  < ../inputs/input/dat788 > ../outputs/output.${1}/t1388
echo ">>>>>>>>running test 1389"
../source/schedule.exe  4 0 1  < ../inputs/input/dat789 > ../outputs/output.${1}/t1389
echo ">>>>>>>>running test 1390"
../source/schedule.exe  3 5 4  < ../inputs/input/dat790 > ../outputs/output.${1}/t1390
echo ">>>>>>>>running test 1391"
../source/schedule.exe  2 3 5  < ../inputs/input/dat791 > ../outputs/output.${1}/t1391
echo ">>>>>>>>running test 1392"
../source/schedule.exe  1 3 0  < ../inputs/input/dat792 > ../outputs/output.${1}/t1392
echo ">>>>>>>>running test 1393"
../source/schedule.exe  0 2 4  < ../inputs/input/dat793 > ../outputs/output.${1}/t1393
echo ">>>>>>>>running test 1394"
../source/schedule.exe  2 4 1  < ../inputs/input/dat794 > ../outputs/output.${1}/t1394
echo ">>>>>>>>running test 1395"
../source/schedule.exe  2 0 0  < ../inputs/input/dat795 > ../outputs/output.${1}/t1395
echo ">>>>>>>>running test 1396"
../source/schedule.exe  5 0 2  < ../inputs/input/dat796 > ../outputs/output.${1}/t1396
echo ">>>>>>>>running test 1397"
../source/schedule.exe  5 0 1  < ../inputs/input/dat797 > ../outputs/output.${1}/t1397
echo ">>>>>>>>running test 1398"
../source/schedule.exe  0 4 5  < ../inputs/input/dat798 > ../outputs/output.${1}/t1398
echo ">>>>>>>>running test 1399"
../source/schedule.exe  5 5 3  < ../inputs/input/dat800 > ../outputs/output.${1}/t1399
echo ">>>>>>>>running test 1400"
../source/schedule.exe  2 2 1  < ../inputs/input/dat799 > ../outputs/output.${1}/t1400
echo ">>>>>>>>running test 1401"
../source/schedule.exe 1 1 1  < ../inputs/input/ad.1 > ../outputs/output.${1}/t1401
echo ">>>>>>>>running test 1402"
../source/schedule.exe 1 1 0  < ../inputs/input/ad.2 > ../outputs/output.${1}/t1402
echo ">>>>>>>>running test 1403"
../source/schedule.exe 1 2  < ../inputs/input/ad.1 > ../outputs/output.${1}/t1403
echo ">>>>>>>>running test 1404"
../source/schedule.exe 1  < ../inputs/input/ad.1 > ../outputs/output.${1}/t1404
echo ">>>>>>>>running test 1405"
../source/schedule.exe  < ../inputs/input/ad.1 > ../outputs/output.${1}/t1405
echo ">>>>>>>>running test 1406"
../source/schedule.exe 1 2 3 4  < ../inputs/input/ad.1 > ../outputs/output.${1}/t1406
echo ">>>>>>>>running test 1407"
../source/schedule.exe 7 1 9  < ../inputs/input/add.58 > ../outputs/output.${1}/t1407
echo ">>>>>>>>running test 1408"
../source/schedule.exe 7 1 4  < ../inputs/input/add.100 > ../outputs/output.${1}/t1408
echo ">>>>>>>>running test 1409"
../source/schedule.exe 3 5 9  < ../inputs/input/add.95 > ../outputs/output.${1}/t1409
echo ">>>>>>>>running test 1410"
../source/schedule.exe 9 7 2  < ../inputs/input/add.0 > ../outputs/output.${1}/t1410
echo ">>>>>>>>running test 1411"
../source/schedule.exe 0 2 6  < ../inputs/input/add.52 > ../outputs/output.${1}/t1411
echo ">>>>>>>>running test 1412"
../source/schedule.exe 3 2 0  < ../inputs/input/add.48 > ../outputs/output.${1}/t1412
echo ">>>>>>>>running test 1413"
../source/schedule.exe 10 5 0  < ../inputs/input/add.20 > ../outputs/output.${1}/t1413
echo ">>>>>>>>running test 1414"
../source/schedule.exe 7 4 10  < ../inputs/input/add.37 > ../outputs/output.${1}/t1414
echo ">>>>>>>>running test 1415"
../source/schedule.exe 9 2 0  < ../inputs/input/add.13 > ../outputs/output.${1}/t1415
echo ">>>>>>>>running test 1416"
../source/schedule.exe 9 1 2  < ../inputs/input/add.14 > ../outputs/output.${1}/t1416
echo ">>>>>>>>running test 1417"
../source/schedule.exe 1 3 10  < ../inputs/input/add.100 > ../outputs/output.${1}/t1417
echo ">>>>>>>>running test 1418"
../source/schedule.exe 1 2 1  < ../inputs/input/add.0 > ../outputs/output.${1}/t1418
echo ">>>>>>>>running test 1419"
../source/schedule.exe 5 5 4  < ../inputs/input/add.11 > ../outputs/output.${1}/t1419
echo ">>>>>>>>running test 1420"
../source/schedule.exe 1 6 10  < ../inputs/input/add.38 > ../outputs/output.${1}/t1420
echo ">>>>>>>>running test 1421"
../source/schedule.exe 4 0 8  < ../inputs/input/add.92 > ../outputs/output.${1}/t1421
echo ">>>>>>>>running test 1422"
../source/schedule.exe 1 10 8  < ../inputs/input/add.50 > ../outputs/output.${1}/t1422
echo ">>>>>>>>running test 1423"
../source/schedule.exe 1 4 5  < ../inputs/input/add.51 > ../outputs/output.${1}/t1423
echo ">>>>>>>>running test 1424"
../source/schedule.exe 9 9 3  < ../inputs/input/add.43 > ../outputs/output.${1}/t1424
echo ">>>>>>>>running test 1425"
../source/schedule.exe 2 6 6  < ../inputs/input/add.78 > ../outputs/output.${1}/t1425
echo ">>>>>>>>running test 1426"
../source/schedule.exe 1 7 4  < ../inputs/input/add.42 > ../outputs/output.${1}/t1426
echo ">>>>>>>>running test 1427"
../source/schedule.exe 3 1 0  < ../inputs/input/add.33 > ../outputs/output.${1}/t1427
echo ">>>>>>>>running test 1428"
../source/schedule.exe 3 2 2  < ../inputs/input/add.56 > ../outputs/output.${1}/t1428
echo ">>>>>>>>running test 1429"
../source/schedule.exe 2 7 9  < ../inputs/input/add.57 > ../outputs/output.${1}/t1429
echo ">>>>>>>>running test 1430"
../source/schedule.exe 0 0 7  < ../inputs/input/add.34 > ../outputs/output.${1}/t1430
echo ">>>>>>>>running test 1431"
../source/schedule.exe 3 6 5  < ../inputs/input/add.86 > ../outputs/output.${1}/t1431
echo ">>>>>>>>running test 1432"
../source/schedule.exe 4 6 2  < ../inputs/input/add.97 > ../outputs/output.${1}/t1432
echo ">>>>>>>>running test 1433"
../source/schedule.exe 5 10 5  < ../inputs/input/add.52 > ../outputs/output.${1}/t1433
echo ">>>>>>>>running test 1434"
../source/schedule.exe 9 3 10  < ../inputs/input/add.73 > ../outputs/output.${1}/t1434
echo ">>>>>>>>running test 1435"
../source/schedule.exe 6 10 6  < ../inputs/input/add.69 > ../outputs/output.${1}/t1435
echo ">>>>>>>>running test 1436"
../source/schedule.exe 2 0 9  < ../inputs/input/add.53 > ../outputs/output.${1}/t1436
echo ">>>>>>>>running test 1437"
../source/schedule.exe 1 0 4  < ../inputs/input/add.77 > ../outputs/output.${1}/t1437
echo ">>>>>>>>running test 1438"
../source/schedule.exe 6 5 9  < ../inputs/input/add.32 > ../outputs/output.${1}/t1438
echo ">>>>>>>>running test 1439"
../source/schedule.exe 4 3 7  < ../inputs/input/add.82 > ../outputs/output.${1}/t1439
echo ">>>>>>>>running test 1440"
../source/schedule.exe 6 6 0  < ../inputs/input/add.19 > ../outputs/output.${1}/t1440
echo ">>>>>>>>running test 1441"
../source/schedule.exe 3 3 4  < ../inputs/input/add.85 > ../outputs/output.${1}/t1441
echo ">>>>>>>>running test 1442"
../source/schedule.exe 1 10 6  < ../inputs/input/add.7 > ../outputs/output.${1}/t1442
echo ">>>>>>>>running test 1443"
../source/schedule.exe 2 0 9  < ../inputs/input/add.15 > ../outputs/output.${1}/t1443
echo ">>>>>>>>running test 1444"
../source/schedule.exe 4 7 0  < ../inputs/input/add.90 > ../outputs/output.${1}/t1444
echo ">>>>>>>>running test 1445"
../source/schedule.exe 6 0 3  < ../inputs/input/add.91 > ../outputs/output.${1}/t1445
echo ">>>>>>>>running test 1446"
../source/schedule.exe 3 3 0  < ../inputs/input/add.23 > ../outputs/output.${1}/t1446
echo ">>>>>>>>running test 1447"
../source/schedule.exe 7 9 2  < ../inputs/input/add.50 > ../outputs/output.${1}/t1447
echo ">>>>>>>>running test 1448"
../source/schedule.exe 4 10 7  < ../inputs/input/add.83 > ../outputs/output.${1}/t1448
echo ">>>>>>>>running test 1449"
../source/schedule.exe 2 2 10  < ../inputs/input/add.77 > ../outputs/output.${1}/t1449
echo ">>>>>>>>running test 1450"
../source/schedule.exe 1 5 3  < ../inputs/input/add.11 > ../outputs/output.${1}/t1450
echo ">>>>>>>>running test 1451"
../source/schedule.exe 2 4 3  < ../inputs/input/add.37 > ../outputs/output.${1}/t1451
echo ">>>>>>>>running test 1452"
../source/schedule.exe 3 2 3  < ../inputs/input/add.65 > ../outputs/output.${1}/t1452
echo ">>>>>>>>running test 1453"
../source/schedule.exe 7 4 2  < ../inputs/input/add.37 > ../outputs/output.${1}/t1453
echo ">>>>>>>>running test 1454"
../source/schedule.exe 5 0 9  < ../inputs/input/add.64 > ../outputs/output.${1}/t1454
echo ">>>>>>>>running test 1455"
../source/schedule.exe 3 0 7  < ../inputs/input/add.73 > ../outputs/output.${1}/t1455
echo ">>>>>>>>running test 1456"
../source/schedule.exe 4 8 9  < ../inputs/input/add.70 > ../outputs/output.${1}/t1456
echo ">>>>>>>>running test 1457"
../source/schedule.exe 10 10 8  < ../inputs/input/add.26 > ../outputs/output.${1}/t1457
echo ">>>>>>>>running test 1458"
../source/schedule.exe 2 8 6  < ../inputs/input/add.21 > ../outputs/output.${1}/t1458
echo ">>>>>>>>running test 1459"
../source/schedule.exe 10 2 1  < ../inputs/input/add.6 > ../outputs/output.${1}/t1459
echo ">>>>>>>>running test 1460"
../source/schedule.exe 0 4 10  < ../inputs/input/add.82 > ../outputs/output.${1}/t1460
echo ">>>>>>>>running test 1461"
../source/schedule.exe 7 0 3  < ../inputs/input/add.48 > ../outputs/output.${1}/t1461
echo ">>>>>>>>running test 1462"
../source/schedule.exe 9 1 6  < ../inputs/input/add.83 > ../outputs/output.${1}/t1462
echo ">>>>>>>>running test 1463"
../source/schedule.exe 3 9 10  < ../inputs/input/add.9 > ../outputs/output.${1}/t1463
echo ">>>>>>>>running test 1464"
../source/schedule.exe 10 3 7  < ../inputs/input/add.20 > ../outputs/output.${1}/t1464
echo ">>>>>>>>running test 1465"
../source/schedule.exe 1 1 0  < ../inputs/input/add.91 > ../outputs/output.${1}/t1465
echo ">>>>>>>>running test 1466"
../source/schedule.exe 6 9 8  < ../inputs/input/add.78 > ../outputs/output.${1}/t1466
echo ">>>>>>>>running test 1467"
../source/schedule.exe 0 7 6  < ../inputs/input/add.45 > ../outputs/output.${1}/t1467
echo ">>>>>>>>running test 1468"
../source/schedule.exe 8 0 2  < ../inputs/input/add.12 > ../outputs/output.${1}/t1468
echo ">>>>>>>>running test 1469"
../source/schedule.exe 7 1 10  < ../inputs/input/add.25 > ../outputs/output.${1}/t1469
echo ">>>>>>>>running test 1470"
../source/schedule.exe 8 2 7  < ../inputs/input/add.68 > ../outputs/output.${1}/t1470
echo ">>>>>>>>running test 1471"
../source/schedule.exe 0 6 1  < ../inputs/input/add.39 > ../outputs/output.${1}/t1471
echo ">>>>>>>>running test 1472"
../source/schedule.exe 4 5 5  < ../inputs/input/add.62 > ../outputs/output.${1}/t1472
echo ">>>>>>>>running test 1473"
../source/schedule.exe 7 2 9  < ../inputs/input/add.72 > ../outputs/output.${1}/t1473
echo ">>>>>>>>running test 1474"
../source/schedule.exe 10 10 6  < ../inputs/input/add.35 > ../outputs/output.${1}/t1474
echo ">>>>>>>>running test 1475"
../source/schedule.exe 3 3 2  < ../inputs/input/add.74 > ../outputs/output.${1}/t1475
echo ">>>>>>>>running test 1476"
../source/schedule.exe 4 7 2  < ../inputs/input/add.47 > ../outputs/output.${1}/t1476
echo ">>>>>>>>running test 1477"
../source/schedule.exe 8 8 0  < ../inputs/input/add.54 > ../outputs/output.${1}/t1477
echo ">>>>>>>>running test 1478"
../source/schedule.exe 3 8 5  < ../inputs/input/add.48 > ../outputs/output.${1}/t1478
echo ">>>>>>>>running test 1479"
../source/schedule.exe 8 6 3  < ../inputs/input/add.11 > ../outputs/output.${1}/t1479
echo ">>>>>>>>running test 1480"
../source/schedule.exe 2 10 7  < ../inputs/input/add.91 > ../outputs/output.${1}/t1480
echo ">>>>>>>>running test 1481"
../source/schedule.exe 4 4 3  < ../inputs/input/add.97 > ../outputs/output.${1}/t1481
echo ">>>>>>>>running test 1482"
../source/schedule.exe 8 4 0  < ../inputs/input/add.37 > ../outputs/output.${1}/t1482
echo ">>>>>>>>running test 1483"
../source/schedule.exe 7 1 1  < ../inputs/input/add.88 > ../outputs/output.${1}/t1483
echo ">>>>>>>>running test 1484"
../source/schedule.exe 6 9 10  < ../inputs/input/add.50 > ../outputs/output.${1}/t1484
echo ">>>>>>>>running test 1485"
../source/schedule.exe 0 1 8  < ../inputs/input/add.75 > ../outputs/output.${1}/t1485
echo ">>>>>>>>running test 1486"
../source/schedule.exe 10 4 10  < ../inputs/input/add.3 > ../outputs/output.${1}/t1486
echo ">>>>>>>>running test 1487"
../source/schedule.exe 5 10 7  < ../inputs/input/add.22 > ../outputs/output.${1}/t1487
echo ">>>>>>>>running test 1488"
../source/schedule.exe 2 3 9  < ../inputs/input/add.95 > ../outputs/output.${1}/t1488
echo ">>>>>>>>running test 1489"
../source/schedule.exe 4 2 9  < ../inputs/input/add.60 > ../outputs/output.${1}/t1489
echo ">>>>>>>>running test 1490"
../source/schedule.exe 0 9 2  < ../inputs/input/add.31 > ../outputs/output.${1}/t1490
echo ">>>>>>>>running test 1491"
../source/schedule.exe 1 2 6  < ../inputs/input/add.45 > ../outputs/output.${1}/t1491
echo ">>>>>>>>running test 1492"
../source/schedule.exe 5 2 0  < ../inputs/input/add.34 > ../outputs/output.${1}/t1492
echo ">>>>>>>>running test 1493"
../source/schedule.exe 9 8 2  < ../inputs/input/add.77 > ../outputs/output.${1}/t1493
echo ">>>>>>>>running test 1494"
../source/schedule.exe 5 4 3  < ../inputs/input/add.29 > ../outputs/output.${1}/t1494
echo ">>>>>>>>running test 1495"
../source/schedule.exe 1 10 8  < ../inputs/input/add.22 > ../outputs/output.${1}/t1495
echo ">>>>>>>>running test 1496"
../source/schedule.exe 2 9 3  < ../inputs/input/add.38 > ../outputs/output.${1}/t1496
echo ">>>>>>>>running test 1497"
../source/schedule.exe 10 10 5  < ../inputs/input/add.89 > ../outputs/output.${1}/t1497
echo ">>>>>>>>running test 1498"
../source/schedule.exe 0 6 3  < ../inputs/input/add.43 > ../outputs/output.${1}/t1498
echo ">>>>>>>>running test 1499"
../source/schedule.exe 2 7 0  < ../inputs/input/add.94 > ../outputs/output.${1}/t1499
echo ">>>>>>>>running test 1500"
../source/schedule.exe 0 0 5  < ../inputs/input/add.79 > ../outputs/output.${1}/t1500
echo ">>>>>>>>running test 1501"
../source/schedule.exe 10 2 4  < ../inputs/input/add.17 > ../outputs/output.${1}/t1501
echo ">>>>>>>>running test 1502"
../source/schedule.exe 10 4 0  < ../inputs/input/add.36 > ../outputs/output.${1}/t1502
echo ">>>>>>>>running test 1503"
../source/schedule.exe 4 1 2  < ../inputs/input/add.20 > ../outputs/output.${1}/t1503
echo ">>>>>>>>running test 1504"
../source/schedule.exe 9 6 5  < ../inputs/input/add.86 > ../outputs/output.${1}/t1504
echo ">>>>>>>>running test 1505"
../source/schedule.exe 7 7 3  < ../inputs/input/add.11 > ../outputs/output.${1}/t1505
echo ">>>>>>>>running test 1506"
../source/schedule.exe 0 1 8  < ../inputs/input/add.67 > ../outputs/output.${1}/t1506
echo ">>>>>>>>running test 1507"
../source/schedule.exe 7 1 9  < ../inputs/input/adt.58 > ../outputs/output.${1}/t1507
echo ">>>>>>>>running test 1508"
../source/schedule.exe 7 1 4  < ../inputs/input/adt.100 > ../outputs/output.${1}/t1508
echo ">>>>>>>>running test 1509"
../source/schedule.exe 3 5 9  < ../inputs/input/adt.95 > ../outputs/output.${1}/t1509
echo ">>>>>>>>running test 1510"
../source/schedule.exe 9 7 2  < ../inputs/input/adt.0 > ../outputs/output.${1}/t1510
echo ">>>>>>>>running test 1511"
../source/schedule.exe 0 2 6  < ../inputs/input/adt.52 > ../outputs/output.${1}/t1511
echo ">>>>>>>>running test 1512"
../source/schedule.exe 3 2 0  < ../inputs/input/adt.48 > ../outputs/output.${1}/t1512
echo ">>>>>>>>running test 1513"
../source/schedule.exe 10 5 0  < ../inputs/input/adt.20 > ../outputs/output.${1}/t1513
echo ">>>>>>>>running test 1514"
../source/schedule.exe 10 5 10  < ../inputs/input/adt.3 > ../outputs/output.${1}/t1514
echo ">>>>>>>>running test 1515"
../source/schedule.exe 5 7 8  < ../inputs/input/adt.89 > ../outputs/output.${1}/t1515
echo ">>>>>>>>running test 1516"
../source/schedule.exe 7 5 3  < ../inputs/input/adt.75 > ../outputs/output.${1}/t1516
echo ">>>>>>>>running test 1517"
../source/schedule.exe 1 10 0  < ../inputs/input/adt.93 > ../outputs/output.${1}/t1517
echo ">>>>>>>>running test 1518"
../source/schedule.exe 2 9 9  < ../inputs/input/adt.24 > ../outputs/output.${1}/t1518
echo ">>>>>>>>running test 1519"
../source/schedule.exe 1 8 5  < ../inputs/input/adt.24 > ../outputs/output.${1}/t1519
echo ">>>>>>>>running test 1520"
../source/schedule.exe 6 0 2  < ../inputs/input/adt.54 > ../outputs/output.${1}/t1520
echo ">>>>>>>>running test 1521"
../source/schedule.exe 10 3 0  < ../inputs/input/adt.48 > ../outputs/output.${1}/t1521
echo ">>>>>>>>running test 1522"
../source/schedule.exe 2 5 6  < ../inputs/input/adt.55 > ../outputs/output.${1}/t1522
echo ">>>>>>>>running test 1523"
../source/schedule.exe 3 2 8  < ../inputs/input/adt.44 > ../outputs/output.${1}/t1523
echo ">>>>>>>>running test 1524"
../source/schedule.exe 0 10 1  < ../inputs/input/adt.14 > ../outputs/output.${1}/t1524
echo ">>>>>>>>running test 1525"
../source/schedule.exe 5 5 4  < ../inputs/input/adt.96 > ../outputs/output.${1}/t1525
echo ">>>>>>>>running test 1526"
../source/schedule.exe 1 4 3  < ../inputs/input/adt.57 > ../outputs/output.${1}/t1526
echo ">>>>>>>>running test 1527"
../source/schedule.exe 1 0 3  < ../inputs/input/adt.74 > ../outputs/output.${1}/t1527
echo ">>>>>>>>running test 1528"
../source/schedule.exe 10 6 1  < ../inputs/input/adt.37 > ../outputs/output.${1}/t1528
echo ">>>>>>>>running test 1529"
../source/schedule.exe 6 3 10  < ../inputs/input/adt.9 > ../outputs/output.${1}/t1529
echo ">>>>>>>>running test 1530"
../source/schedule.exe 7 9 10  < ../inputs/input/adt.36 > ../outputs/output.${1}/t1530
echo ">>>>>>>>running test 1531"
../source/schedule.exe 6 9 7  < ../inputs/input/adt.55 > ../outputs/output.${1}/t1531
echo ">>>>>>>>running test 1532"
../source/schedule.exe 0 0 4  < ../inputs/input/adt.40 > ../outputs/output.${1}/t1532
echo ">>>>>>>>running test 1533"
../source/schedule.exe 9 7 0  < ../inputs/input/adt.0 > ../outputs/output.${1}/t1533
echo ">>>>>>>>running test 1534"
../source/schedule.exe 3 1 9  < ../inputs/input/adt.11 > ../outputs/output.${1}/t1534
echo ">>>>>>>>running test 1535"
../source/schedule.exe 8 1 0  < ../inputs/input/adt.90 > ../outputs/output.${1}/t1535
echo ">>>>>>>>running test 1536"
../source/schedule.exe 3 3 1  < ../inputs/input/adt.62 > ../outputs/output.${1}/t1536
echo ">>>>>>>>running test 1537"
../source/schedule.exe 1 1 10  < ../inputs/input/adt.4 > ../outputs/output.${1}/t1537
echo ">>>>>>>>running test 1538"
../source/schedule.exe 10 8 9  < ../inputs/input/adt.54 > ../outputs/output.${1}/t1538
echo ">>>>>>>>running test 1539"
../source/schedule.exe 4 2 10  < ../inputs/input/adt.21 > ../outputs/output.${1}/t1539
echo ">>>>>>>>running test 1540"
../source/schedule.exe 3 7 3  < ../inputs/input/adt.32 > ../outputs/output.${1}/t1540
echo ">>>>>>>>running test 1541"
../source/schedule.exe 2 8 0  < ../inputs/input/adt.57 > ../outputs/output.${1}/t1541
echo ">>>>>>>>running test 1542"
../source/schedule.exe 9 10 2  < ../inputs/input/adt.3 > ../outputs/output.${1}/t1542
echo ">>>>>>>>running test 1543"
../source/schedule.exe 4 1 7  < ../inputs/input/adt.74 > ../outputs/output.${1}/t1543
echo ">>>>>>>>running test 1544"
../source/schedule.exe 1 10 9  < ../inputs/input/adt.0 > ../outputs/output.${1}/t1544
echo ">>>>>>>>running test 1545"
../source/schedule.exe 3 1 1  < ../inputs/input/adt.54 > ../outputs/output.${1}/t1545
echo ">>>>>>>>running test 1546"
../source/schedule.exe 6 6 1  < ../inputs/input/adt.36 > ../outputs/output.${1}/t1546
echo ">>>>>>>>running test 1547"
../source/schedule.exe 6 5 9  < ../inputs/input/adt.34 > ../outputs/output.${1}/t1547
echo ">>>>>>>>running test 1548"
../source/schedule.exe 9 7 3  < ../inputs/input/adt.64 > ../outputs/output.${1}/t1548
echo ">>>>>>>>running test 1549"
../source/schedule.exe 5 2 1  < ../inputs/input/adt.34 > ../outputs/output.${1}/t1549
echo ">>>>>>>>running test 1550"
../source/schedule.exe 6 9 8  < ../inputs/input/adt.8 > ../outputs/output.${1}/t1550
echo ">>>>>>>>running test 1551"
../source/schedule.exe 3 5 4  < ../inputs/input/adt.16 > ../outputs/output.${1}/t1551
echo ">>>>>>>>running test 1552"
../source/schedule.exe 10 0 6  < ../inputs/input/adt.30 > ../outputs/output.${1}/t1552
echo ">>>>>>>>running test 1553"
../source/schedule.exe 7 5 1  < ../inputs/input/adt.26 > ../outputs/output.${1}/t1553
echo ">>>>>>>>running test 1554"
../source/schedule.exe 0 7 6  < ../inputs/input/adt.3 > ../outputs/output.${1}/t1554
echo ">>>>>>>>running test 1555"
../source/schedule.exe 7 2 1  < ../inputs/input/adt.17 > ../outputs/output.${1}/t1555
echo ">>>>>>>>running test 1556"
../source/schedule.exe 6 0 6  < ../inputs/input/adt.21 > ../outputs/output.${1}/t1556
echo ">>>>>>>>running test 1557"
../source/schedule.exe 7 1 9  < ../inputs/input/inp.hf.1 > ../outputs/output.${1}/t1557
echo ">>>>>>>>running test 1558"
../source/schedule.exe 2 3 5  < ../inputs/input/inp.hf.2 > ../outputs/output.${1}/t1558
echo ">>>>>>>>running test 1559"
../source/schedule.exe 4 8 8  < ../inputs/input/inp.hf.3 > ../outputs/output.${1}/t1559
echo ">>>>>>>>running test 1560"
../source/schedule.exe 10 0 2  < ../inputs/input/inp.hf.4 > ../outputs/output.${1}/t1560
echo ">>>>>>>>running test 1561"
../source/schedule.exe 8 3 2  < ../inputs/input/inp.hf.5 > ../outputs/output.${1}/t1561
echo ">>>>>>>>running test 1562"
../source/schedule.exe 7 10 5  < ../inputs/input/inp.hf.6 > ../outputs/output.${1}/t1562
echo ">>>>>>>>running test 1563"
../source/schedule.exe 4 0 6  < ../inputs/input/inp.hf.7 > ../outputs/output.${1}/t1563
echo ">>>>>>>>running test 1564"
../source/schedule.exe 3 7 4  < ../inputs/input/inp.hf.8 > ../outputs/output.${1}/t1564
echo ">>>>>>>>running test 1565"
../source/schedule.exe 9 7 5  < ../inputs/input/inp.hf.9 > ../outputs/output.${1}/t1565
echo ">>>>>>>>running test 1566"
../source/schedule.exe 9 10 6  < ../inputs/input/inp.hf.10 > ../outputs/output.${1}/t1566
echo ">>>>>>>>running test 1567"
../source/schedule.exe 7 9 8  < ../inputs/input/inp.hf.11 > ../outputs/output.${1}/t1567
echo ">>>>>>>>running test 1568"
../source/schedule.exe 8 9 0  < ../inputs/input/inp.hf.12 > ../outputs/output.${1}/t1568
echo ">>>>>>>>running test 1569"
../source/schedule.exe 8 5 0  < ../inputs/input/inp.hf.13 > ../outputs/output.${1}/t1569
echo ">>>>>>>>running test 1570"
../source/schedule.exe 9 8 5  < ../inputs/input/inp.hf.14 > ../outputs/output.${1}/t1570
echo ">>>>>>>>running test 1571"
../source/schedule.exe 7 0 6  < ../inputs/input/inp.hf.15 > ../outputs/output.${1}/t1571
echo ">>>>>>>>running test 1572"
../source/schedule.exe 8 3 9  < ../inputs/input/inp.hf.16 > ../outputs/output.${1}/t1572
echo ">>>>>>>>running test 1573"
../source/schedule.exe 7 4 2  < ../inputs/input/inp.hf.17 > ../outputs/output.${1}/t1573
echo ">>>>>>>>running test 1574"
../source/schedule.exe 5 8 7  < ../inputs/input/inp.hf.18 > ../outputs/output.${1}/t1574
echo ">>>>>>>>running test 1575"
../source/schedule.exe 0 4 1  < ../inputs/input/inp.hf.19 > ../outputs/output.${1}/t1575
echo ">>>>>>>>running test 1576"
../source/schedule.exe 0 10 6  < ../inputs/input/inp.hf.20 > ../outputs/output.${1}/t1576
echo ">>>>>>>>running test 1577"
../source/schedule.exe 9 0 9  < ../inputs/input/inp.hf.21 > ../outputs/output.${1}/t1577
echo ">>>>>>>>running test 1578"
../source/schedule.exe 9 9 2  < ../inputs/input/inp.hf.22 > ../outputs/output.${1}/t1578
echo ">>>>>>>>running test 1579"
../source/schedule.exe 6 1 0  < ../inputs/input/inp.hf.23 > ../outputs/output.${1}/t1579
echo ">>>>>>>>running test 1580"
../source/schedule.exe 5 10 8  < ../inputs/input/inp.hf.24 > ../outputs/output.${1}/t1580
echo ">>>>>>>>running test 1581"
../source/schedule.exe 6 9 0  < ../inputs/input/inp.hf.25 > ../outputs/output.${1}/t1581
echo ">>>>>>>>running test 1582"
../source/schedule.exe 3 7 3  < ../inputs/input/inp.hf.26 > ../outputs/output.${1}/t1582
echo ">>>>>>>>running test 1583"
../source/schedule.exe 1 5 5  < ../inputs/input/inp.hf.27 > ../outputs/output.${1}/t1583
echo ">>>>>>>>running test 1584"
../source/schedule.exe 1 2 7  < ../inputs/input/inp.hf.28 > ../outputs/output.${1}/t1584
echo ">>>>>>>>running test 1585"
../source/schedule.exe 2 7 6  < ../inputs/input/inp.hf.29 > ../outputs/output.${1}/t1585
echo ">>>>>>>>running test 1586"
../source/schedule.exe 4 6 3  < ../inputs/input/inp.hf.30 > ../outputs/output.${1}/t1586
echo ">>>>>>>>running test 1587"
../source/schedule.exe 7 1 9  < ../inputs/input/adt.158 > ../outputs/output.${1}/t1587
echo ">>>>>>>>running test 1588"
../source/schedule.exe 7 1 4  < ../inputs/input/adt.200 > ../outputs/output.${1}/t1588
echo ">>>>>>>>running test 1589"
../source/schedule.exe 3 5 9  < ../inputs/input/adt.195 > ../outputs/output.${1}/t1589
echo ">>>>>>>>running test 1590"
../source/schedule.exe 9 7 2  < ../inputs/input/adt.100 > ../outputs/output.${1}/t1590
echo ">>>>>>>>running test 1591"
../source/schedule.exe 0 2 6  < ../inputs/input/adt.152 > ../outputs/output.${1}/t1591
echo ">>>>>>>>running test 1592"
../source/schedule.exe 3 2 0  < ../inputs/input/adt.148 > ../outputs/output.${1}/t1592
echo ">>>>>>>>running test 1593"
../source/schedule.exe 10 5 0  < ../inputs/input/adt.120 > ../outputs/output.${1}/t1593
echo ">>>>>>>>running test 1594"
../source/schedule.exe 10 5 10  < ../inputs/input/adt.103 > ../outputs/output.${1}/t1594
echo ">>>>>>>>running test 1595"
../source/schedule.exe 5 7 8  < ../inputs/input/adt.189 > ../outputs/output.${1}/t1595
echo ">>>>>>>>running test 1596"
../source/schedule.exe 7 5 3  < ../inputs/input/adt.175 > ../outputs/output.${1}/t1596
echo ">>>>>>>>running test 1597"
../source/schedule.exe 1 10 0  < ../inputs/input/adt.193 > ../outputs/output.${1}/t1597
echo ">>>>>>>>running test 1598"
../source/schedule.exe 2 9 9  < ../inputs/input/adt.124 > ../outputs/output.${1}/t1598
echo ">>>>>>>>running test 1599"
../source/schedule.exe 1 8 5  < ../inputs/input/adt.124 > ../outputs/output.${1}/t1599
echo ">>>>>>>>running test 1600"
../source/schedule.exe 6 0 2  < ../inputs/input/adt.154 > ../outputs/output.${1}/t1600
echo ">>>>>>>>running test 1601"
../source/schedule.exe 10 3 0  < ../inputs/input/adt.148 > ../outputs/output.${1}/t1601
echo ">>>>>>>>running test 1602"
../source/schedule.exe 2 5 6  < ../inputs/input/adt.155 > ../outputs/output.${1}/t1602
echo ">>>>>>>>running test 1603"
../source/schedule.exe 3 2 8  < ../inputs/input/adt.144 > ../outputs/output.${1}/t1603
echo ">>>>>>>>running test 1604"
../source/schedule.exe 0 10 1  < ../inputs/input/adt.114 > ../outputs/output.${1}/t1604
echo ">>>>>>>>running test 1605"
../source/schedule.exe 5 5 4  < ../inputs/input/adt.196 > ../outputs/output.${1}/t1605
echo ">>>>>>>>running test 1606"
../source/schedule.exe 1 4 3  < ../inputs/input/adt.157 > ../outputs/output.${1}/t1606
echo ">>>>>>>>running test 1607"
../source/schedule.exe 1 0 3  < ../inputs/input/adt.174 > ../outputs/output.${1}/t1607
echo ">>>>>>>>running test 1608"
../source/schedule.exe 10 6 1  < ../inputs/input/adt.137 > ../outputs/output.${1}/t1608
echo ">>>>>>>>running test 1609"
../source/schedule.exe 6 3 10  < ../inputs/input/adt.109 > ../outputs/output.${1}/t1609
echo ">>>>>>>>running test 1610"
../source/schedule.exe 7 9 10  < ../inputs/input/adt.136 > ../outputs/output.${1}/t1610
echo ">>>>>>>>running test 1611"
../source/schedule.exe 6 9 7  < ../inputs/input/adt.155 > ../outputs/output.${1}/t1611
echo ">>>>>>>>running test 1612"
../source/schedule.exe 0 0 4  < ../inputs/input/adt.140 > ../outputs/output.${1}/t1612
echo ">>>>>>>>running test 1613"
../source/schedule.exe 9 7 0  < ../inputs/input/adt.100 > ../outputs/output.${1}/t1613
echo ">>>>>>>>running test 1614"
../source/schedule.exe 3 1 9  < ../inputs/input/adt.111 > ../outputs/output.${1}/t1614
echo ">>>>>>>>running test 1615"
../source/schedule.exe 8 1 0  < ../inputs/input/adt.190 > ../outputs/output.${1}/t1615
echo ">>>>>>>>running test 1616"
../source/schedule.exe 3 3 1  < ../inputs/input/adt.162 > ../outputs/output.${1}/t1616
echo ">>>>>>>>running test 1617"
../source/schedule.exe 1 1 10  < ../inputs/input/adt.104 > ../outputs/output.${1}/t1617
echo ">>>>>>>>running test 1618"
../source/schedule.exe 10 8 9  < ../inputs/input/adt.154 > ../outputs/output.${1}/t1618
echo ">>>>>>>>running test 1619"
../source/schedule.exe 4 2 10  < ../inputs/input/adt.121 > ../outputs/output.${1}/t1619
echo ">>>>>>>>running test 1620"
../source/schedule.exe 3 7 3  < ../inputs/input/adt.132 > ../outputs/output.${1}/t1620
echo ">>>>>>>>running test 1621"
../source/schedule.exe 2 8 0  < ../inputs/input/adt.157 > ../outputs/output.${1}/t1621
echo ">>>>>>>>running test 1622"
../source/schedule.exe 9 10 2  < ../inputs/input/adt.103 > ../outputs/output.${1}/t1622
echo ">>>>>>>>running test 1623"
../source/schedule.exe 4 1 7  < ../inputs/input/adt.174 > ../outputs/output.${1}/t1623
echo ">>>>>>>>running test 1624"
../source/schedule.exe 1 10 9  < ../inputs/input/adt.100 > ../outputs/output.${1}/t1624
echo ">>>>>>>>running test 1625"
../source/schedule.exe 3 1 1  < ../inputs/input/adt.154 > ../outputs/output.${1}/t1625
echo ">>>>>>>>running test 1626"
../source/schedule.exe 6 6 1  < ../inputs/input/adt.136 > ../outputs/output.${1}/t1626
echo ">>>>>>>>running test 1627"
../source/schedule.exe 6 5 9  < ../inputs/input/adt.134 > ../outputs/output.${1}/t1627
echo ">>>>>>>>running test 1628"
../source/schedule.exe 9 7 3  < ../inputs/input/adt.164 > ../outputs/output.${1}/t1628
echo ">>>>>>>>running test 1629"
../source/schedule.exe 5 2 1  < ../inputs/input/adt.134 > ../outputs/output.${1}/t1629
echo ">>>>>>>>running test 1630"
../source/schedule.exe 6 9 8  < ../inputs/input/adt.108 > ../outputs/output.${1}/t1630
echo ">>>>>>>>running test 1631"
../source/schedule.exe 3 5 4  < ../inputs/input/adt.116 > ../outputs/output.${1}/t1631
echo ">>>>>>>>running test 1632"
../source/schedule.exe 10 0 6  < ../inputs/input/adt.130 > ../outputs/output.${1}/t1632
echo ">>>>>>>>running test 1633"
../source/schedule.exe 7 5 1  < ../inputs/input/adt.126 > ../outputs/output.${1}/t1633
echo ">>>>>>>>running test 1634"
../source/schedule.exe 0 7 6  < ../inputs/input/adt.103 > ../outputs/output.${1}/t1634
echo ">>>>>>>>running test 1635"
../source/schedule.exe 7 2 1  < ../inputs/input/adt.117 > ../outputs/output.${1}/t1635
echo ">>>>>>>>running test 1636"
../source/schedule.exe 6 0 6  < ../inputs/input/adt.121 > ../outputs/output.${1}/t1636
echo ">>>>>>>>running test 1637"
../source/schedule.exe 0 6 6  < ../inputs/input/adt.127 > ../outputs/output.${1}/t1637
echo ">>>>>>>>running test 1638"
../source/schedule.exe 2 6 0  < ../inputs/input/adt.158 > ../outputs/output.${1}/t1638
echo ">>>>>>>>running test 1639"
../source/schedule.exe 4 10 7  < ../inputs/input/adt.174 > ../outputs/output.${1}/t1639
echo ">>>>>>>>running test 1640"
../source/schedule.exe 2 6 0  < ../inputs/input/adt.103 > ../outputs/output.${1}/t1640
echo ">>>>>>>>running test 1641"
../source/schedule.exe 1 1 10  < ../inputs/input/adt.103 > ../outputs/output.${1}/t1641
echo ">>>>>>>>running test 1642"
../source/schedule.exe 10 5 7  < ../inputs/input/adt.150 > ../outputs/output.${1}/t1642
echo ">>>>>>>>running test 1643"
../source/schedule.exe 4 5 0  < ../inputs/input/adt.189 > ../outputs/output.${1}/t1643
echo ">>>>>>>>running test 1644"
../source/schedule.exe 4 5 5  < ../inputs/input/adt.189 > ../outputs/output.${1}/t1644
echo ">>>>>>>>running test 1645"
../source/schedule.exe 8 3 1  < ../inputs/input/adt.170 > ../outputs/output.${1}/t1645
echo ">>>>>>>>running test 1646"
../source/schedule.exe 8 9 4  < ../inputs/input/adt.100 > ../outputs/output.${1}/t1646
echo ">>>>>>>>running test 1647"
../source/schedule.exe 8 6 10  < ../inputs/input/adt.173 > ../outputs/output.${1}/t1647
echo ">>>>>>>>running test 1648"
../source/schedule.exe 0 2 5  < ../inputs/input/adt.146 > ../outputs/output.${1}/t1648
echo ">>>>>>>>running test 1649"
../source/schedule.exe 6 2 7  < ../inputs/input/adt.136 > ../outputs/output.${1}/t1649
echo ">>>>>>>>running test 1650"
../source/schedule.exe 1 8 1  < ../inputs/input/adt.107 > ../outputs/output.${1}/t1650
echo ">>>>>>>>running test 1651"
../source/schedule.exe 7 4 0  < ../inputs/input/adt.113 > ../outputs/output.${1}/t1651
echo ">>>>>>>>running test 1652"
../source/schedule.exe 5 6 0  < ../inputs/input/adt.160 > ../outputs/output.${1}/t1652
echo ">>>>>>>>running test 1653"
../source/schedule.exe 7 6 6  < ../inputs/input/adt.192 > ../outputs/output.${1}/t1653
echo ">>>>>>>>running test 1654"
../source/schedule.exe 4 5 0  < ../inputs/input/adt.115 > ../outputs/output.${1}/t1654
echo ">>>>>>>>running test 1655"
../source/schedule.exe 5 3 4  < ../inputs/input/adt.156 > ../outputs/output.${1}/t1655
echo ">>>>>>>>running test 1656"
../source/schedule.exe 2 9 8  < ../inputs/input/adt.199 > ../outputs/output.${1}/t1656
echo ">>>>>>>>running test 1657"
../source/schedule.exe 4 0 3  < ../inputs/input/adt.108 > ../outputs/output.${1}/t1657
echo ">>>>>>>>running test 1658"
../source/schedule.exe 0 10 6  < ../inputs/input/adt.101 > ../outputs/output.${1}/t1658
echo ">>>>>>>>running test 1659"
../source/schedule.exe 9 3 9  < ../inputs/input/adt.123 > ../outputs/output.${1}/t1659
echo ">>>>>>>>running test 1660"
../source/schedule.exe 6 2 3  < ../inputs/input/adt.155 > ../outputs/output.${1}/t1660
echo ">>>>>>>>running test 1661"
../source/schedule.exe 1 8 7  < ../inputs/input/adt.116 > ../outputs/output.${1}/t1661
echo ">>>>>>>>running test 1662"
../source/schedule.exe 8 2 7  < ../inputs/input/adt.150 > ../outputs/output.${1}/t1662
echo ">>>>>>>>running test 1663"
../source/schedule.exe 0 6 8  < ../inputs/input/adt.172 > ../outputs/output.${1}/t1663
echo ">>>>>>>>running test 1664"
../source/schedule.exe 3 9 2  < ../inputs/input/adt.175 > ../outputs/output.${1}/t1664
echo ">>>>>>>>running test 1665"
../source/schedule.exe 9 4 7  < ../inputs/input/adt.122 > ../outputs/output.${1}/t1665
echo ">>>>>>>>running test 1666"
../source/schedule.exe 0 7 2  < ../inputs/input/adt.116 > ../outputs/output.${1}/t1666
echo ">>>>>>>>running test 1667"
../source/schedule.exe 7 4 9  < ../inputs/input/adt.102 > ../outputs/output.${1}/t1667
echo ">>>>>>>>running test 1668"
../source/schedule.exe 3 1 9  < ../inputs/input/adt.165 > ../outputs/output.${1}/t1668
echo ">>>>>>>>running test 1669"
../source/schedule.exe 1 3 9  < ../inputs/input/adt.159 > ../outputs/output.${1}/t1669
echo ">>>>>>>>running test 1670"
../source/schedule.exe 0 7 0  < ../inputs/input/adt.163 > ../outputs/output.${1}/t1670
echo ">>>>>>>>running test 1671"
../source/schedule.exe 1 3 5  < ../inputs/input/adt.144 > ../outputs/output.${1}/t1671
echo ">>>>>>>>running test 1672"
../source/schedule.exe 1 1 1  < ../inputs/input/adt.164 > ../outputs/output.${1}/t1672
echo ">>>>>>>>running test 1673"
../source/schedule.exe 3 4 3  < ../inputs/input/adt.179 > ../outputs/output.${1}/t1673
echo ">>>>>>>>running test 1674"
../source/schedule.exe 10 5 4  < ../inputs/input/adt.159 > ../outputs/output.${1}/t1674
echo ">>>>>>>>running test 1675"
../source/schedule.exe 8 7 6  < ../inputs/input/adt.140 > ../outputs/output.${1}/t1675
echo ">>>>>>>>running test 1676"
../source/schedule.exe 3 3 5  < ../inputs/input/adt.118 > ../outputs/output.${1}/t1676
echo ">>>>>>>>running test 1677"
../source/schedule.exe 0 0 2  < ../inputs/input/adt.119 > ../outputs/output.${1}/t1677
echo ">>>>>>>>running test 1678"
../source/schedule.exe 4 8 0  < ../inputs/input/adt.151 > ../outputs/output.${1}/t1678
echo ">>>>>>>>running test 1679"
../source/schedule.exe 3 5 6  < ../inputs/input/adt.103 > ../outputs/output.${1}/t1679
echo ">>>>>>>>running test 1680"
../source/schedule.exe 1 2 9  < ../inputs/input/adt.112 > ../outputs/output.${1}/t1680
echo ">>>>>>>>running test 1681"
../source/schedule.exe 7 0 1  < ../inputs/input/adt.114 > ../outputs/output.${1}/t1681
echo ">>>>>>>>running test 1682"
../source/schedule.exe 8 5 1  < ../inputs/input/adt.113 > ../outputs/output.${1}/t1682
echo ">>>>>>>>running test 1683"
../source/schedule.exe 1 0 0  < ../inputs/input/adt.178 > ../outputs/output.${1}/t1683
echo ">>>>>>>>running test 1684"
../source/schedule.exe 9 0 7  < ../inputs/input/adt.140 > ../outputs/output.${1}/t1684
echo ">>>>>>>>running test 1685"
../source/schedule.exe 10 3 9  < ../inputs/input/adt.136 > ../outputs/output.${1}/t1685
echo ">>>>>>>>running test 1686"
../source/schedule.exe 8 4 3  < ../inputs/input/adt.131 > ../outputs/output.${1}/t1686
echo ">>>>>>>>running test 1687"
../source/schedule.exe 4 1 4  < ../inputs/input/dat615 > ../outputs/output.${1}/t1687
echo ">>>>>>>>running test 1688"
../source/schedule.exe 1 0 1  < ../inputs/input/dat615 > ../outputs/output.${1}/t1688
echo ">>>>>>>>running test 1689"
../source/schedule.exe 1 1 0  < ../inputs/input/nt.31 > ../outputs/output.${1}/t1689
echo ">>>>>>>>running test 1690"
../source/schedule.exe 1 1 1  < ../inputs/input/nt.32 > ../outputs/output.${1}/t1690
echo ">>>>>>>>running test 1691"
../source/schedule.exe 2 0 1  < ../inputs/input/nt.32 > ../outputs/output.${1}/t1691
echo ">>>>>>>>running test 1692"
../source/schedule.exe 1 0 1  < ../inputs/input/nt.33 > ../outputs/output.${1}/t1692
echo ">>>>>>>>running test 1693"
../source/schedule.exe 5 1 4  < ../inputs/input/dat615 > ../outputs/output.${1}/t1693
echo ">>>>>>>>running test 1694"
../source/schedule.exe 5 3 3  < ../inputs/input/dat610 > ../outputs/output.${1}/t1694
echo ">>>>>>>>running test 1695"
../source/schedule.exe 1 2 1  < ../inputs/input/dat581 > ../outputs/output.${1}/t1695
echo ">>>>>>>>running test 1696"
../source/schedule.exe 1 3 2  < ../inputs/input/dat557 > ../outputs/output.${1}/t1696
echo ">>>>>>>>running test 1697"
../source/schedule.exe 0 5 1  < ../inputs/input/dat317 > ../outputs/output.${1}/t1697
echo ">>>>>>>>running test 1698"
../source/schedule.exe 4 0 1  < ../inputs/input/dat309 > ../outputs/output.${1}/t1698
echo ">>>>>>>>running test 1699"
../source/schedule.exe 5 0 4  < ../inputs/input/dat217 > ../outputs/output.${1}/t1699
echo ">>>>>>>>running test 1700"
../source/schedule.exe 1 2 0  < ../inputs/input/dat185 > ../outputs/output.${1}/t1700
echo ">>>>>>>>running test 1701"
../source/schedule.exe 3 0 2  < ../inputs/input/dat108 > ../outputs/output.${1}/t1701
echo ">>>>>>>>running test 1702"
../source/schedule.exe 4 1 0  < ../inputs/input/dat054 > ../outputs/output.${1}/t1702
echo ">>>>>>>>running test 1703"
../source/schedule.exe 1 0 2  < ../inputs/input/dat050 > ../outputs/output.${1}/t1703
echo ">>>>>>>>running test 1704"
../source/schedule.exe 5 1 1  < ../inputs/input/dat036 > ../outputs/output.${1}/t1704
echo ">>>>>>>>running test 1705"
../source/schedule.exe 2 0 1  < ../inputs/input/dat581 > ../outputs/output.${1}/t1705
echo ">>>>>>>>running test 1706"
../source/schedule.exe 1 4 2  < ../inputs/input/dat557 > ../outputs/output.${1}/t1706
echo ">>>>>>>>running test 1707"
../source/schedule.exe 0 3 0  < ../inputs/input/dat317 > ../outputs/output.${1}/t1707
echo ">>>>>>>>running test 1708"
../source/schedule.exe 4 1 0  < ../inputs/input/dat309 > ../outputs/output.${1}/t1708
echo ">>>>>>>>running test 1709"
../source/schedule.exe 5 4 4  < ../inputs/input/dat217 > ../outputs/output.${1}/t1709
echo ">>>>>>>>running test 1710"
../source/schedule.exe 5 0 2  < ../inputs/input/dat185 > ../outputs/output.${1}/t1710
echo ">>>>>>>>running test 1711"
../source/schedule.exe 3 4 2  < ../inputs/input/dat108 > ../outputs/output.${1}/t1711
echo ">>>>>>>>running test 1712"
../source/schedule.exe 4 1 1  < ../inputs/input/dat054 > ../outputs/output.${1}/t1712
echo ">>>>>>>>running test 1713"
../source/schedule.exe 1 1 0  < ../inputs/input/dat050 > ../outputs/output.${1}/t1713
echo ">>>>>>>>running test 1714"
../source/schedule.exe 5 0 1  < ../inputs/input/dat036 > ../outputs/output.${1}/t1714
echo ">>>>>>>>running test 1715"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.1 > ../outputs/output.${1}/t1715
echo ">>>>>>>>running test 1716"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.2 > ../outputs/output.${1}/t1716
echo ">>>>>>>>running test 1717"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.3 > ../outputs/output.${1}/t1717
echo ">>>>>>>>running test 1718"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.4 > ../outputs/output.${1}/t1718
echo ">>>>>>>>running test 1719"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.5 > ../outputs/output.${1}/t1719
echo ">>>>>>>>running test 1720"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.6 > ../outputs/output.${1}/t1720
echo ">>>>>>>>running test 1721"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.7 > ../outputs/output.${1}/t1721
echo ">>>>>>>>running test 1722"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.8 > ../outputs/output.${1}/t1722
echo ">>>>>>>>running test 1723"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.9 > ../outputs/output.${1}/t1723
echo ">>>>>>>>running test 1724"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.10 > ../outputs/output.${1}/t1724
echo ">>>>>>>>running test 1725"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.11 > ../outputs/output.${1}/t1725
echo ">>>>>>>>running test 1726"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.12 > ../outputs/output.${1}/t1726
echo ">>>>>>>>running test 1727"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.13 > ../outputs/output.${1}/t1727
echo ">>>>>>>>running test 1728"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.14 > ../outputs/output.${1}/t1728
echo ">>>>>>>>running test 1729"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.15 > ../outputs/output.${1}/t1729
echo ">>>>>>>>running test 1730"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.16 > ../outputs/output.${1}/t1730
echo ">>>>>>>>running test 1731"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.17 > ../outputs/output.${1}/t1731
echo ">>>>>>>>running test 1732"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.18 > ../outputs/output.${1}/t1732
echo ">>>>>>>>running test 1733"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.19 > ../outputs/output.${1}/t1733
echo ">>>>>>>>running test 1734"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.20 > ../outputs/output.${1}/t1734
echo ">>>>>>>>running test 1735"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.21 > ../outputs/output.${1}/t1735
echo ">>>>>>>>running test 1736"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.22 > ../outputs/output.${1}/t1736
echo ">>>>>>>>running test 1737"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.23 > ../outputs/output.${1}/t1737
echo ">>>>>>>>running test 1738"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.24 > ../outputs/output.${1}/t1738
echo ">>>>>>>>running test 1739"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.25 > ../outputs/output.${1}/t1739
echo ">>>>>>>>running test 1740"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.26 > ../outputs/output.${1}/t1740
echo ">>>>>>>>running test 1741"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.27 > ../outputs/output.${1}/t1741
echo ">>>>>>>>running test 1742"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.28 > ../outputs/output.${1}/t1742
echo ">>>>>>>>running test 1743"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.29 > ../outputs/output.${1}/t1743
echo ">>>>>>>>running test 1744"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.30 > ../outputs/output.${1}/t1744
echo ">>>>>>>>running test 1745"
../source/schedule.exe 5 0 4  < ../inputs/input/dat615 > ../outputs/output.${1}/t1745
echo ">>>>>>>>running test 1746"
../source/schedule.exe 5 3 3  < ../inputs/input/dat610 > ../outputs/output.${1}/t1746
echo ">>>>>>>>running test 1747"
../source/schedule.exe 0 2 1  < ../inputs/input/dat581 > ../outputs/output.${1}/t1747
echo ">>>>>>>>running test 1748"
../source/schedule.exe 0 3 2  < ../inputs/input/dat557 > ../outputs/output.${1}/t1748
echo ">>>>>>>>running test 1749"
../source/schedule.exe 0 3 1  < ../inputs/input/dat317 > ../outputs/output.${1}/t1749
echo ">>>>>>>>running test 1750"
../source/schedule.exe 4 2 1  < ../inputs/input/dat309 > ../outputs/output.${1}/t1750
echo ">>>>>>>>running test 1751"
../source/schedule.exe 5 1 4  < ../inputs/input/dat217 > ../outputs/output.${1}/t1751
echo ">>>>>>>>running test 1752"
../source/schedule.exe 1 0 0  < ../inputs/input/dat185 > ../outputs/output.${1}/t1752
echo ">>>>>>>>running test 1753"
../source/schedule.exe 1 0 2  < ../inputs/input/dat108 > ../outputs/output.${1}/t1753
echo ">>>>>>>>running test 1754"
../source/schedule.exe 0 1 0  < ../inputs/input/dat054 > ../outputs/output.${1}/t1754
echo ">>>>>>>>running test 1755"
../source/schedule.exe 1 1 2  < ../inputs/input/dat050 > ../outputs/output.${1}/t1755
echo ">>>>>>>>running test 1756"
../source/schedule.exe 5 1 0  < ../inputs/input/dat036 > ../outputs/output.${1}/t1756
echo ">>>>>>>>running test 1757"
../source/schedule.exe 5 0 1  < ../inputs/input/dat581 > ../outputs/output.${1}/t1757
echo ">>>>>>>>running test 1758"
../source/schedule.exe 1 2 2  < ../inputs/input/dat557 > ../outputs/output.${1}/t1758
echo ">>>>>>>>running test 1759"
../source/schedule.exe 0 1 0  < ../inputs/input/dat317 > ../outputs/output.${1}/t1759
echo ">>>>>>>>running test 1760"
../source/schedule.exe 4 1 3  < ../inputs/input/dat309 > ../outputs/output.${1}/t1760
echo ">>>>>>>>running test 1761"
../source/schedule.exe 5 0 4  < ../inputs/input/dat217 > ../outputs/output.${1}/t1761
echo ">>>>>>>>running test 1762"
../source/schedule.exe 5 0 1  < ../inputs/input/dat185 > ../outputs/output.${1}/t1762
echo ">>>>>>>>running test 1763"
../source/schedule.exe 2 4 2  < ../inputs/input/dat108 > ../outputs/output.${1}/t1763
echo ">>>>>>>>running test 1764"
../source/schedule.exe 4 0 1  < ../inputs/input/dat054 > ../outputs/output.${1}/t1764
echo ">>>>>>>>running test 1765"
../source/schedule.exe 1 0 0  < ../inputs/input/dat050 > ../outputs/output.${1}/t1765
echo ">>>>>>>>running test 1766"
../source/schedule.exe 5 4 1  < ../inputs/input/dat036 > ../outputs/output.${1}/t1766
echo ">>>>>>>>running test 1767"
../source/schedule.exe 7 1 9  < ../inputs/input/add.327 > ../outputs/output.${1}/t1767
echo ">>>>>>>>running test 1768"
../source/schedule.exe 7 1 4  < ../inputs/input/add.340 > ../outputs/output.${1}/t1768
echo ">>>>>>>>running test 1769"
../source/schedule.exe 3 5 9  < ../inputs/input/add.316 > ../outputs/output.${1}/t1769
echo ">>>>>>>>running test 1770"
../source/schedule.exe 9 7 2  < ../inputs/input/add.344 > ../outputs/output.${1}/t1770
echo ">>>>>>>>running test 1771"
../source/schedule.exe 0 2 6  < ../inputs/input/add.333 > ../outputs/output.${1}/t1771
echo ">>>>>>>>running test 1772"
../source/schedule.exe 3 2 0  < ../inputs/input/add.325 > ../outputs/output.${1}/t1772
echo ">>>>>>>>running test 1773"
../source/schedule.exe 10 5 0  < ../inputs/input/add.312 > ../outputs/output.${1}/t1773
echo ">>>>>>>>running test 1774"
../source/schedule.exe 7 4 10  < ../inputs/input/add.350 > ../outputs/output.${1}/t1774
echo ">>>>>>>>running test 1775"
../source/schedule.exe 2 2 3  < ../inputs/input/add.319 > ../outputs/output.${1}/t1775
echo ">>>>>>>>running test 1776"
../source/schedule.exe 8 5 3  < ../inputs/input/add.309 > ../outputs/output.${1}/t1776
echo ">>>>>>>>running test 1777"
../source/schedule.exe 9 5 1  < ../inputs/input/add.312 > ../outputs/output.${1}/t1777
echo ">>>>>>>>running test 1778"
../source/schedule.exe 0 10 1  < ../inputs/input/add.305 > ../outputs/output.${1}/t1778
echo ">>>>>>>>running test 1779"
../source/schedule.exe 4 1 0  < ../inputs/input/add.308 > ../outputs/output.${1}/t1779
echo ">>>>>>>>running test 1780"
../source/schedule.exe 10 0 4  < ../inputs/input/add.306 > ../outputs/output.${1}/t1780
echo ">>>>>>>>running test 1781"
../source/schedule.exe 10 3 0  < ../inputs/input/add.310 > ../outputs/output.${1}/t1781
echo ">>>>>>>>running test 1782"
../source/schedule.exe 9 5 5  < ../inputs/input/add.336 > ../outputs/output.${1}/t1782
echo ">>>>>>>>running test 1783"
../source/schedule.exe 0 9 7  < ../inputs/input/add.317 > ../outputs/output.${1}/t1783
echo ">>>>>>>>running test 1784"
../source/schedule.exe 2 7 3  < ../inputs/input/add.337 > ../outputs/output.${1}/t1784
echo ">>>>>>>>running test 1785"
../source/schedule.exe 7 10 9  < ../inputs/input/add.333 > ../outputs/output.${1}/t1785
echo ">>>>>>>>running test 1786"
../source/schedule.exe 5 9 3  < ../inputs/input/add.320 > ../outputs/output.${1}/t1786
echo ">>>>>>>>running test 1787"
../source/schedule.exe 1 8 3  < ../inputs/input/add.319 > ../outputs/output.${1}/t1787
echo ">>>>>>>>running test 1788"
../source/schedule.exe 5 10 9  < ../inputs/input/add.341 > ../outputs/output.${1}/t1788
echo ">>>>>>>>running test 1789"
../source/schedule.exe 9 9 0  < ../inputs/input/add.341 > ../outputs/output.${1}/t1789
echo ">>>>>>>>running test 1790"
../source/schedule.exe 4 4 2  < ../inputs/input/add.312 > ../outputs/output.${1}/t1790
echo ">>>>>>>>running test 1791"
../source/schedule.exe 9 10 7  < ../inputs/input/add.345 > ../outputs/output.${1}/t1791
echo ">>>>>>>>running test 1792"
../source/schedule.exe 2 9 7  < ../inputs/input/add.341 > ../outputs/output.${1}/t1792
echo ">>>>>>>>running test 1793"
../source/schedule.exe 2 1 5  < ../inputs/input/add.343 > ../outputs/output.${1}/t1793
echo ">>>>>>>>running test 1794"
../source/schedule.exe 9 3 2  < ../inputs/input/add.334 > ../outputs/output.${1}/t1794
echo ">>>>>>>>running test 1795"
../source/schedule.exe 6 9 1  < ../inputs/input/add.308 > ../outputs/output.${1}/t1795
echo ">>>>>>>>running test 1796"
../source/schedule.exe 6 4 9  < ../inputs/input/add.319 > ../outputs/output.${1}/t1796
echo ">>>>>>>>running test 1797"
../source/schedule.exe 10 9 4  < ../inputs/input/add.349 > ../outputs/output.${1}/t1797
echo ">>>>>>>>running test 1798"
../source/schedule.exe 1 3 4  < ../inputs/input/add.310 > ../outputs/output.${1}/t1798
echo ">>>>>>>>running test 1799"
../source/schedule.exe 0 7 0  < ../inputs/input/add.334 > ../outputs/output.${1}/t1799
echo ">>>>>>>>running test 1800"
../source/schedule.exe 3 2 4  < ../inputs/input/add.343 > ../outputs/output.${1}/t1800
echo ">>>>>>>>running test 1801"
../source/schedule.exe 6 2 0  < ../inputs/input/add.347 > ../outputs/output.${1}/t1801
echo ">>>>>>>>running test 1802"
../source/schedule.exe 7 6 9  < ../inputs/input/add.320 > ../outputs/output.${1}/t1802
echo ">>>>>>>>running test 1803"
../source/schedule.exe 0 7 6  < ../inputs/input/add.334 > ../outputs/output.${1}/t1803
echo ">>>>>>>>running test 1804"
../source/schedule.exe 10 0 0  < ../inputs/input/add.300 > ../outputs/output.${1}/t1804
echo ">>>>>>>>running test 1805"
../source/schedule.exe 6 1 8  < ../inputs/input/add.350 > ../outputs/output.${1}/t1805
echo ">>>>>>>>running test 1806"
../source/schedule.exe 3 10 6  < ../inputs/input/add.325 > ../outputs/output.${1}/t1806
echo ">>>>>>>>running test 1807"
../source/schedule.exe 10 7 5  < ../inputs/input/add.332 > ../outputs/output.${1}/t1807
echo ">>>>>>>>running test 1808"
../source/schedule.exe 7 10 10  < ../inputs/input/add.325 > ../outputs/output.${1}/t1808
echo ">>>>>>>>running test 1809"
../source/schedule.exe 7 10 4  < ../inputs/input/add.313 > ../outputs/output.${1}/t1809
echo ">>>>>>>>running test 1810"
../source/schedule.exe 10 4 3  < ../inputs/input/add.302 > ../outputs/output.${1}/t1810
echo ">>>>>>>>running test 1811"
../source/schedule.exe 10 6 1  < ../inputs/input/add.335 > ../outputs/output.${1}/t1811
echo ">>>>>>>>running test 1812"
../source/schedule.exe 0 3 3  < ../inputs/input/add.304 > ../outputs/output.${1}/t1812
echo ">>>>>>>>running test 1813"
../source/schedule.exe 2 10 4  < ../inputs/input/add.312 > ../outputs/output.${1}/t1813
echo ">>>>>>>>running test 1814"
../source/schedule.exe 9 4 2  < ../inputs/input/add.319 > ../outputs/output.${1}/t1814
echo ">>>>>>>>running test 1815"
../source/schedule.exe 7 10 5  < ../inputs/input/add.322 > ../outputs/output.${1}/t1815
echo ">>>>>>>>running test 1816"
../source/schedule.exe 4 3 4  < ../inputs/input/add.343 > ../outputs/output.${1}/t1816
echo ">>>>>>>>running test 1817"
../source/schedule.exe 5 6 9  < ../inputs/input/add.335 > ../outputs/output.${1}/t1817
echo ">>>>>>>>running test 1818"
../source/schedule.exe 3 5 0  < ../inputs/input/add.313 > ../outputs/output.${1}/t1818
echo ">>>>>>>>running test 1819"
../source/schedule.exe 5 3 9  < ../inputs/input/add.302 > ../outputs/output.${1}/t1819
echo ">>>>>>>>running test 1820"
../source/schedule.exe 2 2 4  < ../inputs/input/add.303 > ../outputs/output.${1}/t1820
echo ">>>>>>>>running test 1821"
../source/schedule.exe 4 4 3  < ../inputs/input/add.324 > ../outputs/output.${1}/t1821
echo ">>>>>>>>running test 1822"
../source/schedule.exe 0 1 9  < ../inputs/input/add.333 > ../outputs/output.${1}/t1822
echo ">>>>>>>>running test 1823"
../source/schedule.exe 2 0 10  < ../inputs/input/add.301 > ../outputs/output.${1}/t1823
echo ">>>>>>>>running test 1824"
../source/schedule.exe 0 0 6  < ../inputs/input/add.349 > ../outputs/output.${1}/t1824
echo ">>>>>>>>running test 1825"
../source/schedule.exe 6 1 3  < ../inputs/input/add.329 > ../outputs/output.${1}/t1825
echo ">>>>>>>>running test 1826"
../source/schedule.exe 10 4 1  < ../inputs/input/add.321 > ../outputs/output.${1}/t1826
echo ">>>>>>>>running test 1827"
../source/schedule.exe 6 10 9  < ../inputs/input/add.309 > ../outputs/output.${1}/t1827
echo ">>>>>>>>running test 1828"
../source/schedule.exe 1 0 2  < ../inputs/input/add.327 > ../outputs/output.${1}/t1828
echo ">>>>>>>>running test 1829"
../source/schedule.exe 7 1 2  < ../inputs/input/add.301 > ../outputs/output.${1}/t1829
echo ">>>>>>>>running test 1830"
../source/schedule.exe 0 3 1  < ../inputs/input/add.313 > ../outputs/output.${1}/t1830
echo ">>>>>>>>running test 1831"
../source/schedule.exe 6 7 4  < ../inputs/input/add.324 > ../outputs/output.${1}/t1831
echo ">>>>>>>>running test 1832"
../source/schedule.exe 7 10 2  < ../inputs/input/add.302 > ../outputs/output.${1}/t1832
echo ">>>>>>>>running test 1833"
../source/schedule.exe 3 9 2  < ../inputs/input/add.317 > ../outputs/output.${1}/t1833
echo ">>>>>>>>running test 1834"
../source/schedule.exe 2 3 8  < ../inputs/input/add.305 > ../outputs/output.${1}/t1834
echo ">>>>>>>>running test 1835"
../source/schedule.exe 8 10 9  < ../inputs/input/add.339 > ../outputs/output.${1}/t1835
echo ">>>>>>>>running test 1836"
../source/schedule.exe 2 10 2  < ../inputs/input/add.304 > ../outputs/output.${1}/t1836
echo ">>>>>>>>running test 1837"
../source/schedule.exe 1 9 5  < ../inputs/input/add.348 > ../outputs/output.${1}/t1837
echo ">>>>>>>>running test 1838"
../source/schedule.exe 2 3 0  < ../inputs/input/add.344 > ../outputs/output.${1}/t1838
echo ">>>>>>>>running test 1839"
../source/schedule.exe 3 8 6  < ../inputs/input/add.341 > ../outputs/output.${1}/t1839
echo ">>>>>>>>running test 1840"
../source/schedule.exe 1 1 9  < ../inputs/input/add.307 > ../outputs/output.${1}/t1840
echo ">>>>>>>>running test 1841"
../source/schedule.exe 9 10 10  < ../inputs/input/add.347 > ../outputs/output.${1}/t1841
echo ">>>>>>>>running test 1842"
../source/schedule.exe 0 7 5  < ../inputs/input/add.316 > ../outputs/output.${1}/t1842
echo ">>>>>>>>running test 1843"
../source/schedule.exe 8 7 1  < ../inputs/input/add.336 > ../outputs/output.${1}/t1843
echo ">>>>>>>>running test 1844"
../source/schedule.exe 4 2 6  < ../inputs/input/add.326 > ../outputs/output.${1}/t1844
echo ">>>>>>>>running test 1845"
../source/schedule.exe 9 4 6  < ../inputs/input/add.304 > ../outputs/output.${1}/t1845
echo ">>>>>>>>running test 1846"
../source/schedule.exe 7 6 8  < ../inputs/input/add.314 > ../outputs/output.${1}/t1846
echo ">>>>>>>>running test 1847"
../source/schedule.exe 3 9 7  < ../inputs/input/add.350 > ../outputs/output.${1}/t1847
echo ">>>>>>>>running test 1848"
../source/schedule.exe 1 1 10  < ../inputs/input/add.327 > ../outputs/output.${1}/t1848
echo ">>>>>>>>running test 1849"
../source/schedule.exe 9 8 4  < ../inputs/input/add.343 > ../outputs/output.${1}/t1849
echo ">>>>>>>>running test 1850"
../source/schedule.exe 10 9 0  < ../inputs/input/add.305 > ../outputs/output.${1}/t1850
echo ">>>>>>>>running test 1851"
../source/schedule.exe 0 2 2  < ../inputs/input/add.305 > ../outputs/output.${1}/t1851
echo ">>>>>>>>running test 1852"
../source/schedule.exe 6 10 7  < ../inputs/input/add.331 > ../outputs/output.${1}/t1852
echo ">>>>>>>>running test 1853"
../source/schedule.exe 1 5 10  < ../inputs/input/add.306 > ../outputs/output.${1}/t1853
echo ">>>>>>>>running test 1854"
../source/schedule.exe 4 3 8  < ../inputs/input/add.330 > ../outputs/output.${1}/t1854
echo ">>>>>>>>running test 1855"
../source/schedule.exe 2 1 9  < ../inputs/input/add.344 > ../outputs/output.${1}/t1855
echo ">>>>>>>>running test 1856"
../source/schedule.exe 2 7 0  < ../inputs/input/add.308 > ../outputs/output.${1}/t1856
echo ">>>>>>>>running test 1857"
../source/schedule.exe 5 0 6  < ../inputs/input/add.303 > ../outputs/output.${1}/t1857
echo ">>>>>>>>running test 1858"
../source/schedule.exe 1 10 10  < ../inputs/input/add.320 > ../outputs/output.${1}/t1858
echo ">>>>>>>>running test 1859"
../source/schedule.exe 8 0 3  < ../inputs/input/add.341 > ../outputs/output.${1}/t1859
echo ">>>>>>>>running test 1860"
../source/schedule.exe 6 8 8  < ../inputs/input/add.330 > ../outputs/output.${1}/t1860
echo ">>>>>>>>running test 1861"
../source/schedule.exe 8 0 7  < ../inputs/input/add.316 > ../outputs/output.${1}/t1861
echo ">>>>>>>>running test 1862"
../source/schedule.exe 2 4 1  < ../inputs/input/add.306 > ../outputs/output.${1}/t1862
echo ">>>>>>>>running test 1863"
../source/schedule.exe 2 7 3  < ../inputs/input/add.314 > ../outputs/output.${1}/t1863
echo ">>>>>>>>running test 1864"
../source/schedule.exe 8 4 5  < ../inputs/input/add.343 > ../outputs/output.${1}/t1864
echo ">>>>>>>>running test 1865"
../source/schedule.exe 10 7 3  < ../inputs/input/add.323 > ../outputs/output.${1}/t1865
echo ">>>>>>>>running test 1866"
../source/schedule.exe 0 6 3  < ../inputs/input/add.315 > ../outputs/output.${1}/t1866
echo ">>>>>>>>running test 1867"
../source/schedule.exe 1  6  5   < ../inputs/input/lu1 > ../outputs/output.${1}/t1867
echo ">>>>>>>>running test 1868"
../source/schedule.exe 2  5  10   < ../inputs/input/lu2 > ../outputs/output.${1}/t1868
echo ">>>>>>>>running test 1869"
../source/schedule.exe 3  6  7   < ../inputs/input/lu3 > ../outputs/output.${1}/t1869
echo ">>>>>>>>running test 1870"
../source/schedule.exe 8  9  2   < ../inputs/input/lu4 > ../outputs/output.${1}/t1870
echo ">>>>>>>>running test 1871"
../source/schedule.exe 7  2  9   < ../inputs/input/lu5 > ../outputs/output.${1}/t1871
echo ">>>>>>>>running test 1872"
../source/schedule.exe 2  7  10   < ../inputs/input/lu6 > ../outputs/output.${1}/t1872
echo ">>>>>>>>running test 1873"
../source/schedule.exe 3  10  3   < ../inputs/input/lu7 > ../outputs/output.${1}/t1873
echo ">>>>>>>>running test 1874"
../source/schedule.exe 6  3  2   < ../inputs/input/lu8 > ../outputs/output.${1}/t1874
echo ">>>>>>>>running test 1875"
../source/schedule.exe 9  6  5   < ../inputs/input/lu9 > ../outputs/output.${1}/t1875
echo ">>>>>>>>running test 1876"
../source/schedule.exe 2  7  6   < ../inputs/input/lu10 > ../outputs/output.${1}/t1876
echo ">>>>>>>>running test 1877"
../source/schedule.exe 3  2  3   < ../inputs/input/lu11 > ../outputs/output.${1}/t1877
echo ">>>>>>>>running test 1878"
../source/schedule.exe 6  1  6   < ../inputs/input/lu12 > ../outputs/output.${1}/t1878
echo ">>>>>>>>running test 1879"
../source/schedule.exe 3  10  5   < ../inputs/input/lu13 > ../outputs/output.${1}/t1879
echo ">>>>>>>>running test 1880"
../source/schedule.exe 6  7  10   < ../inputs/input/lu14 > ../outputs/output.${1}/t1880
echo ">>>>>>>>running test 1881"
../source/schedule.exe 5  4  5   < ../inputs/input/lu15 > ../outputs/output.${1}/t1881
echo ">>>>>>>>running test 1882"
../source/schedule.exe 2  3  6   < ../inputs/input/lu16 > ../outputs/output.${1}/t1882
echo ">>>>>>>>running test 1883"
../source/schedule.exe 5  8  3   < ../inputs/input/lu17 > ../outputs/output.${1}/t1883
echo ">>>>>>>>running test 1884"
../source/schedule.exe 8  7  8   < ../inputs/input/lu18 > ../outputs/output.${1}/t1884
echo ">>>>>>>>running test 1885"
../source/schedule.exe 9  6  3   < ../inputs/input/lu19 > ../outputs/output.${1}/t1885
echo ">>>>>>>>running test 1886"
../source/schedule.exe 4  1  6   < ../inputs/input/lu20 > ../outputs/output.${1}/t1886
echo ">>>>>>>>running test 1887"
../source/schedule.exe 5  6  7   < ../inputs/input/lu21 > ../outputs/output.${1}/t1887
echo ">>>>>>>>running test 1888"
../source/schedule.exe 4  3  10   < ../inputs/input/lu22 > ../outputs/output.${1}/t1888
echo ">>>>>>>>running test 1889"
../source/schedule.exe 7  2  5   < ../inputs/input/lu23 > ../outputs/output.${1}/t1889
echo ">>>>>>>>running test 1890"
../source/schedule.exe 4  7  2   < ../inputs/input/lu24 > ../outputs/output.${1}/t1890
echo ">>>>>>>>running test 1891"
../source/schedule.exe 9  10  5   < ../inputs/input/lu25 > ../outputs/output.${1}/t1891
echo ">>>>>>>>running test 1892"
../source/schedule.exe 4  1  2   < ../inputs/input/lu26 > ../outputs/output.${1}/t1892
echo ">>>>>>>>running test 1893"
../source/schedule.exe 9  10  9   < ../inputs/input/lu27 > ../outputs/output.${1}/t1893
echo ">>>>>>>>running test 1894"
../source/schedule.exe 4  7  2   < ../inputs/input/lu28 > ../outputs/output.${1}/t1894
echo ">>>>>>>>running test 1895"
../source/schedule.exe 3  8  3   < ../inputs/input/lu29 > ../outputs/output.${1}/t1895
echo ">>>>>>>>running test 1896"
../source/schedule.exe 6  3  6   < ../inputs/input/lu30 > ../outputs/output.${1}/t1896
echo ">>>>>>>>running test 1897"
../source/schedule.exe 5  4  9   < ../inputs/input/lu31 > ../outputs/output.${1}/t1897
echo ">>>>>>>>running test 1898"
../source/schedule.exe 6  3  6   < ../inputs/input/lu32 > ../outputs/output.${1}/t1898
echo ">>>>>>>>running test 1899"
../source/schedule.exe 9  10  7   < ../inputs/input/lu33 > ../outputs/output.${1}/t1899
echo ">>>>>>>>running test 1900"
../source/schedule.exe 6  9  6   < ../inputs/input/lu34 > ../outputs/output.${1}/t1900
echo ">>>>>>>>running test 1901"
../source/schedule.exe 7  10  3   < ../inputs/input/lu35 > ../outputs/output.${1}/t1901
echo ">>>>>>>>running test 1902"
../source/schedule.exe 2  7  10   < ../inputs/input/lu36 > ../outputs/output.${1}/t1902
echo ">>>>>>>>running test 1903"
../source/schedule.exe 1  8  3   < ../inputs/input/lu37 > ../outputs/output.${1}/t1903
echo ">>>>>>>>running test 1904"
../source/schedule.exe 6  9  6   < ../inputs/input/lu38 > ../outputs/output.${1}/t1904
echo ">>>>>>>>running test 1905"
../source/schedule.exe 1  8  3   < ../inputs/input/lu39 > ../outputs/output.${1}/t1905
echo ">>>>>>>>running test 1906"
../source/schedule.exe 10  1  10   < ../inputs/input/lu40 > ../outputs/output.${1}/t1906
echo ">>>>>>>>running test 1907"
../source/schedule.exe 7  6  1   < ../inputs/input/lu41 > ../outputs/output.${1}/t1907
echo ">>>>>>>>running test 1908"
../source/schedule.exe 8  9  8   < ../inputs/input/lu42 > ../outputs/output.${1}/t1908
echo ">>>>>>>>running test 1909"
../source/schedule.exe 7  4  1   < ../inputs/input/lu43 > ../outputs/output.${1}/t1909
echo ">>>>>>>>running test 1910"
../source/schedule.exe 6  3  2   < ../inputs/input/lu44 > ../outputs/output.${1}/t1910
echo ">>>>>>>>running test 1911"
../source/schedule.exe 1  8  3   < ../inputs/input/lu45 > ../outputs/output.${1}/t1911
echo ">>>>>>>>running test 1912"
../source/schedule.exe 8  9  2   < ../inputs/input/lu46 > ../outputs/output.${1}/t1912
echo ">>>>>>>>running test 1913"
../source/schedule.exe 1  10  3   < ../inputs/input/lu47 > ../outputs/output.${1}/t1913
echo ">>>>>>>>running test 1914"
../source/schedule.exe 4  7  4   < ../inputs/input/lu48 > ../outputs/output.${1}/t1914
echo ">>>>>>>>running test 1915"
../source/schedule.exe 9  4  9   < ../inputs/input/lu49 > ../outputs/output.${1}/t1915
echo ">>>>>>>>running test 1916"
../source/schedule.exe 2  3  4   < ../inputs/input/lu50 > ../outputs/output.${1}/t1916
echo ">>>>>>>>running test 1917"
../source/schedule.exe 5  2  5   < ../inputs/input/lu51 > ../outputs/output.${1}/t1917
echo ">>>>>>>>running test 1918"
../source/schedule.exe 4  1  4   < ../inputs/input/lu52 > ../outputs/output.${1}/t1918
echo ">>>>>>>>running test 1919"
../source/schedule.exe 9  2  1   < ../inputs/input/lu53 > ../outputs/output.${1}/t1919
echo ">>>>>>>>running test 1920"
../source/schedule.exe 2  1  10   < ../inputs/input/lu54 > ../outputs/output.${1}/t1920
echo ">>>>>>>>running test 1921"
../source/schedule.exe 1  6  3   < ../inputs/input/lu55 > ../outputs/output.${1}/t1921
echo ">>>>>>>>running test 1922"
../source/schedule.exe 10  9  8   < ../inputs/input/lu56 > ../outputs/output.${1}/t1922
echo ">>>>>>>>running test 1923"
../source/schedule.exe 1  6  1   < ../inputs/input/lu57 > ../outputs/output.${1}/t1923
echo ">>>>>>>>running test 1924"
../source/schedule.exe 6  7  6   < ../inputs/input/lu58 > ../outputs/output.${1}/t1924
echo ">>>>>>>>running test 1925"
../source/schedule.exe 9  6  3   < ../inputs/input/lu59 > ../outputs/output.${1}/t1925
echo ">>>>>>>>running test 1926"
../source/schedule.exe 4  9  8   < ../inputs/input/lu60 > ../outputs/output.${1}/t1926
echo ">>>>>>>>running test 1927"
../source/schedule.exe 9  4  5   < ../inputs/input/lu61 > ../outputs/output.${1}/t1927
echo ">>>>>>>>running test 1928"
../source/schedule.exe 4  5  6   < ../inputs/input/lu62 > ../outputs/output.${1}/t1928
echo ">>>>>>>>running test 1929"
../source/schedule.exe 9  4  3   < ../inputs/input/lu63 > ../outputs/output.${1}/t1929
echo ">>>>>>>>running test 1930"
../source/schedule.exe 8  9  10   < ../inputs/input/lu64 > ../outputs/output.${1}/t1930
echo ">>>>>>>>running test 1931"
../source/schedule.exe 1  6  1   < ../inputs/input/lu65 > ../outputs/output.${1}/t1931
echo ">>>>>>>>running test 1932"
../source/schedule.exe 2  7  2   < ../inputs/input/lu66 > ../outputs/output.${1}/t1932
echo ">>>>>>>>running test 1933"
../source/schedule.exe 7  6  1   < ../inputs/input/lu67 > ../outputs/output.${1}/t1933
echo ">>>>>>>>running test 1934"
../source/schedule.exe 6  5  6   < ../inputs/input/lu68 > ../outputs/output.${1}/t1934
echo ">>>>>>>>running test 1935"
../source/schedule.exe 1  6  5   < ../inputs/input/lu69 > ../outputs/output.${1}/t1935
echo ">>>>>>>>running test 1936"
../source/schedule.exe 6  1  8   < ../inputs/input/lu70 > ../outputs/output.${1}/t1936
echo ">>>>>>>>running test 1937"
../source/schedule.exe 5  4  9   < ../inputs/input/lu71 > ../outputs/output.${1}/t1937
echo ">>>>>>>>running test 1938"
../source/schedule.exe 2  5  6   < ../inputs/input/lu72 > ../outputs/output.${1}/t1938
echo ">>>>>>>>running test 1939"
../source/schedule.exe 3  6  7   < ../inputs/input/lu73 > ../outputs/output.${1}/t1939
echo ">>>>>>>>running test 1940"
../source/schedule.exe 8  1  10   < ../inputs/input/lu74 > ../outputs/output.${1}/t1940
echo ">>>>>>>>running test 1941"
../source/schedule.exe 5  10  3   < ../inputs/input/lu75 > ../outputs/output.${1}/t1941
echo ">>>>>>>>running test 1942"
../source/schedule.exe 4  7  10   < ../inputs/input/lu76 > ../outputs/output.${1}/t1942
echo ">>>>>>>>running test 1943"
../source/schedule.exe 9  2  7   < ../inputs/input/lu77 > ../outputs/output.${1}/t1943
echo ">>>>>>>>running test 1944"
../source/schedule.exe 4  1  10   < ../inputs/input/lu78 > ../outputs/output.${1}/t1944
echo ">>>>>>>>running test 1945"
../source/schedule.exe 5  2  3   < ../inputs/input/lu79 > ../outputs/output.${1}/t1945
echo ">>>>>>>>running test 1946"
../source/schedule.exe 4  5  6   < ../inputs/input/lu80 > ../outputs/output.${1}/t1946
echo ">>>>>>>>running test 1947"
../source/schedule.exe 3  2  3   < ../inputs/input/lu81 > ../outputs/output.${1}/t1947
echo ">>>>>>>>running test 1948"
../source/schedule.exe 8  3  2   < ../inputs/input/lu82 > ../outputs/output.${1}/t1948
echo ">>>>>>>>running test 1949"
../source/schedule.exe 3  6  5   < ../inputs/input/lu83 > ../outputs/output.${1}/t1949
echo ">>>>>>>>running test 1950"
../source/schedule.exe 6  7  8   < ../inputs/input/lu84 > ../outputs/output.${1}/t1950
echo ">>>>>>>>running test 1951"
../source/schedule.exe 1  6  9   < ../inputs/input/lu85 > ../outputs/output.${1}/t1951
echo ">>>>>>>>running test 1952"
../source/schedule.exe 4  1  6   < ../inputs/input/lu86 > ../outputs/output.${1}/t1952
echo ">>>>>>>>running test 1953"
../source/schedule.exe 1  8  3   < ../inputs/input/lu87 > ../outputs/output.${1}/t1953
echo ">>>>>>>>running test 1954"
../source/schedule.exe 6  3  4   < ../inputs/input/lu88 > ../outputs/output.${1}/t1954
echo ">>>>>>>>running test 1955"
../source/schedule.exe 5  10  7   < ../inputs/input/lu89 > ../outputs/output.${1}/t1955
echo ">>>>>>>>running test 1956"
../source/schedule.exe 6  9  2   < ../inputs/input/lu90 > ../outputs/output.${1}/t1956
echo ">>>>>>>>running test 1957"
../source/schedule.exe 5  10  1   < ../inputs/input/lu91 > ../outputs/output.${1}/t1957
echo ">>>>>>>>running test 1958"
../source/schedule.exe 4  7  8   < ../inputs/input/lu92 > ../outputs/output.${1}/t1958
echo ">>>>>>>>running test 1959"
../source/schedule.exe 5  2  5   < ../inputs/input/lu93 > ../outputs/output.${1}/t1959
echo ">>>>>>>>running test 1960"
../source/schedule.exe 4  7  8   < ../inputs/input/lu94 > ../outputs/output.${1}/t1960
echo ">>>>>>>>running test 1961"
../source/schedule.exe 3  4  9   < ../inputs/input/lu95 > ../outputs/output.${1}/t1961
echo ">>>>>>>>running test 1962"
../source/schedule.exe 8  5  4   < ../inputs/input/lu96 > ../outputs/output.${1}/t1962
echo ">>>>>>>>running test 1963"
../source/schedule.exe 9  10  5   < ../inputs/input/lu97 > ../outputs/output.${1}/t1963
echo ">>>>>>>>running test 1964"
../source/schedule.exe 4  9  8   < ../inputs/input/lu98 > ../outputs/output.${1}/t1964
echo ">>>>>>>>running test 1965"
../source/schedule.exe 5  2  7   < ../inputs/input/lu99 > ../outputs/output.${1}/t1965
echo ">>>>>>>>running test 1966"
../source/schedule.exe 4  5  2   < ../inputs/input/lu100 > ../outputs/output.${1}/t1966
echo ">>>>>>>>running test 1967"
../source/schedule.exe 5  6  1   < ../inputs/input/lu101 > ../outputs/output.${1}/t1967
echo ">>>>>>>>running test 1968"
../source/schedule.exe 4  7  8   < ../inputs/input/lu102 > ../outputs/output.${1}/t1968
echo ">>>>>>>>running test 1969"
../source/schedule.exe 1  6  1   < ../inputs/input/lu103 > ../outputs/output.${1}/t1969
echo ">>>>>>>>running test 1970"
../source/schedule.exe 2  7  10   < ../inputs/input/lu104 > ../outputs/output.${1}/t1970
echo ">>>>>>>>running test 1971"
../source/schedule.exe 1  10  5   < ../inputs/input/lu105 > ../outputs/output.${1}/t1971
echo ">>>>>>>>running test 1972"
../source/schedule.exe 6  3  8   < ../inputs/input/lu106 > ../outputs/output.${1}/t1972
echo ">>>>>>>>running test 1973"
../source/schedule.exe 5  2  7   < ../inputs/input/lu107 > ../outputs/output.${1}/t1973
echo ">>>>>>>>running test 1974"
../source/schedule.exe 10  1  10   < ../inputs/input/lu108 > ../outputs/output.${1}/t1974
echo ">>>>>>>>running test 1975"
../source/schedule.exe 9  2  3   < ../inputs/input/lu109 > ../outputs/output.${1}/t1975
echo ">>>>>>>>running test 1976"
../source/schedule.exe 6  9  6   < ../inputs/input/lu110 > ../outputs/output.${1}/t1976
echo ">>>>>>>>running test 1977"
../source/schedule.exe 3  2  1   < ../inputs/input/lu111 > ../outputs/output.${1}/t1977
echo ">>>>>>>>running test 1978"
../source/schedule.exe 2  5  6   < ../inputs/input/lu112 > ../outputs/output.${1}/t1978
echo ">>>>>>>>running test 1979"
../source/schedule.exe 3  10  7   < ../inputs/input/lu113 > ../outputs/output.${1}/t1979
echo ">>>>>>>>running test 1980"
../source/schedule.exe 8  5  10   < ../inputs/input/lu114 > ../outputs/output.${1}/t1980
echo ">>>>>>>>running test 1981"
../source/schedule.exe 3  6  9   < ../inputs/input/lu115 > ../outputs/output.${1}/t1981
echo ">>>>>>>>running test 1982"
../source/schedule.exe 10  5  2   < ../inputs/input/lu116 > ../outputs/output.${1}/t1982
echo ">>>>>>>>running test 1983"
../source/schedule.exe 7  8  9   < ../inputs/input/lu117 > ../outputs/output.${1}/t1983
echo ">>>>>>>>running test 1984"
../source/schedule.exe 4  3  2   < ../inputs/input/lu118 > ../outputs/output.${1}/t1984
echo ">>>>>>>>running test 1985"
../source/schedule.exe 9  6  7   < ../inputs/input/lu119 > ../outputs/output.${1}/t1985
echo ">>>>>>>>running test 1986"
../source/schedule.exe 8  7  4   < ../inputs/input/lu120 > ../outputs/output.${1}/t1986
echo ">>>>>>>>running test 1987"
../source/schedule.exe 1  4  5   < ../inputs/input/lu121 > ../outputs/output.${1}/t1987
echo ">>>>>>>>running test 1988"
../source/schedule.exe 4  3  6   < ../inputs/input/lu122 > ../outputs/output.${1}/t1988
echo ">>>>>>>>running test 1989"
../source/schedule.exe 7  4  5   < ../inputs/input/lu123 > ../outputs/output.${1}/t1989
echo ">>>>>>>>running test 1990"
../source/schedule.exe 8  3  2   < ../inputs/input/lu124 > ../outputs/output.${1}/t1990
echo ">>>>>>>>running test 1991"
../source/schedule.exe 9  10  1   < ../inputs/input/lu125 > ../outputs/output.${1}/t1991
echo ">>>>>>>>running test 1992"
../source/schedule.exe 6  3  6   < ../inputs/input/lu126 > ../outputs/output.${1}/t1992
echo ">>>>>>>>running test 1993"
../source/schedule.exe 1  2  3   < ../inputs/input/lu127 > ../outputs/output.${1}/t1993
echo ">>>>>>>>running test 1994"
../source/schedule.exe 6  1  6   < ../inputs/input/lu128 > ../outputs/output.${1}/t1994
echo ">>>>>>>>running test 1995"
../source/schedule.exe 1  2  1   < ../inputs/input/lu129 > ../outputs/output.${1}/t1995
echo ">>>>>>>>running test 1996"
../source/schedule.exe 2  7  8   < ../inputs/input/lu130 > ../outputs/output.${1}/t1996
echo ">>>>>>>>running test 1997"
../source/schedule.exe 9  2  7   < ../inputs/input/lu131 > ../outputs/output.${1}/t1997
echo ">>>>>>>>running test 1998"
../source/schedule.exe 8  5  4   < ../inputs/input/lu132 > ../outputs/output.${1}/t1998
echo ">>>>>>>>running test 1999"
../source/schedule.exe 3  10  7   < ../inputs/input/lu133 > ../outputs/output.${1}/t1999
echo ">>>>>>>>running test 2000"
../source/schedule.exe 2  3  4   < ../inputs/input/lu134 > ../outputs/output.${1}/t2000
echo ">>>>>>>>running test 2001"
../source/schedule.exe 9  4  5   < ../inputs/input/lu135 > ../outputs/output.${1}/t2001
echo ">>>>>>>>running test 2002"
../source/schedule.exe 8  3  4   < ../inputs/input/lu136 > ../outputs/output.${1}/t2002
echo ">>>>>>>>running test 2003"
../source/schedule.exe 3  4  9   < ../inputs/input/lu137 > ../outputs/output.${1}/t2003
echo ">>>>>>>>running test 2004"
../source/schedule.exe 10  9  8   < ../inputs/input/lu138 > ../outputs/output.${1}/t2004
echo ">>>>>>>>running test 2005"
../source/schedule.exe 9  2  7   < ../inputs/input/lu139 > ../outputs/output.${1}/t2005
echo ">>>>>>>>running test 2006"
../source/schedule.exe 8  9  6   < ../inputs/input/lu140 > ../outputs/output.${1}/t2006
echo ">>>>>>>>running test 2007"
../source/schedule.exe 9  8  5   < ../inputs/input/lu141 > ../outputs/output.${1}/t2007
echo ">>>>>>>>running test 2008"
../source/schedule.exe 6  9  10   < ../inputs/input/lu142 > ../outputs/output.${1}/t2008
echo ">>>>>>>>running test 2009"
../source/schedule.exe 3  6  1   < ../inputs/input/lu143 > ../outputs/output.${1}/t2009
echo ">>>>>>>>running test 2010"
../source/schedule.exe 8  1  4   < ../inputs/input/lu144 > ../outputs/output.${1}/t2010
echo ">>>>>>>>running test 2011"
../source/schedule.exe 3  6  1   < ../inputs/input/lu145 > ../outputs/output.${1}/t2011
echo ">>>>>>>>running test 2012"
../source/schedule.exe 2  7  4   < ../inputs/input/lu146 > ../outputs/output.${1}/t2012
echo ">>>>>>>>running test 2013"
../source/schedule.exe 7  2  5   < ../inputs/input/lu147 > ../outputs/output.${1}/t2013
echo ">>>>>>>>running test 2014"
../source/schedule.exe 2  7  4   < ../inputs/input/lu148 > ../outputs/output.${1}/t2014
echo ">>>>>>>>running test 2015"
../source/schedule.exe 1  2  7   < ../inputs/input/lu149 > ../outputs/output.${1}/t2015
echo ">>>>>>>>running test 2016"
../source/schedule.exe 2  7  4   < ../inputs/input/lu150 > ../outputs/output.${1}/t2016
echo ">>>>>>>>running test 2017"
../source/schedule.exe 9  6  9   < ../inputs/input/lu151 > ../outputs/output.${1}/t2017
echo ">>>>>>>>running test 2018"
../source/schedule.exe 4  9  2   < ../inputs/input/lu152 > ../outputs/output.${1}/t2018
echo ">>>>>>>>running test 2019"
../source/schedule.exe 7  2  7   < ../inputs/input/lu153 > ../outputs/output.${1}/t2019
echo ">>>>>>>>running test 2020"
../source/schedule.exe 2  3  6   < ../inputs/input/lu154 > ../outputs/output.${1}/t2020
echo ">>>>>>>>running test 2021"
../source/schedule.exe 3  6  7   < ../inputs/input/lu155 > ../outputs/output.${1}/t2021
echo ">>>>>>>>running test 2022"
../source/schedule.exe 4  7  8   < ../inputs/input/lu156 > ../outputs/output.${1}/t2022
echo ">>>>>>>>running test 2023"
../source/schedule.exe 9  2  1   < ../inputs/input/lu157 > ../outputs/output.${1}/t2023
echo ">>>>>>>>running test 2024"
../source/schedule.exe 6  3  6   < ../inputs/input/lu158 > ../outputs/output.${1}/t2024
echo ">>>>>>>>running test 2025"
../source/schedule.exe 5  4  9   < ../inputs/input/lu159 > ../outputs/output.${1}/t2025
echo ">>>>>>>>running test 2026"
../source/schedule.exe 2  3  2   < ../inputs/input/lu160 > ../outputs/output.${1}/t2026
echo ">>>>>>>>running test 2027"
../source/schedule.exe 7  6  7   < ../inputs/input/lu161 > ../outputs/output.${1}/t2027
echo ">>>>>>>>running test 2028"
../source/schedule.exe 4  3  4   < ../inputs/input/lu162 > ../outputs/output.${1}/t2028
echo ">>>>>>>>running test 2029"
../source/schedule.exe 5  10  9   < ../inputs/input/lu163 > ../outputs/output.${1}/t2029
echo ">>>>>>>>running test 2030"
../source/schedule.exe 10  5  6   < ../inputs/input/lu164 > ../outputs/output.${1}/t2030
echo ">>>>>>>>running test 2031"
../source/schedule.exe 1  6  9   < ../inputs/input/lu165 > ../outputs/output.${1}/t2031
echo ">>>>>>>>running test 2032"
../source/schedule.exe 4  5  8   < ../inputs/input/lu166 > ../outputs/output.${1}/t2032
echo ">>>>>>>>running test 2033"
../source/schedule.exe 5  8  1   < ../inputs/input/lu167 > ../outputs/output.${1}/t2033
echo ">>>>>>>>running test 2034"
../source/schedule.exe 8  7  4   < ../inputs/input/lu168 > ../outputs/output.${1}/t2034
echo ">>>>>>>>running test 2035"
../source/schedule.exe 7  6  3   < ../inputs/input/lu169 > ../outputs/output.${1}/t2035
echo ">>>>>>>>running test 2036"
../source/schedule.exe 8  7  10   < ../inputs/input/lu170 > ../outputs/output.${1}/t2036
echo ">>>>>>>>running test 2037"
../source/schedule.exe 7  2  3   < ../inputs/input/lu171 > ../outputs/output.${1}/t2037
echo ">>>>>>>>running test 2038"
../source/schedule.exe 2  7  8   < ../inputs/input/lu172 > ../outputs/output.${1}/t2038
echo ">>>>>>>>running test 2039"
../source/schedule.exe 5  2  7   < ../inputs/input/lu173 > ../outputs/output.${1}/t2039
echo ">>>>>>>>running test 2040"
../source/schedule.exe 8  1  2   < ../inputs/input/lu174 > ../outputs/output.${1}/t2040
echo ">>>>>>>>running test 2041"
../source/schedule.exe 3  2  1   < ../inputs/input/lu175 > ../outputs/output.${1}/t2041
echo ">>>>>>>>running test 2042"
../source/schedule.exe 6  3  6   < ../inputs/input/lu176 > ../outputs/output.${1}/t2042
echo ">>>>>>>>running test 2043"
../source/schedule.exe 9  6  1   < ../inputs/input/lu177 > ../outputs/output.${1}/t2043
echo ">>>>>>>>running test 2044"
../source/schedule.exe 10  3  4   < ../inputs/input/lu178 > ../outputs/output.${1}/t2044
echo ">>>>>>>>running test 2045"
../source/schedule.exe 1  2  5   < ../inputs/input/lu179 > ../outputs/output.${1}/t2045
echo ">>>>>>>>running test 2046"
../source/schedule.exe 8  9  6   < ../inputs/input/lu180 > ../outputs/output.${1}/t2046
echo ">>>>>>>>running test 2047"
../source/schedule.exe 1  8  1   < ../inputs/input/lu181 > ../outputs/output.${1}/t2047
echo ">>>>>>>>running test 2048"
../source/schedule.exe 2  5  8   < ../inputs/input/lu182 > ../outputs/output.${1}/t2048
echo ">>>>>>>>running test 2049"
../source/schedule.exe 3  10  9   < ../inputs/input/lu183 > ../outputs/output.${1}/t2049
echo ">>>>>>>>running test 2050"
../source/schedule.exe 6  1  10   < ../inputs/input/lu184 > ../outputs/output.${1}/t2050
echo ">>>>>>>>running test 2051"
../source/schedule.exe 1  4  7   < ../inputs/input/lu185 > ../outputs/output.${1}/t2051
echo ">>>>>>>>running test 2052"
../source/schedule.exe 8  7  6   < ../inputs/input/lu186 > ../outputs/output.${1}/t2052
echo ">>>>>>>>running test 2053"
../source/schedule.exe 1  8  5   < ../inputs/input/lu187 > ../outputs/output.${1}/t2053
echo ">>>>>>>>running test 2054"
../source/schedule.exe 10  3  8   < ../inputs/input/lu188 > ../outputs/output.${1}/t2054
echo ">>>>>>>>running test 2055"
../source/schedule.exe 7  2  3   < ../inputs/input/lu189 > ../outputs/output.${1}/t2055
echo ">>>>>>>>running test 2056"
../source/schedule.exe 10  3  2   < ../inputs/input/lu190 > ../outputs/output.${1}/t2056
echo ">>>>>>>>running test 2057"
../source/schedule.exe 5  10  5   < ../inputs/input/lu191 > ../outputs/output.${1}/t2057
echo ">>>>>>>>running test 2058"
../source/schedule.exe 6  3  4   < ../inputs/input/lu192 > ../outputs/output.${1}/t2058
echo ">>>>>>>>running test 2059"
../source/schedule.exe 1  10  1   < ../inputs/input/lu193 > ../outputs/output.${1}/t2059
echo ">>>>>>>>running test 2060"
../source/schedule.exe 4  5  10   < ../inputs/input/lu194 > ../outputs/output.${1}/t2060
echo ">>>>>>>>running test 2061"
../source/schedule.exe 3  2  9   < ../inputs/input/lu195 > ../outputs/output.${1}/t2061
echo ">>>>>>>>running test 2062"
../source/schedule.exe 8  5  8   < ../inputs/input/lu196 > ../outputs/output.${1}/t2062
echo ">>>>>>>>running test 2063"
../source/schedule.exe 7  6  7   < ../inputs/input/lu197 > ../outputs/output.${1}/t2063
echo ">>>>>>>>running test 2064"
../source/schedule.exe 10  3  10   < ../inputs/input/lu198 > ../outputs/output.${1}/t2064
echo ">>>>>>>>running test 2065"
../source/schedule.exe 9  4  9   < ../inputs/input/lu199 > ../outputs/output.${1}/t2065
echo ">>>>>>>>running test 2066"
../source/schedule.exe 8  1  4   < ../inputs/input/lu200 > ../outputs/output.${1}/t2066
echo ">>>>>>>>running test 2067"
../source/schedule.exe 3  2  9   < ../inputs/input/lu201 > ../outputs/output.${1}/t2067
echo ">>>>>>>>running test 2068"
../source/schedule.exe 2  9  8   < ../inputs/input/lu202 > ../outputs/output.${1}/t2068
echo ">>>>>>>>running test 2069"
../source/schedule.exe 1  8  7   < ../inputs/input/lu203 > ../outputs/output.${1}/t2069
echo ">>>>>>>>running test 2070"
../source/schedule.exe 6  1  4   < ../inputs/input/lu204 > ../outputs/output.${1}/t2070
echo ">>>>>>>>running test 2071"
../source/schedule.exe 3  10  5   < ../inputs/input/lu205 > ../outputs/output.${1}/t2071
echo ">>>>>>>>running test 2072"
../source/schedule.exe 2  3  8   < ../inputs/input/lu206 > ../outputs/output.${1}/t2072
echo ">>>>>>>>running test 2073"
../source/schedule.exe 5  2  3   < ../inputs/input/lu207 > ../outputs/output.${1}/t2073
echo ">>>>>>>>running test 2074"
../source/schedule.exe 4  5  2   < ../inputs/input/lu208 > ../outputs/output.${1}/t2074
echo ">>>>>>>>running test 2075"
../source/schedule.exe 5  6  1   < ../inputs/input/lu209 > ../outputs/output.${1}/t2075
echo ">>>>>>>>running test 2076"
../source/schedule.exe 2  5  6   < ../inputs/input/lu210 > ../outputs/output.${1}/t2076
echo ">>>>>>>>running test 2077"
../source/schedule.exe 1  6  3   < ../inputs/input/lu211 > ../outputs/output.${1}/t2077
echo ">>>>>>>>running test 2078"
../source/schedule.exe 2  7  4   < ../inputs/input/lu212 > ../outputs/output.${1}/t2078
echo ">>>>>>>>running test 2079"
../source/schedule.exe 5  8  7   < ../inputs/input/lu213 > ../outputs/output.${1}/t2079
echo ">>>>>>>>running test 2080"
../source/schedule.exe 10  5  2   < ../inputs/input/lu214 > ../outputs/output.${1}/t2080
echo ">>>>>>>>running test 2081"
../source/schedule.exe 1  4  9   < ../inputs/input/lu215 > ../outputs/output.${1}/t2081
echo ">>>>>>>>running test 2082"
../source/schedule.exe 8  1  6   < ../inputs/input/lu216 > ../outputs/output.${1}/t2082
echo ">>>>>>>>running test 2083"
../source/schedule.exe 3  4  9   < ../inputs/input/lu217 > ../outputs/output.${1}/t2083
echo ">>>>>>>>running test 2084"
../source/schedule.exe 6  5  2   < ../inputs/input/lu218 > ../outputs/output.${1}/t2084
echo ">>>>>>>>running test 2085"
../source/schedule.exe 7  6  3   < ../inputs/input/lu219 > ../outputs/output.${1}/t2085
echo ">>>>>>>>running test 2086"
../source/schedule.exe 4  7  8   < ../inputs/input/lu220 > ../outputs/output.${1}/t2086
echo ">>>>>>>>running test 2087"
../source/schedule.exe 3  8  1   < ../inputs/input/lu221 > ../outputs/output.${1}/t2087
echo ">>>>>>>>running test 2088"
../source/schedule.exe 10  1  4   < ../inputs/input/lu222 > ../outputs/output.${1}/t2088
echo ">>>>>>>>running test 2089"
../source/schedule.exe 1  10  7   < ../inputs/input/lu223 > ../outputs/output.${1}/t2089
echo ">>>>>>>>running test 2090"
../source/schedule.exe 4  7  10   < ../inputs/input/lu224 > ../outputs/output.${1}/t2090
echo ">>>>>>>>running test 2091"
../source/schedule.exe 5  4  3   < ../inputs/input/lu225 > ../outputs/output.${1}/t2091
echo ">>>>>>>>running test 2092"
../source/schedule.exe 10  5  4   < ../inputs/input/lu226 > ../outputs/output.${1}/t2092
echo ">>>>>>>>running test 2093"
../source/schedule.exe 1  4  9   < ../inputs/input/lu227 > ../outputs/output.${1}/t2093
echo ">>>>>>>>running test 2094"
../source/schedule.exe 2  5  4   < ../inputs/input/lu228 > ../outputs/output.${1}/t2094
echo ">>>>>>>>running test 2095"
../source/schedule.exe 7  10  9   < ../inputs/input/lu229 > ../outputs/output.${1}/t2095
echo ">>>>>>>>running test 2096"
../source/schedule.exe 2  7  2   < ../inputs/input/lu230 > ../outputs/output.${1}/t2096
echo ">>>>>>>>running test 2097"
../source/schedule.exe 3  8  9   < ../inputs/input/lu231 > ../outputs/output.${1}/t2097
echo ">>>>>>>>running test 2098"
../source/schedule.exe 4  9  2   < ../inputs/input/lu232 > ../outputs/output.${1}/t2098
echo ">>>>>>>>running test 2099"
../source/schedule.exe 9  8  7   < ../inputs/input/lu233 > ../outputs/output.${1}/t2099
echo ">>>>>>>>running test 2100"
../source/schedule.exe 6  9  4   < ../inputs/input/lu234 > ../outputs/output.${1}/t2100
echo ">>>>>>>>running test 2101"
../source/schedule.exe 9  4  3   < ../inputs/input/lu235 > ../outputs/output.${1}/t2101
echo ">>>>>>>>running test 2102"
../source/schedule.exe 2  7  6   < ../inputs/input/lu236 > ../outputs/output.${1}/t2102
echo ">>>>>>>>running test 2103"
../source/schedule.exe 1  8  9   < ../inputs/input/lu237 > ../outputs/output.${1}/t2103
echo ">>>>>>>>running test 2104"
../source/schedule.exe 8  1  6   < ../inputs/input/lu238 > ../outputs/output.${1}/t2104
echo ">>>>>>>>running test 2105"
../source/schedule.exe 7  10  9   < ../inputs/input/lu239 > ../outputs/output.${1}/t2105
echo ">>>>>>>>running test 2106"
../source/schedule.exe 4  3  2   < ../inputs/input/lu240 > ../outputs/output.${1}/t2106
echo ">>>>>>>>running test 2107"
../source/schedule.exe 9  4  5   < ../inputs/input/lu241 > ../outputs/output.${1}/t2107
echo ">>>>>>>>running test 2108"
../source/schedule.exe 6  1  10   < ../inputs/input/lu242 > ../outputs/output.${1}/t2108
echo ">>>>>>>>running test 2109"
../source/schedule.exe 1  10  1   < ../inputs/input/lu243 > ../outputs/output.${1}/t2109
echo ">>>>>>>>running test 2110"
../source/schedule.exe 6  3  10   < ../inputs/input/lu244 > ../outputs/output.${1}/t2110
echo ">>>>>>>>running test 2111"
../source/schedule.exe 1  4  3   < ../inputs/input/lu245 > ../outputs/output.${1}/t2111
echo ">>>>>>>>running test 2112"
../source/schedule.exe 8  3  10   < ../inputs/input/lu246 > ../outputs/output.${1}/t2112
echo ">>>>>>>>running test 2113"
../source/schedule.exe 9  2  5   < ../inputs/input/lu247 > ../outputs/output.${1}/t2113
echo ">>>>>>>>running test 2114"
../source/schedule.exe 8  5  6   < ../inputs/input/lu248 > ../outputs/output.${1}/t2114
echo ">>>>>>>>running test 2115"
../source/schedule.exe 3  4  3   < ../inputs/input/lu249 > ../outputs/output.${1}/t2115
echo ">>>>>>>>running test 2116"
../source/schedule.exe 10  7  2   < ../inputs/input/lu250 > ../outputs/output.${1}/t2116
echo ">>>>>>>>running test 2117"
../source/schedule.exe 1  2  3   < ../inputs/input/lu251 > ../outputs/output.${1}/t2117
echo ">>>>>>>>running test 2118"
../source/schedule.exe 2  5  4   < ../inputs/input/lu252 > ../outputs/output.${1}/t2118
echo ">>>>>>>>running test 2119"
../source/schedule.exe 7  4  5   < ../inputs/input/lu253 > ../outputs/output.${1}/t2119
echo ">>>>>>>>running test 2120"
../source/schedule.exe 4  3  2   < ../inputs/input/lu254 > ../outputs/output.${1}/t2120
echo ">>>>>>>>running test 2121"
../source/schedule.exe 5  4  9   < ../inputs/input/lu255 > ../outputs/output.${1}/t2121
echo ">>>>>>>>running test 2122"
../source/schedule.exe 2  5  10   < ../inputs/input/lu256 > ../outputs/output.${1}/t2122
echo ">>>>>>>>running test 2123"
../source/schedule.exe 7  6  1   < ../inputs/input/lu257 > ../outputs/output.${1}/t2123
echo ">>>>>>>>running test 2124"
../source/schedule.exe 6  9  6   < ../inputs/input/lu258 > ../outputs/output.${1}/t2124
echo ">>>>>>>>running test 2125"
../source/schedule.exe 3  2  5   < ../inputs/input/lu259 > ../outputs/output.${1}/t2125
echo ">>>>>>>>running test 2126"
../source/schedule.exe 8  3  4   < ../inputs/input/lu260 > ../outputs/output.${1}/t2126
echo ">>>>>>>>running test 2127"
../source/schedule.exe 5  6  7   < ../inputs/input/lu261 > ../outputs/output.${1}/t2127
echo ">>>>>>>>running test 2128"
../source/schedule.exe 6  1  10   < ../inputs/input/lu262 > ../outputs/output.${1}/t2128
echo ">>>>>>>>running test 2129"
../source/schedule.exe 9  8  5   < ../inputs/input/lu263 > ../outputs/output.${1}/t2129
echo ">>>>>>>>running test 2130"
../source/schedule.exe 4  3  4   < ../inputs/input/lu264 > ../outputs/output.${1}/t2130
echo ">>>>>>>>running test 2131"
../source/schedule.exe 1  4  3   < ../inputs/input/lu265 > ../outputs/output.${1}/t2131
echo ">>>>>>>>running test 2132"
../source/schedule.exe 8  1  10   < ../inputs/input/lu266 > ../outputs/output.${1}/t2132
echo ">>>>>>>>running test 2133"
../source/schedule.exe 1  6  5   < ../inputs/input/lu267 > ../outputs/output.${1}/t2133
echo ">>>>>>>>running test 2134"
../source/schedule.exe 8  1  6   < ../inputs/input/lu268 > ../outputs/output.${1}/t2134
echo ">>>>>>>>running test 2135"
../source/schedule.exe 9  4  9   < ../inputs/input/lu269 > ../outputs/output.${1}/t2135
echo ">>>>>>>>running test 2136"
../source/schedule.exe 8  9  4   < ../inputs/input/lu270 > ../outputs/output.${1}/t2136
echo ">>>>>>>>running test 2137"
../source/schedule.exe 5  8  3   < ../inputs/input/lu271 > ../outputs/output.${1}/t2137
echo ">>>>>>>>running test 2138"
../source/schedule.exe 2  1  8   < ../inputs/input/lu272 > ../outputs/output.${1}/t2138
echo ">>>>>>>>running test 2139"
../source/schedule.exe 7  6  3   < ../inputs/input/lu273 > ../outputs/output.${1}/t2139
echo ">>>>>>>>running test 2140"
../source/schedule.exe 10  7  10   < ../inputs/input/lu274 > ../outputs/output.${1}/t2140
echo ">>>>>>>>running test 2141"
../source/schedule.exe 5  10  9   < ../inputs/input/lu275 > ../outputs/output.${1}/t2141
echo ">>>>>>>>running test 2142"
../source/schedule.exe 6  1  2   < ../inputs/input/lu276 > ../outputs/output.${1}/t2142
echo ">>>>>>>>running test 2143"
../source/schedule.exe 7  2  3   < ../inputs/input/lu277 > ../outputs/output.${1}/t2143
echo ">>>>>>>>running test 2144"
../source/schedule.exe 4  9  4   < ../inputs/input/lu278 > ../outputs/output.${1}/t2144
echo ">>>>>>>>running test 2145"
../source/schedule.exe 5  2  7   < ../inputs/input/lu279 > ../outputs/output.${1}/t2145
echo ">>>>>>>>running test 2146"
../source/schedule.exe 8  7  8   < ../inputs/input/lu280 > ../outputs/output.${1}/t2146
echo ">>>>>>>>running test 2147"
../source/schedule.exe 7  10  1   < ../inputs/input/lu281 > ../outputs/output.${1}/t2147
echo ">>>>>>>>running test 2148"
../source/schedule.exe 2  9  8   < ../inputs/input/lu282 > ../outputs/output.${1}/t2148
echo ">>>>>>>>running test 2149"
../source/schedule.exe 7  8  5   < ../inputs/input/lu283 > ../outputs/output.${1}/t2149
echo ">>>>>>>>running test 2150"
../source/schedule.exe 8  9  8   < ../inputs/input/lu284 > ../outputs/output.${1}/t2150
echo ">>>>>>>>running test 2151"
../source/schedule.exe 3  6  5   < ../inputs/input/lu285 > ../outputs/output.${1}/t2151
echo ">>>>>>>>running test 2152"
../source/schedule.exe 2  5  4   < ../inputs/input/lu286 > ../outputs/output.${1}/t2152
echo ">>>>>>>>running test 2153"
../source/schedule.exe 7  6  5   < ../inputs/input/lu287 > ../outputs/output.${1}/t2153
echo ">>>>>>>>running test 2154"
../source/schedule.exe 4  1  4   < ../inputs/input/lu288 > ../outputs/output.${1}/t2154
echo ">>>>>>>>running test 2155"
../source/schedule.exe 3  8  1   < ../inputs/input/lu289 > ../outputs/output.${1}/t2155
echo ">>>>>>>>running test 2156"
../source/schedule.exe 8  5  4   < ../inputs/input/lu290 > ../outputs/output.${1}/t2156
echo ">>>>>>>>running test 2157"
../source/schedule.exe 7  4  7   < ../inputs/input/lu291 > ../outputs/output.${1}/t2157
echo ">>>>>>>>running test 2158"
../source/schedule.exe 8  7  6   < ../inputs/input/lu292 > ../outputs/output.${1}/t2158
echo ">>>>>>>>running test 2159"
../source/schedule.exe 9  6  5   < ../inputs/input/lu293 > ../outputs/output.${1}/t2159
echo ">>>>>>>>running test 2160"
../source/schedule.exe 8  9  4   < ../inputs/input/lu294 > ../outputs/output.${1}/t2160
echo ">>>>>>>>running test 2161"
../source/schedule.exe 1  6  7   < ../inputs/input/lu295 > ../outputs/output.${1}/t2161
echo ">>>>>>>>running test 2162"
../source/schedule.exe 2  9  6   < ../inputs/input/lu296 > ../outputs/output.${1}/t2162
echo ">>>>>>>>running test 2163"
../source/schedule.exe 5  4  7   < ../inputs/input/lu297 > ../outputs/output.${1}/t2163
echo ">>>>>>>>running test 2164"
../source/schedule.exe 6  3  10   < ../inputs/input/lu298 > ../outputs/output.${1}/t2164
echo ">>>>>>>>running test 2165"
../source/schedule.exe 7  8  9   < ../inputs/input/lu299 > ../outputs/output.${1}/t2165
echo ">>>>>>>>running test 2166"
../source/schedule.exe 4  5  2   < ../inputs/input/lu300 > ../outputs/output.${1}/t2166
echo ">>>>>>>>running test 2167"
../source/schedule.exe 3  10  1   < ../inputs/input/lu301 > ../outputs/output.${1}/t2167
echo ">>>>>>>>running test 2168"
../source/schedule.exe 8  5  4   < ../inputs/input/lu302 > ../outputs/output.${1}/t2168
echo ">>>>>>>>running test 2169"
../source/schedule.exe 3  2  5   < ../inputs/input/lu303 > ../outputs/output.${1}/t2169
echo ">>>>>>>>running test 2170"
../source/schedule.exe 4  7  10   < ../inputs/input/lu304 > ../outputs/output.${1}/t2170
echo ">>>>>>>>running test 2171"
../source/schedule.exe 7  8  3   < ../inputs/input/lu305 > ../outputs/output.${1}/t2171
echo ">>>>>>>>running test 2172"
../source/schedule.exe 4  7  10   < ../inputs/input/lu306 > ../outputs/output.${1}/t2172
echo ">>>>>>>>running test 2173"
../source/schedule.exe 9  4  5   < ../inputs/input/lu307 > ../outputs/output.${1}/t2173
echo ">>>>>>>>running test 2174"
../source/schedule.exe 10  5  8   < ../inputs/input/lu308 > ../outputs/output.${1}/t2174
echo ">>>>>>>>running test 2175"
../source/schedule.exe 3  6  3   < ../inputs/input/lu309 > ../outputs/output.${1}/t2175
echo ">>>>>>>>running test 2176"
../source/schedule.exe 6  3  4   < ../inputs/input/lu310 > ../outputs/output.${1}/t2176
echo ">>>>>>>>running test 2177"
../source/schedule.exe 1  10  3   < ../inputs/input/lu311 > ../outputs/output.${1}/t2177
echo ">>>>>>>>running test 2178"
../source/schedule.exe 4  3  8   < ../inputs/input/lu312 > ../outputs/output.${1}/t2178
echo ">>>>>>>>running test 2179"
../source/schedule.exe 3  8  7   < ../inputs/input/lu313 > ../outputs/output.${1}/t2179
echo ">>>>>>>>running test 2180"
../source/schedule.exe 10  7  8   < ../inputs/input/lu314 > ../outputs/output.${1}/t2180
echo ">>>>>>>>running test 2181"
../source/schedule.exe 3  4  5   < ../inputs/input/lu315 > ../outputs/output.${1}/t2181
echo ">>>>>>>>running test 2182"
../source/schedule.exe 4  5  8   < ../inputs/input/lu316 > ../outputs/output.${1}/t2182
echo ">>>>>>>>running test 2183"
../source/schedule.exe 1  2  3   < ../inputs/input/lu317 > ../outputs/output.${1}/t2183
echo ">>>>>>>>running test 2184"
../source/schedule.exe 10  7  8   < ../inputs/input/lu318 > ../outputs/output.${1}/t2184
echo ">>>>>>>>running test 2185"
../source/schedule.exe 7  4  9   < ../inputs/input/lu319 > ../outputs/output.${1}/t2185
echo ">>>>>>>>running test 2186"
../source/schedule.exe 4  7  10   < ../inputs/input/lu320 > ../outputs/output.${1}/t2186
echo ">>>>>>>>running test 2187"
../source/schedule.exe 9  6  5   < ../inputs/input/lu321 > ../outputs/output.${1}/t2187
echo ">>>>>>>>running test 2188"
../source/schedule.exe 6  1  4   < ../inputs/input/lu322 > ../outputs/output.${1}/t2188
echo ">>>>>>>>running test 2189"
../source/schedule.exe 9  10  3   < ../inputs/input/lu323 > ../outputs/output.${1}/t2189
echo ">>>>>>>>running test 2190"
../source/schedule.exe 8  5  4   < ../inputs/input/lu324 > ../outputs/output.${1}/t2190
echo ">>>>>>>>running test 2191"
../source/schedule.exe 9  4  3   < ../inputs/input/lu325 > ../outputs/output.${1}/t2191
echo ">>>>>>>>running test 2192"
../source/schedule.exe 8  3  4   < ../inputs/input/lu326 > ../outputs/output.${1}/t2192
echo ">>>>>>>>running test 2193"
../source/schedule.exe 5  10  1   < ../inputs/input/lu327 > ../outputs/output.${1}/t2193
echo ">>>>>>>>running test 2194"
../source/schedule.exe 8  3  10   < ../inputs/input/lu328 > ../outputs/output.${1}/t2194
echo ">>>>>>>>running test 2195"
../source/schedule.exe 7  6  1   < ../inputs/input/lu329 > ../outputs/output.${1}/t2195
echo ">>>>>>>>running test 2196"
../source/schedule.exe 6  5  4   < ../inputs/input/lu330 > ../outputs/output.${1}/t2196
echo ">>>>>>>>running test 2197"
../source/schedule.exe 5  2  9   < ../inputs/input/lu331 > ../outputs/output.${1}/t2197
echo ">>>>>>>>running test 2198"
../source/schedule.exe 4  5  2   < ../inputs/input/lu332 > ../outputs/output.${1}/t2198
echo ">>>>>>>>running test 2199"
../source/schedule.exe 3  4  3   < ../inputs/input/lu333 > ../outputs/output.${1}/t2199
echo ">>>>>>>>running test 2200"
../source/schedule.exe 6  9  8   < ../inputs/input/lu334 > ../outputs/output.${1}/t2200
echo ">>>>>>>>running test 2201"
../source/schedule.exe 7  6  1   < ../inputs/input/lu335 > ../outputs/output.${1}/t2201
echo ">>>>>>>>running test 2202"
../source/schedule.exe 4  1  2   < ../inputs/input/lu336 > ../outputs/output.${1}/t2202
echo ">>>>>>>>running test 2203"
../source/schedule.exe 5  10  1   < ../inputs/input/lu337 > ../outputs/output.${1}/t2203
echo ">>>>>>>>running test 2204"
../source/schedule.exe 10  9  2   < ../inputs/input/lu338 > ../outputs/output.${1}/t2204
echo ">>>>>>>>running test 2205"
../source/schedule.exe 5  2  1   < ../inputs/input/lu339 > ../outputs/output.${1}/t2205
echo ">>>>>>>>running test 2206"
../source/schedule.exe 8  7  8   < ../inputs/input/lu340 > ../outputs/output.${1}/t2206
echo ">>>>>>>>running test 2207"
../source/schedule.exe 7  6  9   < ../inputs/input/lu341 > ../outputs/output.${1}/t2207
echo ">>>>>>>>running test 2208"
../source/schedule.exe 10  1  10   < ../inputs/input/lu342 > ../outputs/output.${1}/t2208
echo ">>>>>>>>running test 2209"
../source/schedule.exe 9  6  7   < ../inputs/input/lu343 > ../outputs/output.${1}/t2209
echo ">>>>>>>>running test 2210"
../source/schedule.exe 6  7  10   < ../inputs/input/lu344 > ../outputs/output.${1}/t2210
echo ">>>>>>>>running test 2211"
../source/schedule.exe 7  10  9   < ../inputs/input/lu345 > ../outputs/output.${1}/t2211
echo ">>>>>>>>running test 2212"
../source/schedule.exe 6  7  10   < ../inputs/input/lu346 > ../outputs/output.${1}/t2212
echo ">>>>>>>>running test 2213"
../source/schedule.exe 3  4  5   < ../inputs/input/lu347 > ../outputs/output.${1}/t2213
echo ">>>>>>>>running test 2214"
../source/schedule.exe 10  9  6   < ../inputs/input/lu348 > ../outputs/output.${1}/t2214
echo ">>>>>>>>running test 2215"
../source/schedule.exe 3  6  9   < ../inputs/input/lu349 > ../outputs/output.${1}/t2215
echo ">>>>>>>>running test 2216"
../source/schedule.exe 10  5  8   < ../inputs/input/lu350 > ../outputs/output.${1}/t2216
echo ">>>>>>>>running test 2217"
../source/schedule.exe 5  8  9   < ../inputs/input/lu351 > ../outputs/output.${1}/t2217
echo ">>>>>>>>running test 2218"
../source/schedule.exe 2  7  4   < ../inputs/input/lu352 > ../outputs/output.${1}/t2218
echo ">>>>>>>>running test 2219"
../source/schedule.exe 3  4  9   < ../inputs/input/lu353 > ../outputs/output.${1}/t2219
echo ">>>>>>>>running test 2220"
../source/schedule.exe 6  9  8   < ../inputs/input/lu354 > ../outputs/output.${1}/t2220
echo ">>>>>>>>running test 2221"
../source/schedule.exe 7  8  9   < ../inputs/input/lu355 > ../outputs/output.${1}/t2221
echo ">>>>>>>>running test 2222"
../source/schedule.exe 10  7  4   < ../inputs/input/lu356 > ../outputs/output.${1}/t2222
echo ">>>>>>>>running test 2223"
../source/schedule.exe 1  4  9   < ../inputs/input/lu357 > ../outputs/output.${1}/t2223
echo ">>>>>>>>running test 2224"
../source/schedule.exe 10  9  10   < ../inputs/input/lu358 > ../outputs/output.${1}/t2224
echo ">>>>>>>>running test 2225"
../source/schedule.exe 5  4  7   < ../inputs/input/lu359 > ../outputs/output.${1}/t2225
echo ">>>>>>>>running test 2226"
../source/schedule.exe 2  3  4   < ../inputs/input/lu360 > ../outputs/output.${1}/t2226
echo ">>>>>>>>running test 2227"
../source/schedule.exe 7  8  3   < ../inputs/input/lu361 > ../outputs/output.${1}/t2227
echo ">>>>>>>>running test 2228"
../source/schedule.exe 8  9  10   < ../inputs/input/lu362 > ../outputs/output.${1}/t2228
echo ">>>>>>>>running test 2229"
../source/schedule.exe 1  6  5   < ../inputs/input/lu363 > ../outputs/output.${1}/t2229
echo ">>>>>>>>running test 2230"
../source/schedule.exe 4  3  6   < ../inputs/input/lu364 > ../outputs/output.${1}/t2230
echo ">>>>>>>>running test 2231"
../source/schedule.exe 7  2  5   < ../inputs/input/lu365 > ../outputs/output.${1}/t2231
echo ">>>>>>>>running test 2232"
../source/schedule.exe 4  3  2   < ../inputs/input/lu366 > ../outputs/output.${1}/t2232
echo ">>>>>>>>running test 2233"
../source/schedule.exe 9  10  3   < ../inputs/input/lu367 > ../outputs/output.${1}/t2233
echo ">>>>>>>>running test 2234"
../source/schedule.exe 4  1  8   < ../inputs/input/lu368 > ../outputs/output.${1}/t2234
echo ">>>>>>>>running test 2235"
../source/schedule.exe 1  8  7   < ../inputs/input/lu369 > ../outputs/output.${1}/t2235
echo ">>>>>>>>running test 2236"
../source/schedule.exe 6  3  8   < ../inputs/input/lu370 > ../outputs/output.${1}/t2236
echo ">>>>>>>>running test 2237"
../source/schedule.exe 5  4  3   < ../inputs/input/lu371 > ../outputs/output.${1}/t2237
echo ">>>>>>>>running test 2238"
../source/schedule.exe 10  1  8   < ../inputs/input/lu372 > ../outputs/output.${1}/t2238
echo ">>>>>>>>running test 2239"
../source/schedule.exe 3  8  7   < ../inputs/input/lu373 > ../outputs/output.${1}/t2239
echo ">>>>>>>>running test 2240"
../source/schedule.exe 6  9  10   < ../inputs/input/lu374 > ../outputs/output.${1}/t2240
echo ">>>>>>>>running test 2241"
../source/schedule.exe 9  8  3   < ../inputs/input/lu375 > ../outputs/output.${1}/t2241
echo ">>>>>>>>running test 2242"
../source/schedule.exe 6  3  10   < ../inputs/input/lu376 > ../outputs/output.${1}/t2242
echo ">>>>>>>>running test 2243"
../source/schedule.exe 3  10  9   < ../inputs/input/lu377 > ../outputs/output.${1}/t2243
echo ">>>>>>>>running test 2244"
../source/schedule.exe 10  3  8   < ../inputs/input/lu378 > ../outputs/output.${1}/t2244
echo ">>>>>>>>running test 2245"
../source/schedule.exe 5  2  7   < ../inputs/input/lu379 > ../outputs/output.${1}/t2245
echo ">>>>>>>>running test 2246"
../source/schedule.exe 6  1  6   < ../inputs/input/lu380 > ../outputs/output.${1}/t2246
echo ">>>>>>>>running test 2247"
../source/schedule.exe 3  2  3   < ../inputs/input/lu381 > ../outputs/output.${1}/t2247
echo ">>>>>>>>running test 2248"
../source/schedule.exe 8  9  8   < ../inputs/input/lu382 > ../outputs/output.${1}/t2248
echo ">>>>>>>>running test 2249"
../source/schedule.exe 7  6  5   < ../inputs/input/lu383 > ../outputs/output.${1}/t2249
echo ">>>>>>>>running test 2250"
../source/schedule.exe 6  7  8   < ../inputs/input/lu384 > ../outputs/output.${1}/t2250
echo ">>>>>>>>running test 2251"
../source/schedule.exe 3  8  9   < ../inputs/input/lu385 > ../outputs/output.${1}/t2251
echo ">>>>>>>>running test 2252"
../source/schedule.exe 10  9  8   < ../inputs/input/lu386 > ../outputs/output.${1}/t2252
echo ">>>>>>>>running test 2253"
../source/schedule.exe 5  8  7   < ../inputs/input/lu387 > ../outputs/output.${1}/t2253
echo ">>>>>>>>running test 2254"
../source/schedule.exe 2  7  2   < ../inputs/input/lu388 > ../outputs/output.${1}/t2254
echo ">>>>>>>>running test 2255"
../source/schedule.exe 3  10  1   < ../inputs/input/lu389 > ../outputs/output.${1}/t2255
echo ">>>>>>>>running test 2256"
../source/schedule.exe 10  3  8   < ../inputs/input/lu390 > ../outputs/output.${1}/t2256
echo ">>>>>>>>running test 2257"
../source/schedule.exe 1  8  1   < ../inputs/input/lu391 > ../outputs/output.${1}/t2257
echo ">>>>>>>>running test 2258"
../source/schedule.exe 4  5  10   < ../inputs/input/lu392 > ../outputs/output.${1}/t2258
echo ">>>>>>>>running test 2259"
../source/schedule.exe 7  6  9   < ../inputs/input/lu393 > ../outputs/output.${1}/t2259
echo ">>>>>>>>running test 2260"
../source/schedule.exe 10  7  6   < ../inputs/input/lu394 > ../outputs/output.${1}/t2260
echo ">>>>>>>>running test 2261"
../source/schedule.exe 7  6  1   < ../inputs/input/lu395 > ../outputs/output.${1}/t2261
echo ">>>>>>>>running test 2262"
../source/schedule.exe 10  5  2   < ../inputs/input/lu396 > ../outputs/output.${1}/t2262
echo ">>>>>>>>running test 2263"
../source/schedule.exe 1  2  1   < ../inputs/input/lu397 > ../outputs/output.${1}/t2263
echo ">>>>>>>>running test 2264"
../source/schedule.exe 2  9  10   < ../inputs/input/lu398 > ../outputs/output.${1}/t2264
echo ">>>>>>>>running test 2265"
../source/schedule.exe 3  8  7   < ../inputs/input/lu399 > ../outputs/output.${1}/t2265
echo ">>>>>>>>running test 2266"
../source/schedule.exe 6  9  4   < ../inputs/input/lu400 > ../outputs/output.${1}/t2266
echo ">>>>>>>>running test 2267"
../source/schedule.exe 3  6  7   < ../inputs/input/lu401 > ../outputs/output.${1}/t2267
echo ">>>>>>>>running test 2268"
../source/schedule.exe 10  3  6   < ../inputs/input/lu402 > ../outputs/output.${1}/t2268
echo ">>>>>>>>running test 2269"
../source/schedule.exe 5  10  5   < ../inputs/input/lu403 > ../outputs/output.${1}/t2269
echo ">>>>>>>>running test 2270"
../source/schedule.exe 6  7  10   < ../inputs/input/lu404 > ../outputs/output.${1}/t2270
echo ">>>>>>>>running test 2271"
../source/schedule.exe 7  10  9   < ../inputs/input/lu405 > ../outputs/output.${1}/t2271
echo ">>>>>>>>running test 2272"
../source/schedule.exe 4  5  10   < ../inputs/input/lu406 > ../outputs/output.${1}/t2272
echo ">>>>>>>>running test 2273"
../source/schedule.exe 1  6  7   < ../inputs/input/lu407 > ../outputs/output.${1}/t2273
echo ">>>>>>>>running test 2274"
../source/schedule.exe 6  7  10   < ../inputs/input/lu408 > ../outputs/output.${1}/t2274
echo ">>>>>>>>running test 2275"
../source/schedule.exe 1  8  9   < ../inputs/input/lu409 > ../outputs/output.${1}/t2275
echo ">>>>>>>>running test 2276"
../source/schedule.exe 8  3  8   < ../inputs/input/lu410 > ../outputs/output.${1}/t2276
echo ">>>>>>>>running test 2277"
../source/schedule.exe 3  6  9   < ../inputs/input/lu411 > ../outputs/output.${1}/t2277
echo ">>>>>>>>running test 2278"
../source/schedule.exe 8  9  6   < ../inputs/input/lu412 > ../outputs/output.${1}/t2278
echo ">>>>>>>>running test 2279"
../source/schedule.exe 9  2  5   < ../inputs/input/lu413 > ../outputs/output.${1}/t2279
echo ">>>>>>>>running test 2280"
../source/schedule.exe 10  9  2   < ../inputs/input/lu414 > ../outputs/output.${1}/t2280
echo ">>>>>>>>running test 2281"
../source/schedule.exe 5  8  1   < ../inputs/input/lu415 > ../outputs/output.${1}/t2281
echo ">>>>>>>>running test 2282"
../source/schedule.exe 4  5  10   < ../inputs/input/lu416 > ../outputs/output.${1}/t2282
echo ">>>>>>>>running test 2283"
../source/schedule.exe 5  10  1   < ../inputs/input/lu417 > ../outputs/output.${1}/t2283
echo ">>>>>>>>running test 2284"
../source/schedule.exe 6  3  8   < ../inputs/input/lu418 > ../outputs/output.${1}/t2284
echo ">>>>>>>>running test 2285"
../source/schedule.exe 9  4  5   < ../inputs/input/lu419 > ../outputs/output.${1}/t2285
echo ">>>>>>>>running test 2286"
../source/schedule.exe 4  5  10   < ../inputs/input/lu420 > ../outputs/output.${1}/t2286
echo ">>>>>>>>running test 2287"
../source/schedule.exe 7  6  5   < ../inputs/input/lu421 > ../outputs/output.${1}/t2287
echo ">>>>>>>>running test 2288"
../source/schedule.exe 10  7  2   < ../inputs/input/lu422 > ../outputs/output.${1}/t2288
echo ">>>>>>>>running test 2289"
../source/schedule.exe 5  6  7   < ../inputs/input/lu423 > ../outputs/output.${1}/t2289
echo ">>>>>>>>running test 2290"
../source/schedule.exe 6  5  8   < ../inputs/input/lu424 > ../outputs/output.${1}/t2290
echo ">>>>>>>>running test 2291"
../source/schedule.exe 1  6  5   < ../inputs/input/lu425 > ../outputs/output.${1}/t2291
echo ">>>>>>>>running test 2292"
../source/schedule.exe 6  9  4   < ../inputs/input/lu426 > ../outputs/output.${1}/t2292
echo ">>>>>>>>running test 2293"
../source/schedule.exe 9  6  5   < ../inputs/input/lu427 > ../outputs/output.${1}/t2293
echo ">>>>>>>>running test 2294"
../source/schedule.exe 10  5  4   < ../inputs/input/lu428 > ../outputs/output.${1}/t2294
echo ">>>>>>>>running test 2295"
../source/schedule.exe 7  6  3   < ../inputs/input/lu429 > ../outputs/output.${1}/t2295
echo ">>>>>>>>running test 2296"
../source/schedule.exe 2  5  10   < ../inputs/input/lu430 > ../outputs/output.${1}/t2296
echo ">>>>>>>>running test 2297"
../source/schedule.exe 7  10  7   < ../inputs/input/lu431 > ../outputs/output.${1}/t2297
echo ">>>>>>>>running test 2298"
../source/schedule.exe 10  1  2   < ../inputs/input/lu432 > ../outputs/output.${1}/t2298
echo ">>>>>>>>running test 2299"
../source/schedule.exe 1  8  7   < ../inputs/input/lu433 > ../outputs/output.${1}/t2299
echo ">>>>>>>>running test 2300"
../source/schedule.exe 10  1  4   < ../inputs/input/lu434 > ../outputs/output.${1}/t2300
echo ">>>>>>>>running test 2301"
../source/schedule.exe 7  4  5   < ../inputs/input/lu435 > ../outputs/output.${1}/t2301
echo ">>>>>>>>running test 2302"
../source/schedule.exe 4  9  4   < ../inputs/input/lu436 > ../outputs/output.${1}/t2302
echo ">>>>>>>>running test 2303"
../source/schedule.exe 3  2  3   < ../inputs/input/lu437 > ../outputs/output.${1}/t2303
echo ">>>>>>>>running test 2304"
../source/schedule.exe 4  1  6   < ../inputs/input/lu438 > ../outputs/output.${1}/t2304
echo ">>>>>>>>running test 2305"
../source/schedule.exe 7  2  7   < ../inputs/input/lu439 > ../outputs/output.${1}/t2305
echo ">>>>>>>>running test 2306"
../source/schedule.exe 10  7  4   < ../inputs/input/lu440 > ../outputs/output.${1}/t2306
echo ">>>>>>>>running test 2307"
../source/schedule.exe 9  4  9   < ../inputs/input/lu441 > ../outputs/output.${1}/t2307
echo ">>>>>>>>running test 2308"
../source/schedule.exe 10  7  8   < ../inputs/input/lu442 > ../outputs/output.${1}/t2308
echo ">>>>>>>>running test 2309"
../source/schedule.exe 5  8  5   < ../inputs/input/lu443 > ../outputs/output.${1}/t2309
echo ">>>>>>>>running test 2310"
../source/schedule.exe 6  3  4   < ../inputs/input/lu444 > ../outputs/output.${1}/t2310
echo ">>>>>>>>running test 2311"
../source/schedule.exe 7  8  3   < ../inputs/input/lu445 > ../outputs/output.${1}/t2311
echo ">>>>>>>>running test 2312"
../source/schedule.exe 6  5  8   < ../inputs/input/lu446 > ../outputs/output.${1}/t2312
echo ">>>>>>>>running test 2313"
../source/schedule.exe 7  8  9   < ../inputs/input/lu447 > ../outputs/output.${1}/t2313
echo ">>>>>>>>running test 2314"
../source/schedule.exe 4  7  10   < ../inputs/input/lu448 > ../outputs/output.${1}/t2314
echo ">>>>>>>>running test 2315"
../source/schedule.exe 1  6  5   < ../inputs/input/lu449 > ../outputs/output.${1}/t2315
echo ">>>>>>>>running test 2316"
../source/schedule.exe 10  5  6   < ../inputs/input/lu450 > ../outputs/output.${1}/t2316
echo ">>>>>>>>running test 2317"
../source/schedule.exe 3  6  3   < ../inputs/input/lu451 > ../outputs/output.${1}/t2317
echo ">>>>>>>>running test 2318"
../source/schedule.exe 2  5  4   < ../inputs/input/lu452 > ../outputs/output.${1}/t2318
echo ">>>>>>>>running test 2319"
../source/schedule.exe 1  6  9   < ../inputs/input/lu453 > ../outputs/output.${1}/t2319
echo ">>>>>>>>running test 2320"
../source/schedule.exe 10  7  2   < ../inputs/input/lu454 > ../outputs/output.${1}/t2320
echo ">>>>>>>>running test 2321"
../source/schedule.exe 3  2  3   < ../inputs/input/lu455 > ../outputs/output.${1}/t2321
echo ">>>>>>>>running test 2322"
../source/schedule.exe 6  1  2   < ../inputs/input/lu456 > ../outputs/output.${1}/t2322
echo ">>>>>>>>running test 2323"
../source/schedule.exe 7  2  5   < ../inputs/input/lu457 > ../outputs/output.${1}/t2323
echo ">>>>>>>>running test 2324"
../source/schedule.exe 4  1  4   < ../inputs/input/lu458 > ../outputs/output.${1}/t2324
echo ">>>>>>>>running test 2325"
../source/schedule.exe 5  6  5   < ../inputs/input/lu459 > ../outputs/output.${1}/t2325
echo ">>>>>>>>running test 2326"
../source/schedule.exe 6  3  10   < ../inputs/input/lu460 > ../outputs/output.${1}/t2326
echo ">>>>>>>>running test 2327"
../source/schedule.exe 3  6  3   < ../inputs/input/lu461 > ../outputs/output.${1}/t2327
echo ">>>>>>>>running test 2328"
../source/schedule.exe 8  9  6   < ../inputs/input/lu462 > ../outputs/output.${1}/t2328
echo ">>>>>>>>running test 2329"
../source/schedule.exe 9  6  9   < ../inputs/input/lu463 > ../outputs/output.${1}/t2329
echo ">>>>>>>>running test 2330"
../source/schedule.exe 10  7  2   < ../inputs/input/lu464 > ../outputs/output.${1}/t2330
echo ">>>>>>>>running test 2331"
../source/schedule.exe 3  6  3   < ../inputs/input/lu465 > ../outputs/output.${1}/t2331
echo ">>>>>>>>running test 2332"
../source/schedule.exe 4  7  10   < ../inputs/input/lu466 > ../outputs/output.${1}/t2332
echo ">>>>>>>>running test 2333"
../source/schedule.exe 3  8  3   < ../inputs/input/lu467 > ../outputs/output.${1}/t2333
echo ">>>>>>>>running test 2334"
../source/schedule.exe 10  9  4   < ../inputs/input/lu468 > ../outputs/output.${1}/t2334
echo ">>>>>>>>running test 2335"
../source/schedule.exe 1  8  9   < ../inputs/input/lu469 > ../outputs/output.${1}/t2335
echo ">>>>>>>>running test 2336"
../source/schedule.exe 10  7  8   < ../inputs/input/lu470 > ../outputs/output.${1}/t2336
echo ">>>>>>>>running test 2337"
../source/schedule.exe 3  10  7   < ../inputs/input/lu471 > ../outputs/output.${1}/t2337
echo ">>>>>>>>running test 2338"
../source/schedule.exe 8  3  2   < ../inputs/input/lu472 > ../outputs/output.${1}/t2338
echo ">>>>>>>>running test 2339"
../source/schedule.exe 1  2  7   < ../inputs/input/lu473 > ../outputs/output.${1}/t2339
echo ">>>>>>>>running test 2340"
../source/schedule.exe 4  9  4   < ../inputs/input/lu474 > ../outputs/output.${1}/t2340
echo ">>>>>>>>running test 2341"
../source/schedule.exe 3  6  9   < ../inputs/input/lu475 > ../outputs/output.${1}/t2341
echo ">>>>>>>>running test 2342"
../source/schedule.exe 10  5  4   < ../inputs/input/lu476 > ../outputs/output.${1}/t2342
echo ">>>>>>>>running test 2343"
../source/schedule.exe 9  8  7   < ../inputs/input/lu477 > ../outputs/output.${1}/t2343
echo ">>>>>>>>running test 2344"
../source/schedule.exe 2  3  6   < ../inputs/input/lu478 > ../outputs/output.${1}/t2344
echo ">>>>>>>>running test 2345"
../source/schedule.exe 3  8  7   < ../inputs/input/lu479 > ../outputs/output.${1}/t2345
echo ">>>>>>>>running test 2346"
../source/schedule.exe 8  7  4   < ../inputs/input/lu480 > ../outputs/output.${1}/t2346
echo ">>>>>>>>running test 2347"
../source/schedule.exe 9  4  3   < ../inputs/input/lu481 > ../outputs/output.${1}/t2347
echo ">>>>>>>>running test 2348"
../source/schedule.exe 8  5  10   < ../inputs/input/lu482 > ../outputs/output.${1}/t2348
echo ">>>>>>>>running test 2349"
../source/schedule.exe 5  8  3   < ../inputs/input/lu483 > ../outputs/output.${1}/t2349
echo ">>>>>>>>running test 2350"
../source/schedule.exe 2  7  4   < ../inputs/input/lu484 > ../outputs/output.${1}/t2350
echo ">>>>>>>>running test 2351"
../source/schedule.exe 5  6  7   < ../inputs/input/lu485 > ../outputs/output.${1}/t2351
echo ">>>>>>>>running test 2352"
../source/schedule.exe 6  3  2   < ../inputs/input/lu486 > ../outputs/output.${1}/t2352
echo ">>>>>>>>running test 2353"
../source/schedule.exe 5  2  7   < ../inputs/input/lu487 > ../outputs/output.${1}/t2353
echo ">>>>>>>>running test 2354"
../source/schedule.exe 10  5  4   < ../inputs/input/lu488 > ../outputs/output.${1}/t2354
echo ">>>>>>>>running test 2355"
../source/schedule.exe 3  4  3   < ../inputs/input/lu489 > ../outputs/output.${1}/t2355
echo ">>>>>>>>running test 2356"
../source/schedule.exe 10  5  4   < ../inputs/input/lu490 > ../outputs/output.${1}/t2356
echo ">>>>>>>>running test 2357"
../source/schedule.exe 3  10  1   < ../inputs/input/lu491 > ../outputs/output.${1}/t2357
echo ">>>>>>>>running test 2358"
../source/schedule.exe 6  5  4   < ../inputs/input/lu492 > ../outputs/output.${1}/t2358
echo ">>>>>>>>running test 2359"
../source/schedule.exe 9  2  9   < ../inputs/input/lu493 > ../outputs/output.${1}/t2359
echo ">>>>>>>>running test 2360"
../source/schedule.exe 2  5  4   < ../inputs/input/lu494 > ../outputs/output.${1}/t2360
echo ">>>>>>>>running test 2361"
../source/schedule.exe 7  4  9   < ../inputs/input/lu495 > ../outputs/output.${1}/t2361
echo ">>>>>>>>running test 2362"
../source/schedule.exe 8  1  8   < ../inputs/input/lu496 > ../outputs/output.${1}/t2362
echo ">>>>>>>>running test 2363"
../source/schedule.exe 5  10  3   < ../inputs/input/lu497 > ../outputs/output.${1}/t2363
echo ">>>>>>>>running test 2364"
../source/schedule.exe 6  3  6   < ../inputs/input/lu498 > ../outputs/output.${1}/t2364
echo ">>>>>>>>running test 2365"
../source/schedule.exe 5  6  5   < ../inputs/input/lu499 > ../outputs/output.${1}/t2365
echo ">>>>>>>>running test 2366"
../source/schedule.exe 8  7  10   < ../inputs/input/lu500 > ../outputs/output.${1}/t2366
echo ">>>>>>>>running test 2367"
../source/schedule.exe 7 1 9  < ../inputs/input/bdt.58 > ../outputs/output.${1}/t2367
echo ">>>>>>>>running test 2368"
../source/schedule.exe 1 4 2  < ../inputs/input/bdt.35 > ../outputs/output.${1}/t2368
echo ">>>>>>>>running test 2369"
../source/schedule.exe 4 8 8  < ../inputs/input/bdt.18 > ../outputs/output.${1}/t2369
echo ">>>>>>>>running test 2370"
../source/schedule.exe 7 2 10  < ../inputs/input/bdt.24 > ../outputs/output.${1}/t2370
echo ">>>>>>>>running test 2371"
../source/schedule.exe 6 8 3  < ../inputs/input/bdt.17 > ../outputs/output.${1}/t2371
echo ">>>>>>>>running test 2372"
../source/schedule.exe 7 10 5  < ../inputs/input/bdt.84 > ../outputs/output.${1}/t2372
echo ">>>>>>>>running test 2373"
../source/schedule.exe 6 8 3  < ../inputs/input/bdt.56 > ../outputs/output.${1}/t2373
echo ">>>>>>>>running test 2374"
../source/schedule.exe 8 8 0  < ../inputs/input/bdt.80 > ../outputs/output.${1}/t2374
echo ">>>>>>>>running test 2375"
../source/schedule.exe 8 1 4  < ../inputs/input/bdt.35 > ../outputs/output.${1}/t2375
echo ">>>>>>>>running test 2376"
../source/schedule.exe 9 3 4  < ../inputs/input/bdt.20 > ../outputs/output.${1}/t2376
echo ">>>>>>>>running test 2377"
../source/schedule.exe 8 8 5  < ../inputs/input/bdt.14 > ../outputs/output.${1}/t2377
echo ">>>>>>>>running test 2378"
../source/schedule.exe 4 9 7  < ../inputs/input/bdt.91 > ../outputs/output.${1}/t2378
echo ">>>>>>>>running test 2379"
../source/schedule.exe 1 8 3  < ../inputs/input/bdt.9 > ../outputs/output.${1}/t2379
echo ">>>>>>>>running test 2380"
../source/schedule.exe 10 10 7  < ../inputs/input/bdt.2 > ../outputs/output.${1}/t2380
echo ">>>>>>>>running test 2381"
../source/schedule.exe 5 2 8  < ../inputs/input/bdt.41 > ../outputs/output.${1}/t2381
echo ">>>>>>>>running test 2382"
../source/schedule.exe 8 3 4  < ../inputs/input/bdt.84 > ../outputs/output.${1}/t2382
echo ">>>>>>>>running test 2383"
../source/schedule.exe 10 10 6  < ../inputs/input/bdt.20 > ../outputs/output.${1}/t2383
echo ">>>>>>>>running test 2384"
../source/schedule.exe 10 7 9  < ../inputs/input/bdt.22 > ../outputs/output.${1}/t2384
echo ">>>>>>>>running test 2385"
../source/schedule.exe 2 8 7  < ../inputs/input/bdt.100 > ../outputs/output.${1}/t2385
echo ">>>>>>>>running test 2386"
../source/schedule.exe 10 3 4  < ../inputs/input/bdt.6 > ../outputs/output.${1}/t2386
echo ">>>>>>>>running test 2387"
../source/schedule.exe 2 5 3  < ../inputs/input/bdt.46 > ../outputs/output.${1}/t2387
echo ">>>>>>>>running test 2388"
../source/schedule.exe 8 6 0  < ../inputs/input/bdt.16 > ../outputs/output.${1}/t2388
echo ">>>>>>>>running test 2389"
../source/schedule.exe 2 7 7  < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2389
echo ">>>>>>>>running test 2390"
../source/schedule.exe 0 5 1  < ../inputs/input/bdt.1 > ../outputs/output.${1}/t2390
echo ">>>>>>>>running test 2391"
../source/schedule.exe 5 4 5  < ../inputs/input/bdt.20 > ../outputs/output.${1}/t2391
echo ">>>>>>>>running test 2392"
../source/schedule.exe 8 6 2  < ../inputs/input/bdt.35 > ../outputs/output.${1}/t2392
echo ">>>>>>>>running test 2393"
../source/schedule.exe 8 4 4  < ../inputs/input/bdt.63 > ../outputs/output.${1}/t2393
echo ">>>>>>>>running test 2394"
../source/schedule.exe 6 4 8  < ../inputs/input/bdt.82 > ../outputs/output.${1}/t2394
echo ">>>>>>>>running test 2395"
../source/schedule.exe 0 1 3  < ../inputs/input/bdt.80 > ../outputs/output.${1}/t2395
echo ">>>>>>>>running test 2396"
../source/schedule.exe 8 7 9  < ../inputs/input/bdt.47 > ../outputs/output.${1}/t2396
echo ">>>>>>>>running test 2397"
../source/schedule.exe 1 9 9  < ../inputs/input/bdt.27 > ../outputs/output.${1}/t2397
echo ">>>>>>>>running test 2398"
../source/schedule.exe 1 9 0  < ../inputs/input/bdt.39 > ../outputs/output.${1}/t2398
echo ">>>>>>>>running test 2399"
../source/schedule.exe 4 0 10  < ../inputs/input/bdt.83 > ../outputs/output.${1}/t2399
echo ">>>>>>>>running test 2400"
../source/schedule.exe 7 0 6  < ../inputs/input/bdt.38 > ../outputs/output.${1}/t2400
echo ">>>>>>>>running test 2401"
../source/schedule.exe 5 0 7  < ../inputs/input/bdt.30 > ../outputs/output.${1}/t2401
echo ">>>>>>>>running test 2402"
../source/schedule.exe 2 9 7  < ../inputs/input/bdt.74 > ../outputs/output.${1}/t2402
echo ">>>>>>>>running test 2403"
../source/schedule.exe 10 10 6  < ../inputs/input/bdt.42 > ../outputs/output.${1}/t2403
echo ">>>>>>>>running test 2404"
../source/schedule.exe 2 5 10  < ../inputs/input/bdt.25 > ../outputs/output.${1}/t2404
echo ">>>>>>>>running test 2405"
../source/schedule.exe 8 5 0  < ../inputs/input/bdt.31 > ../outputs/output.${1}/t2405
echo ">>>>>>>>running test 2406"
../source/schedule.exe 6 9 1  < ../inputs/input/bdt.37 > ../outputs/output.${1}/t2406
echo ">>>>>>>>running test 2407"
../source/schedule.exe 8 4 2  < ../inputs/input/bdt.29 > ../outputs/output.${1}/t2407
echo ">>>>>>>>running test 2408"
../source/schedule.exe 5 9 1  < ../inputs/input/bdt.91 > ../outputs/output.${1}/t2408
echo ">>>>>>>>running test 2409"
../source/schedule.exe 5 1 2  < ../inputs/input/bdt.95 > ../outputs/output.${1}/t2409
echo ">>>>>>>>running test 2410"
../source/schedule.exe 1 9 10  < ../inputs/input/bdt.79 > ../outputs/output.${1}/t2410
echo ">>>>>>>>running test 2411"
../source/schedule.exe 3 6 5  < ../inputs/input/bdt.83 > ../outputs/output.${1}/t2411
echo ">>>>>>>>running test 2412"
../source/schedule.exe 7 2 8  < ../inputs/input/bdt.86 > ../outputs/output.${1}/t2412
echo ">>>>>>>>running test 2413"
../source/schedule.exe 4 7 7  < ../inputs/input/bdt.83 > ../outputs/output.${1}/t2413
echo ">>>>>>>>running test 2414"
../source/schedule.exe 0 3 6  < ../inputs/input/bdt.36 > ../outputs/output.${1}/t2414
echo ">>>>>>>>running test 2415"
../source/schedule.exe 5 5 1  < ../inputs/input/bdt.49 > ../outputs/output.${1}/t2415
echo ">>>>>>>>running test 2416"
../source/schedule.exe 6 9 8  < ../inputs/input/bdt.64 > ../outputs/output.${1}/t2416
echo ">>>>>>>>running test 2417"
../source/schedule.exe 2 3 1  < ../inputs/input/nnt1 > ../outputs/output.${1}/t2417
echo ">>>>>>>>running test 2418"
../source/schedule.exe 2 3 1  < ../inputs/input/nnt2 > ../outputs/output.${1}/t2418
echo ">>>>>>>>running test 2419"
../source/schedule.exe 1 0 1  < ../inputs/input/nnt2 > ../outputs/output.${1}/t2419
echo ">>>>>>>>running test 2420"
../source/schedule.exe 1 0 2  < ../inputs/input/nnt3 > ../outputs/output.${1}/t2420
echo ">>>>>>>>running test 2421"
../source/schedule.exe 3 0 2  < ../inputs/input/nnt3 > ../outputs/output.${1}/t2421
echo ">>>>>>>>running test 2422"
../source/schedule.exe 3 2 2  < ../inputs/input/nnt4 > ../outputs/output.${1}/t2422
echo ">>>>>>>>running test 2423"
../source/schedule.exe 4 2 2  < ../inputs/input/nnt4 > ../outputs/output.${1}/t2423
echo ">>>>>>>>running test 2424"
../source/schedule.exe 4 0 2  < ../inputs/input/nnt5 > ../outputs/output.${1}/t2424
echo ">>>>>>>>running test 2425"
../source/schedule.exe 4 3 2  < ../inputs/input/nnt6 > ../outputs/output.${1}/t2425
echo ">>>>>>>>running test 2426"
../source/schedule.exe 4 3 2  < ../inputs/input/nnt7 > ../outputs/output.${1}/t2426
echo ">>>>>>>>running test 2427"
../source/schedule.exe 4 3 2  < ../inputs/input/nnt8 > ../outputs/output.${1}/t2427
echo ">>>>>>>>running test 2428"
../source/schedule.exe 2 3 2  < ../inputs/input/nnt8 > ../outputs/output.${1}/t2428
echo ">>>>>>>>running test 2429"
../source/schedule.exe 2 0 2  < ../inputs/input/nnt8 > ../outputs/output.${1}/t2429
echo ">>>>>>>>running test 2430"
../source/schedule.exe 2 0 2  < ../inputs/input/nnt9 > ../outputs/output.${1}/t2430
echo ">>>>>>>>running test 2431"
../source/schedule.exe 2 3 2  < ../inputs/input/nnt9 > ../outputs/output.${1}/t2431
echo ">>>>>>>>running test 2432"
../source/schedule.exe 2 3 1  < ../inputs/input/nnt9 > ../outputs/output.${1}/t2432
echo ">>>>>>>>running test 2433"
../source/schedule.exe 5 3 1  < ../inputs/input/nnt9 > ../outputs/output.${1}/t2433
echo ">>>>>>>>running test 2434"
../source/schedule.exe 5 3 1  < ../inputs/input/nnt10 > ../outputs/output.${1}/t2434
echo ">>>>>>>>running test 2435"
../source/schedule.exe 0 3 1  < ../inputs/input/nnt10 > ../outputs/output.${1}/t2435
echo ">>>>>>>>running test 2436"
../source/schedule.exe 0 1 1  < ../inputs/input/nnt10 > ../outputs/output.${1}/t2436
echo ">>>>>>>>running test 2437"
../source/schedule.exe 0 1 1  < ../inputs/input/nnt11 > ../outputs/output.${1}/t2437
echo ">>>>>>>>running test 2438"
../source/schedule.exe 3 4 1  < ../inputs/input/nnt11 > ../outputs/output.${1}/t2438
echo ">>>>>>>>running test 2439"
../source/schedule.exe 3 1 1  < ../inputs/input/nnt11 > ../outputs/output.${1}/t2439
echo ">>>>>>>>running test 2440"
../source/schedule.exe 3 1 1  < ../inputs/input/nnt12 > ../outputs/output.${1}/t2440
echo ">>>>>>>>running test 2441"
../source/schedule.exe 3 1 0  < ../inputs/input/nnt12 > ../outputs/output.${1}/t2441
echo ">>>>>>>>running test 2442"
../source/schedule.exe 5 0 0  < ../inputs/input/nnt12 > ../outputs/output.${1}/t2442
echo ">>>>>>>>running test 2443"
../source/schedule.exe 5 1 1  < ../inputs/input/nnt13 > ../outputs/output.${1}/t2443
echo ">>>>>>>>running test 2444"
../source/schedule.exe 1 1 1  < ../inputs/input/nnt13 > ../outputs/output.${1}/t2444
echo ">>>>>>>>running test 2445"
../source/schedule.exe 1 1 1  < ../inputs/input/nnt14 > ../outputs/output.${1}/t2445
echo ">>>>>>>>running test 2446"
../source/schedule.exe 3 5 2  < ../inputs/input/nnt14 > ../outputs/output.${1}/t2446
echo ">>>>>>>>running test 2447"
../source/schedule.exe 3 0 0  < ../inputs/input/nnt14 > ../outputs/output.${1}/t2447
echo ">>>>>>>>running test 2448"
../source/schedule.exe 1 0 7  < ../inputs/input/inp.hf.18 > ../outputs/output.${1}/t2448
echo ">>>>>>>>running test 2449"
../source/schedule.exe 3 2 4  < ../inputs/input/inp.hf.17 > ../outputs/output.${1}/t2449
echo ">>>>>>>>running test 2450"
../source/schedule.exe 0 1 0  < ../inputs/input/adt.55 > ../outputs/output.${1}/t2450
echo ">>>>>>>>running test 2451"
../source/schedule.exe 0 0 0  < ../inputs/input/adt.3 > ../outputs/output.${1}/t2451
echo ">>>>>>>>running test 2452"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2452
echo ">>>>>>>>running test 2453"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2453
echo ">>>>>>>>running test 2454"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2454
echo ">>>>>>>>running test 2455"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2455
echo ">>>>>>>>running test 2456"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2456
echo ">>>>>>>>running test 2457"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2457
echo ">>>>>>>>running test 2458"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2458
echo ">>>>>>>>running test 2459"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/output.${1}/t2459
echo ">>>>>>>>running test 2460"
../source/schedule.exe 0 0 0  < ../inputs/input/inp.hf.14 > ../outputs/output.${1}/t2460
echo ">>>>>>>>running test 2461"
../source/schedule.exe 0 1 5  < ../inputs/input/inp.hf.14 > ../outputs/output.${1}/t2461
echo ">>>>>>>>running test 2462"
../source/schedule.exe 0 5 1  < ../inputs/input/inp.hf.13 > ../outputs/output.${1}/t2462
echo ">>>>>>>>running test 2463"
../source/schedule.exe 1 2 3  < ../inputs/input/inp.hf.12 > ../outputs/output.${1}/t2463
echo ">>>>>>>>running test 2464"
../source/schedule.exe 0 1 0  < ../inputs/input/inp.hf.8 > ../outputs/output.${1}/t2464
echo ">>>>>>>>running test 2465"
../source/schedule.exe 2 1 0  < ../inputs/input/inp.hf.1 > ../outputs/output.${1}/t2465
echo ">>>>>>>>running test 2466"
../source/schedule.exe 1 1 0  < ../inputs/input/inp.hf.12 > ../outputs/output.${1}/t2466
echo ">>>>>>>>running test 2467"
../source/schedule.exe 0 2 5  < ../inputs/input/inp.hf.8 > ../outputs/output.${1}/t2467
echo ">>>>>>>>running test 2468"
../source/schedule.exe 0 1 2   < ../inputs/input/lu119 > ../outputs/output.${1}/t2468
echo ">>>>>>>>running test 2469"
../source/schedule.exe 1 0 3   < ../inputs/input/lu68 > ../outputs/output.${1}/t2469
echo ">>>>>>>>running test 2470"
../source/schedule.exe 3 3 1  < ../inputs/input/ft.2 > ../outputs/output.${1}/t2470
echo ">>>>>>>>running test 2471"
../source/schedule.exe 9 4 2  < ../inputs/input/ft.21 > ../outputs/output.${1}/t2471
echo ">>>>>>>>running test 2472"
../source/schedule.exe 3 9 7  < ../inputs/input/ft.1 > ../outputs/output.${1}/t2472
echo ">>>>>>>>running test 2473"
../source/schedule.exe 2 0 2  < ../inputs/input/ft.30 > ../outputs/output.${1}/t2473
echo ">>>>>>>>running test 2474"
../source/schedule.exe 6 8 3  < ../inputs/input/ft.29 > ../outputs/output.${1}/t2474
echo ">>>>>>>>running test 2475"
../source/schedule.exe 10 8 3  < ../inputs/input/ft.25 > ../outputs/output.${1}/t2475
echo ">>>>>>>>running test 2476"
../source/schedule.exe 2 7 9  < ../inputs/input/ft.6 > ../outputs/output.${1}/t2476
echo ">>>>>>>>running test 2477"
../source/schedule.exe 8 6 5  < ../inputs/input/ft.1 > ../outputs/output.${1}/t2477
echo ">>>>>>>>running test 2478"
../source/schedule.exe 2 5 6  < ../inputs/input/ft.30 > ../outputs/output.${1}/t2478
echo ">>>>>>>>running test 2479"
../source/schedule.exe 2 1 5  < ../inputs/input/ft.20 > ../outputs/output.${1}/t2479
echo ">>>>>>>>running test 2480"
../source/schedule.exe 10 0 7  < ../inputs/input/ft.25 > ../outputs/output.${1}/t2480
echo ">>>>>>>>running test 2481"
../source/schedule.exe 7 8 1  < ../inputs/input/ft.25 > ../outputs/output.${1}/t2481
echo ">>>>>>>>running test 2482"
../source/schedule.exe 10 7 9  < ../inputs/input/ft.3 > ../outputs/output.${1}/t2482
echo ">>>>>>>>running test 2483"
../source/schedule.exe 1 2 3  < ../inputs/input/ft.20 > ../outputs/output.${1}/t2483
echo ">>>>>>>>running test 2484"
../source/schedule.exe 3 7 3  < ../inputs/input/ft.18 > ../outputs/output.${1}/t2484
echo ">>>>>>>>running test 2485"
../source/schedule.exe 3 6 4  < ../inputs/input/ft.9 > ../outputs/output.${1}/t2485
echo ">>>>>>>>running test 2486"
../source/schedule.exe 7 10 9  < ../inputs/input/ft.6 > ../outputs/output.${1}/t2486
echo ">>>>>>>>running test 2487"
../source/schedule.exe 6 8 9  < ../inputs/input/ft.26 > ../outputs/output.${1}/t2487
echo ">>>>>>>>running test 2488"
../source/schedule.exe 3 1 5  < ../inputs/input/ft.8 > ../outputs/output.${1}/t2488
echo ">>>>>>>>running test 2489"
../source/schedule.exe 2 4 2  < ../inputs/input/ft.15 > ../outputs/output.${1}/t2489
echo ">>>>>>>>running test 2490"
../source/schedule.exe 6 6 0  < ../inputs/input/ft.19 > ../outputs/output.${1}/t2490
echo ">>>>>>>>running test 2491"
../source/schedule.exe 4 10 6  < ../inputs/input/ft.26 > ../outputs/output.${1}/t2491
echo ">>>>>>>>running test 2492"
../source/schedule.exe 6 0 1  < ../inputs/input/ft.4 > ../outputs/output.${1}/t2492
echo ">>>>>>>>running test 2493"
../source/schedule.exe 7 2 5  < ../inputs/input/ft.5 > ../outputs/output.${1}/t2493
echo ">>>>>>>>running test 2494"
../source/schedule.exe 9 8 0  < ../inputs/input/ft.1 > ../outputs/output.${1}/t2494
echo ">>>>>>>>running test 2495"
../source/schedule.exe 4 2 10  < ../inputs/input/ft.1 > ../outputs/output.${1}/t2495
echo ">>>>>>>>running test 2496"
../source/schedule.exe 4 1 4  < ../inputs/input/ft.14 > ../outputs/output.${1}/t2496
echo ">>>>>>>>running test 2497"
../source/schedule.exe 1 1 9  < ../inputs/input/ft.21 > ../outputs/output.${1}/t2497
echo ">>>>>>>>running test 2498"
../source/schedule.exe 2 7 3  < ../inputs/input/ft.11 > ../outputs/output.${1}/t2498
echo ">>>>>>>>running test 2499"
../source/schedule.exe 10 10 6  < ../inputs/input/ft.2 > ../outputs/output.${1}/t2499
echo ">>>>>>>>running test 2500"
../source/schedule.exe 8 9 2  < ../inputs/input/ft.8 > ../outputs/output.${1}/t2500
echo ">>>>>>>>running test 2501"
../source/schedule.exe 2 9 10  < ../inputs/input/ft.9 > ../outputs/output.${1}/t2501
echo ">>>>>>>>running test 2502"
../source/schedule.exe 6 9 1  < ../inputs/input/ft.11 > ../outputs/output.${1}/t2502
echo ">>>>>>>>running test 2503"
../source/schedule.exe 10 7 5  < ../inputs/input/ft.3 > ../outputs/output.${1}/t2503
echo ">>>>>>>>running test 2504"
../source/schedule.exe 7 1 4  < ../inputs/input/ft.19 > ../outputs/output.${1}/t2504
echo ">>>>>>>>running test 2505"
../source/schedule.exe 1 2 1  < ../inputs/input/ft.24 > ../outputs/output.${1}/t2505
echo ">>>>>>>>running test 2506"
../source/schedule.exe 3 1 6  < ../inputs/input/ft.17 > ../outputs/output.${1}/t2506
echo ">>>>>>>>running test 2507"
../source/schedule.exe 1 9 5  < ../inputs/input/ft.14 > ../outputs/output.${1}/t2507
echo ">>>>>>>>running test 2508"
../source/schedule.exe 9 5 8  < ../inputs/input/ft.8 > ../outputs/output.${1}/t2508
echo ">>>>>>>>running test 2509"
../source/schedule.exe 0 6 3  < ../inputs/input/ft.14 > ../outputs/output.${1}/t2509
echo ">>>>>>>>running test 2510"
../source/schedule.exe 8 6 2  < ../inputs/input/ft.27 > ../outputs/output.${1}/t2510
echo ">>>>>>>>running test 2511"
../source/schedule.exe 6 6 10  < ../inputs/input/ft.8 > ../outputs/output.${1}/t2511
echo ">>>>>>>>running test 2512"
../source/schedule.exe 8 2 9  < ../inputs/input/ft.19 > ../outputs/output.${1}/t2512
echo ">>>>>>>>running test 2513"
../source/schedule.exe 2 2 6  < ../inputs/input/ft.11 > ../outputs/output.${1}/t2513
echo ">>>>>>>>running test 2514"
../source/schedule.exe 4 9 4  < ../inputs/input/ft.15 > ../outputs/output.${1}/t2514
echo ">>>>>>>>running test 2515"
../source/schedule.exe 10 7 9  < ../inputs/input/ft.26 > ../outputs/output.${1}/t2515
echo ">>>>>>>>running test 2516"
../source/schedule.exe 4 7 6  < ../inputs/input/ft.24 > ../outputs/output.${1}/t2516
echo ">>>>>>>>running test 2517"
../source/schedule.exe 9 5 3  < ../inputs/input/ft.1 > ../outputs/output.${1}/t2517
echo ">>>>>>>>running test 2518"
../source/schedule.exe 3 5 9  < ../inputs/input/ft.25 > ../outputs/output.${1}/t2518
echo ">>>>>>>>running test 2519"
../source/schedule.exe 5 3 10  < ../inputs/input/ft.5 > ../outputs/output.${1}/t2519
echo ">>>>>>>>running test 2520"
../source/schedule.exe  < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2520
echo ">>>>>>>>running test 2521"
../source/schedule.exe  < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2521
echo ">>>>>>>>running test 2522"
../source/schedule.exe  < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2522
echo ">>>>>>>>running test 2523"
../source/schedule.exe 1 2   < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2523
echo ">>>>>>>>running test 2524"
../source/schedule.exe 2 3   < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2524
echo ">>>>>>>>running test 2525"
../source/schedule.exe 2 3   < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2525
echo ">>>>>>>>running test 2526"
../source/schedule.exe 0 0  < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2526
echo ">>>>>>>>running test 2527"
../source/schedule.exe 0   0     < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2527
echo ">>>>>>>>running test 2528"
../source/schedule.exe 0          0  < ../inputs/input/bdt.77 > ../outputs/output.${1}/t2528
echo ">>>>>>>>running test 2529"
../source/schedule.exe 1 1 1  < ../inputs/input/et.1 > ../outputs/output.${1}/t2529
echo ">>>>>>>>running test 2530"
../source/schedule.exe 1 2 3  < ../inputs/input/et.3 > ../outputs/output.${1}/t2530
echo ">>>>>>>>running test 2531"
../source/schedule.exe 1 2 3  < ../inputs/input/et.2 > ../outputs/output.${1}/t2531
echo ">>>>>>>>running test 2532"
../source/schedule.exe 2 1 3  < ../inputs/input/et.4 > ../outputs/output.${1}/t2532
echo ">>>>>>>>running test 2533"
../source/schedule.exe 3 4 1  < ../inputs/input/et.5 > ../outputs/output.${1}/t2533
echo ">>>>>>>>running test 2534"
../source/schedule.exe 1 2 1  < ../inputs/input/et.6 > ../outputs/output.${1}/t2534
echo ">>>>>>>>running test 2535"
../source/schedule.exe 2 1 2  < ../inputs/input/et.7 > ../outputs/output.${1}/t2535
echo ">>>>>>>>running test 2536"
../source/schedule.exe 2 3 1  < ../inputs/input/et.8 > ../outputs/output.${1}/t2536
echo ">>>>>>>>running test 2537"
../source/schedule.exe 2 1 1  < ../inputs/input/et.9 > ../outputs/output.${1}/t2537
echo ">>>>>>>>running test 2538"
../source/schedule.exe 2 5 1  < ../inputs/input/et.10 > ../outputs/output.${1}/t2538
echo ">>>>>>>>running test 2539"
../source/schedule.exe 0 0 0  < ../inputs/input/et.11 > ../outputs/output.${1}/t2539
echo ">>>>>>>>running test 2540"
../source/schedule.exe 0 1 4  < ../inputs/input/et.12 > ../outputs/output.${1}/t2540
echo ">>>>>>>>running test 2541"
../source/schedule.exe 1 2 3  < ../inputs/input/et.13 > ../outputs/output.${1}/t2541
echo ">>>>>>>>running test 2542"
../source/schedule.exe 4 1 2  < ../inputs/input/et.14 > ../outputs/output.${1}/t2542
echo ">>>>>>>>running test 2543"
../source/schedule.exe 1 2 3  < ../inputs/input/et.15 > ../outputs/output.${1}/t2543
echo ">>>>>>>>running test 2544"
../source/schedule.exe 3  1  < ../inputs/input/ft.2 > ../outputs/output.${1}/t2544
echo ">>>>>>>>running test 2545"
../source/schedule.exe 9  2  < ../inputs/input/ft.21 > ../outputs/output.${1}/t2545
echo ">>>>>>>>running test 2546"
../source/schedule.exe 3   < ../inputs/input/ft.1 > ../outputs/output.${1}/t2546
echo ">>>>>>>>running test 2547"
../source/schedule.exe 2  2  < ../inputs/input/ft.30 > ../outputs/output.${1}/t2547
echo ">>>>>>>>running test 2548"
../source/schedule.exe 6   < ../inputs/input/ft.29 > ../outputs/output.${1}/t2548
echo ">>>>>>>>running test 2549"
../source/schedule.exe 8 3  < ../inputs/input/ft.25 > ../outputs/output.${1}/t2549
echo ">>>>>>>>running test 2550"
../source/schedule.exe 2  9  < ../inputs/input/ft.6 > ../outputs/output.${1}/t2550
echo ">>>>>>>>running test 2551"
../source/schedule.exe 8 6   < ../inputs/input/ft.1 > ../outputs/output.${1}/t2551
echo ">>>>>>>>running test 2552"
../source/schedule.exe 2 5   < ../inputs/input/ft.30 > ../outputs/output.${1}/t2552
echo ">>>>>>>>running test 2553"
../source/schedule.exe 2  5  < ../inputs/input/ft.20 > ../outputs/output.${1}/t2553
echo ">>>>>>>>running test 2554"
../source/schedule.exe 2 5 0  < ../inputs/input/dt.1 > ../outputs/output.${1}/t2554
echo ">>>>>>>>running test 2555"
../source/schedule.exe 2 0 0  < ../inputs/input/dt.1 > ../outputs/output.${1}/t2555
echo ">>>>>>>>running test 2556"
../source/schedule.exe 2 0 0  < ../inputs/input/dt.2 > ../outputs/output.${1}/t2556
echo ">>>>>>>>running test 2557"
../source/schedule.exe 2 2 2   < ../inputs/input/dt.2 > ../outputs/output.${1}/t2557
echo ">>>>>>>>running test 2558"
../source/schedule.exe 0 2 1   < ../inputs/input/dt.3 > ../outputs/output.${1}/t2558
echo ">>>>>>>>running test 2559"
../source/schedule.exe 1 4 2   < ../inputs/input/dt.4 > ../outputs/output.${1}/t2559
echo ">>>>>>>>running test 2560"
../source/schedule.exe 0 4 2   < ../inputs/input/dt.5 > ../outputs/output.${1}/t2560
echo ">>>>>>>>running test 2561"
../source/schedule.exe 0 4 2   < ../inputs/input/dt.6 > ../outputs/output.${1}/t2561
echo ">>>>>>>>running test 2562"
../source/schedule.exe 1 4 2   < ../inputs/input/dt.7 > ../outputs/output.${1}/t2562
echo ">>>>>>>>running test 2563"
../source/schedule.exe 1 4 0   < ../inputs/input/dt.8 > ../outputs/output.${1}/t2563
echo ">>>>>>>>running test 2564"
../source/schedule.exe 1 4 0   < ../inputs/input/dt.9 > ../outputs/output.${1}/t2564
echo ">>>>>>>>running test 2565"
../source/schedule.exe 0 2 0  < ../inputs/input/dt.9 > ../outputs/output.${1}/t2565
echo ">>>>>>>>running test 2566"
../source/schedule.exe 1 2 1  < ../inputs/input/dt.10 > ../outputs/output.${1}/t2566
echo ">>>>>>>>running test 2567"
../source/schedule.exe 1 2 1  < ../inputs/input/dt.11 > ../outputs/output.${1}/t2567
echo ">>>>>>>>running test 2568"
../source/schedule.exe 1 2 1  < ../inputs/input/dt.12 > ../outputs/output.${1}/t2568
echo ">>>>>>>>running test 2569"
../source/schedule.exe 3 2 0  < ../inputs/input/dt.13 > ../outputs/output.${1}/t2569
echo ">>>>>>>>running test 2570"
../source/schedule.exe 3 2 0  < ../inputs/input/dt.14 > ../outputs/output.${1}/t2570
echo ">>>>>>>>running test 2571"
../source/schedule.exe 2 1 0   < ../inputs/input/dt.15 > ../outputs/output.${1}/t2571
echo ">>>>>>>>running test 2572"
../source/schedule.exe 2 1 1   < ../inputs/input/dt.16 > ../outputs/output.${1}/t2572
echo ">>>>>>>>running test 2573"
../source/schedule.exe 2 1 1   < ../inputs/input/dt.17 > ../outputs/output.${1}/t2573
echo ">>>>>>>>running test 2574"
../source/schedule.exe 2 1 1   < ../inputs/input/dt.18 > ../outputs/output.${1}/t2574
echo ">>>>>>>>running test 2575"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.19 > ../outputs/output.${1}/t2575
echo ">>>>>>>>running test 2576"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.20 > ../outputs/output.${1}/t2576
echo ">>>>>>>>running test 2577"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.21 > ../outputs/output.${1}/t2577
echo ">>>>>>>>running test 2578"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.22 > ../outputs/output.${1}/t2578
echo ">>>>>>>>running test 2579"
../source/schedule.exe 4 1 2   < ../inputs/input/dt.23 > ../outputs/output.${1}/t2579
echo ">>>>>>>>running test 2580"
../source/schedule.exe 4 1 2   < ../inputs/input/dt.24 > ../outputs/output.${1}/t2580
echo ">>>>>>>>running test 2581"
../source/schedule.exe 1 1 1  < ../inputs/input/ct.1 > ../outputs/output.${1}/t2581
echo ">>>>>>>>running test 2582"
../source/schedule.exe 0 2 1  < ../inputs/input/ct.2 > ../outputs/output.${1}/t2582
echo ">>>>>>>>running test 2583"
../source/schedule.exe 3 2 0  < ../inputs/input/ct.3 > ../outputs/output.${1}/t2583
echo ">>>>>>>>running test 2584"
../source/schedule.exe 3 0 0  < ../inputs/input/ct.3 > ../outputs/output.${1}/t2584
echo ">>>>>>>>running test 2585"
../source/schedule.exe 3 0 0  < ../inputs/input/ct.4 > ../outputs/output.${1}/t2585
echo ">>>>>>>>running test 2586"
../source/schedule.exe 1 1 1  < ../inputs/input/ct.4 > ../outputs/output.${1}/t2586
echo ">>>>>>>>running test 2587"
../source/schedule.exe 1 1 1  < ../inputs/input/ct.5 > ../outputs/output.${1}/t2587
echo ">>>>>>>>running test 2588"
../source/schedule.exe 3 0 3  < ../inputs/input/ct.5 > ../outputs/output.${1}/t2588
echo ">>>>>>>>running test 2589"
../source/schedule.exe 3 0 3  < ../inputs/input/ct.6 > ../outputs/output.${1}/t2589
echo ">>>>>>>>running test 2590"
../source/schedule.exe 3 1 3  < ../inputs/input/ct.7 > ../outputs/output.${1}/t2590
echo ">>>>>>>>running test 2591"
../source/schedule.exe 1 0 0  < ../inputs/input/ct.7 > ../outputs/output.${1}/t2591
echo ">>>>>>>>running test 2592"
../source/schedule.exe 1 9 9  < ../inputs/input/ct.8 > ../outputs/output.${1}/t2592
echo ">>>>>>>>running test 2593"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.8 > ../outputs/output.${1}/t2593
echo ">>>>>>>>running test 2594"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.9 > ../outputs/output.${1}/t2594
echo ">>>>>>>>running test 2595"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.10 > ../outputs/output.${1}/t2595
echo ">>>>>>>>running test 2596"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.11 > ../outputs/output.${1}/t2596
echo ">>>>>>>>running test 2597"
../source/schedule.exe 0 3 0  < ../inputs/input/ct.11 > ../outputs/output.${1}/t2597
echo ">>>>>>>>running test 2598"
../source/schedule.exe 1 3 0  < ../inputs/input/ct.12 > ../outputs/output.${1}/t2598
echo ">>>>>>>>running test 2599"
../source/schedule.exe 1 3 2  < ../inputs/input/ct.13 > ../outputs/output.${1}/t2599
echo ">>>>>>>>running test 2600"
../source/schedule.exe 3 4 5  < ../inputs/input/ct.14 > ../outputs/output.${1}/t2600
echo ">>>>>>>>running test 2601"
../source/schedule.exe 1 2 3  < ../inputs/input/ct.15 > ../outputs/output.${1}/t2601
echo ">>>>>>>>running test 2602"
../source/schedule.exe 4 2 3  < ../inputs/input/ct.16 > ../outputs/output.${1}/t2602
echo ">>>>>>>>running test 2603"
../source/schedule.exe 2 2 2  < ../inputs/input/ct.17 > ../outputs/output.${1}/t2603
echo ">>>>>>>>running test 2604"
../source/schedule.exe 4 5 6  < ../inputs/input/ct.18 > ../outputs/output.${1}/t2604
echo ">>>>>>>>running test 2605"
../source/schedule.exe 3 3 4  < ../inputs/input/ct.19 > ../outputs/output.${1}/t2605
echo ">>>>>>>>running test 2606"
../source/schedule.exe 3 2 4  < ../inputs/input/ct.20 > ../outputs/output.${1}/t2606
echo ">>>>>>>>running test 2607"
../source/schedule.exe 3 2 4  < ../inputs/input/ct.21 > ../outputs/output.${1}/t2607
echo ">>>>>>>>running test 2608"
../source/schedule.exe 0 1 2  < ../inputs/input/ct.22 > ../outputs/output.${1}/t2608
echo ">>>>>>>>running test 2609"
../source/schedule.exe 1 0 5  < ../inputs/input/ct.23 > ../outputs/output.${1}/t2609
echo ">>>>>>>>running test 2610"
../source/schedule.exe 3 4 2  < ../inputs/input/ct.24 > ../outputs/output.${1}/t2610
echo ">>>>>>>>running test 2611"
../source/schedule.exe 3 2 1  < ../inputs/input/ct.25 > ../outputs/output.${1}/t2611
echo ">>>>>>>>running test 2612"
../source/schedule.exe 7 1 3  < ../inputs/input/ct.26 > ../outputs/output.${1}/t2612
echo ">>>>>>>>running test 2613"
../source/schedule.exe 2 1 4  < ../inputs/input/ct.27 > ../outputs/output.${1}/t2613
echo ">>>>>>>>running test 2614"
../source/schedule.exe 3 1 5  < ../inputs/input/ct.28 > ../outputs/output.${1}/t2614
echo ">>>>>>>>running test 2615"
../source/schedule.exe 0 0 0  < ../inputs/input/ct.29 > ../outputs/output.${1}/t2615
echo ">>>>>>>>running test 2616"
../source/schedule.exe 1 2 0  < ../inputs/input/ct.30 > ../outputs/output.${1}/t2616
echo ">>>>>>>>running test 2617"
../source/schedule.exe 2 3 1  < ../inputs/input/ct.31 > ../outputs/output.${1}/t2617
echo ">>>>>>>>running test 2618"
../source/schedule.exe 1 4 2  < ../inputs/input/ct.32 > ../outputs/output.${1}/t2618
echo ">>>>>>>>running test 2619"
../source/schedule.exe 3 5 0  < ../inputs/input/ct.33 > ../outputs/output.${1}/t2619
echo ">>>>>>>>running test 2620"
../source/schedule.exe 0 3 4  < ../inputs/input/ct.34 > ../outputs/output.${1}/t2620
echo ">>>>>>>>running test 2621"
../source/schedule.exe 1 2 3  < ../inputs/input/ct.35 > ../outputs/output.${1}/t2621
echo ">>>>>>>>running test 2622"
../source/schedule.exe 6 7 3  < ../inputs/input/ct.36 > ../outputs/output.${1}/t2622
echo ">>>>>>>>running test 2623"
../source/schedule.exe 1 2 0  < ../inputs/input/ct.37 > ../outputs/output.${1}/t2623
echo ">>>>>>>>running test 2624"
../source/schedule.exe 3 4 5  < ../inputs/input/ct.38 > ../outputs/output.${1}/t2624
echo ">>>>>>>>running test 2625"
../source/schedule.exe 2 3 1  < ../inputs/input/ct.39 > ../outputs/output.${1}/t2625
echo ">>>>>>>>running test 2626"
../source/schedule.exe 1 4 5  < ../inputs/input/ct.40 > ../outputs/output.${1}/t2626
echo ">>>>>>>>running test 2627"
../source/schedule.exe 1 5 6  < ../inputs/input/ct.41 > ../outputs/output.${1}/t2627
echo ">>>>>>>>running test 2628"
../source/schedule.exe 1 2 4  < ../inputs/input/ct.42 > ../outputs/output.${1}/t2628
echo ">>>>>>>>running test 2629"
../source/schedule.exe 0 8 4  < ../inputs/input/ct.43 > ../outputs/output.${1}/t2629
echo ">>>>>>>>running test 2630"
../source/schedule.exe 0 3 4  < ../inputs/input/ct.44 > ../outputs/output.${1}/t2630
echo ">>>>>>>>running test 2631"
../source/schedule.exe 0 3 2  < ../inputs/input/ct.45 > ../outputs/output.${1}/t2631
echo ">>>>>>>>running test 2632"
../source/schedule.exe 8 2 4  < ../inputs/input/ct.46 > ../outputs/output.${1}/t2632
echo ">>>>>>>>running test 2633"
../source/schedule.exe 2 2 1  < ../inputs/input/ct.47 > ../outputs/output.${1}/t2633
echo ">>>>>>>>running test 2634"
../source/schedule.exe 1 2 4  < ../inputs/input/ct.48 > ../outputs/output.${1}/t2634
echo ">>>>>>>>running test 2635"
../source/schedule.exe 0 9 0  < ../inputs/input/ct.49 > ../outputs/output.${1}/t2635
echo ">>>>>>>>running test 2636"
../source/schedule.exe 1 3 2  < ../inputs/input/ct.50 > ../outputs/output.${1}/t2636
echo ">>>>>>>>running test 2637"
../source/schedule.exe 0 9 2  < ../inputs/input/ct.51 > ../outputs/output.${1}/t2637
echo ">>>>>>>>running test 2638"
../source/schedule.exe 2 1 2  < ../inputs/input/ct.52 > ../outputs/output.${1}/t2638
echo ">>>>>>>>running test 2639"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.53 > ../outputs/output.${1}/t2639
echo ">>>>>>>>running test 2640"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.54 > ../outputs/output.${1}/t2640
echo ">>>>>>>>running test 2641"
../source/schedule.exe 2 2 2  < ../inputs/input/ct.55 > ../outputs/output.${1}/t2641
echo ">>>>>>>>running test 2642"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.56 > ../outputs/output.${1}/t2642
echo ">>>>>>>>running test 2643"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.57 > ../outputs/output.${1}/t2643
echo ">>>>>>>>running test 2644"
../source/schedule.exe 2 1 2  < ../inputs/input/ct.58 > ../outputs/output.${1}/t2644
echo ">>>>>>>>running test 2645"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.59 > ../outputs/output.${1}/t2645
echo ">>>>>>>>running test 2646"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.60 > ../outputs/output.${1}/t2646
echo ">>>>>>>>running test 2647"
../source/schedule.exe 2 2 2  < ../inputs/input/ct.61 > ../outputs/output.${1}/t2647
echo ">>>>>>>>running test 2648"
../source/schedule.exe 2 0 2  < ../inputs/input/ct.62 > ../outputs/output.${1}/t2648
echo ">>>>>>>>running test 2649"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.63 > ../outputs/output.${1}/t2649
echo ">>>>>>>>running test 2650"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.65 > ../outputs/output.${1}/t2650

