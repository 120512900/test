#!/bin/bash

new="./runall.sh"
while read line
do
  if [[ ${line} =~ "schedule.exe" ]];then
    line="{ $line; } 2>../outputs/output.\${1}/${line#*output.\$\{1\}/}"
  fi
  echo ${line} >> ${new}
done < "./oldrunall.sh"
