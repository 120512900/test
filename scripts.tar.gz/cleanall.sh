#!/bin/bash

tmp="./tmp.txt"
eval "rm ./log.txt >> ${tmp} 2>&1"
eval "rm ../source.alt/source.orig/schedule.gc* >> ${tmp} 2>&1"
eval "rm ../source.alt/source.orig/schedule.c.gcov >> ${tmp} 2>&1"
eval "rm ../source.alt/source.orig/lcov_info >> ${tmp} 2>&1"
eval "rm -rf ../source.alt/source.orig/lcov_report >> ${tmp} 2>&1"
eval "rm -rf ../outputs/output.correct >> ${tmp} 2>&1"

clean(){
	target=$1
	eval "rm ../versions.alt/versions.orig/${target}/schedule.gc* >> ${tmp} 2>&1"
	eval "rm ../versions.alt/versions.orig/${target}/schedule.c.gcov >> ${tmp} 2>&1"
	eval "rm ../versions.alt/versions.orig/${target}/lcov_info >> ${tmp} 2>&1"
	eval "rm -rf ../versions.alt/versions.orig/${target}/lcov_report >> ${tmp} 2>&1"
	eval "rm -rf ../outputs/output.${target} >> ${tmp} 2>&1"
	
}

i=1
while(( $i<10))
do
  clean v$i
  let i++
done
eval "rm ./tmp.txt"
